-- CREAZIONE TABELLA pcsassunzionisimulate --
IF NOT EXISTS(select * from sysobjects where id = object_id(N'[dbo].[pcsassunzionisimulate]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[pcsassunzionisimulate] (
idpcsassunzionisimulate int NOT NULL,
year int NOT NULL,
ct datetime NOT NULL,
cu varchar(64) NOT NULL,
data datetime NULL,
finanziamento varchar(150) NULL,
idcontrattokind int NULL,
idcontrattokind_start int NULL,
idsasd int NULL,
idstruttura int NULL,
legge varchar(250) NULL,
lt datetime NOT NULL,
lu varchar(64) NOT NULL,
nominativo varchar(150) NULL,
numeropersoneassunzione decimal(19,2) NULL,
percentuale decimal(19,2) NULL,
stipendio decimal(19,2) NULL,
totale decimal(19,2) NULL,
totale1 decimal(19,2) NULL,
totale2 decimal(19,2) NULL,
totale3 decimal(19,2) NULL,
 CONSTRAINT xpkpcsassunzionisimulate PRIMARY KEY (idpcsassunzionisimulate,
year
)
)
END
GO

-- VERIFICA STRUTTURA pcsassunzionisimulate --
IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'idpcsassunzionisimulate' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD idpcsassunzionisimulate int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'idpcsassunzionisimulate' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'year' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD year int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'year' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'ct' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD ct datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'ct' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN ct datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'cu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD cu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'cu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN cu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'data' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD data datetime NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN data datetime NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'finanziamento' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD finanziamento varchar(150) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN finanziamento varchar(150) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'idcontrattokind' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD idcontrattokind int NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN idcontrattokind int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'idcontrattokind_start' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD idcontrattokind_start int NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN idcontrattokind_start int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'idsasd' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD idsasd int NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN idsasd int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'idstruttura' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD idstruttura int NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN idstruttura int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'legge' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD legge varchar(250) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN legge varchar(250) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'lt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD lt datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'lt' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN lt datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'lu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD lu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('pcsassunzionisimulate') and col.name = 'lu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [pcsassunzionisimulate] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN lu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'nominativo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD nominativo varchar(150) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN nominativo varchar(150) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'numeropersoneassunzione' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD numeropersoneassunzione decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN numeropersoneassunzione decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'percentuale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD percentuale decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN percentuale decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'stipendio' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD stipendio decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN stipendio decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'totale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD totale decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN totale decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'totale1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD totale1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN totale1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'totale2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD totale2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN totale2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'pcsassunzionisimulate' and C.name = 'totale3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [pcsassunzionisimulate] ADD totale3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [pcsassunzionisimulate] ALTER COLUMN totale3 decimal(19,2) NULL
GO

-- CREAZIONE VISTA pcspuntiorganicoview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[pcspuntiorganicoview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[pcspuntiorganicoview]
GO

CREATE VIEW [dbo].[pcspuntiorganicoview]
AS
SELECT *
FROM (
	SELECT annoelab AS year,
	contrattokind_title,isdoc,
	DATA,
	CONCAT(COLUMN_NAME,
		  CASE annorif WHEN annoelab THEN 0
					   WHEN annoelab+1 THEN 1
					   WHEN annoelab+2 THEN 2
					   WHEN annoelab+3 THEN 3
					   END
	) AS PIV_COL
	FROM   (
------------------------------------	
		select annoelab, 
		annorif,
		contrattokind_title,
		SUM(puntipiu) AS puntipiu,
		SUM(puntimeno) as puntimeno,
		SUM(importo) AS importo,
		sum(importoateneo) as importoateneo,
		sum(importoesterno) as importoesterno,
		isdoc
		from (

			------------------------assunzioni simulate inizio ----------------------------		
			SELECT  
			annoelab, 
			annorif,
			contrattokind_title,
			SUM(puntiorganico) AS puntipiu,
			puntimeno,
			SUM(totale) AS importo,
			SUM(totaleateneo) AS importoateneo,
			SUM(totaleesterno) AS importoesterno,
			isdoc
			from (
				----------------- annoelab = annorif----------------------
				
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale * isnull(numeropersoneassunzione,1) as totale,
				totale * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzionisimulate.data
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year = YEAR(pcsassunzionisimulate.data)
				
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+1 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year = YEAR(pcsassunzionisimulate.data)
				
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+2 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year = YEAR(pcsassunzionisimulate.data)
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+3 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind  ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year = YEAR(pcsassunzionisimulate.data)
				-----------------------------+1
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+1 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzionisimulate.data,dbo.pcsassunzionisimulate.year+1
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+1 = YEAR(pcsassunzionisimulate.data)
				
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+2 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+1 = YEAR(pcsassunzionisimulate.data)
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+3 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+1 = YEAR(pcsassunzionisimulate.data)				

				-------------------+2
						UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+2 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+2 = YEAR(pcsassunzionisimulate.data)
				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+3 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+2 = YEAR(pcsassunzionisimulate.data)		
				---------------------+3

				UNION 
				SELECT dbo.pcsassunzionisimulate.year AS annoelab, 
				dbo.pcsassunzionisimulate.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzionisimulate.year+3 = YEAR(pcsassunzionisimulate.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzionisimulate
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzionisimulate.idcontrattokind
				WHERE dbo.pcsassunzionisimulate.year+3 = YEAR(pcsassunzionisimulate.data)		

			) zz

			GROUP BY contrattokind_title, annoelab, annorif,puntimeno, isdoc		
				
			------------------------assunzioni simulate fine ----------------------------		
			UNION

			------------------------assunzioni inizio ----------------------------		
			SELECT  
			annoelab, 
			annorif,
			contrattokind_title,
			SUM(puntiorganico) AS puntipiu,
			puntimeno,
			SUM(totale) AS importo,
			SUM(totaleateneo) AS importoateneo,
			SUM(totaleesterno) AS importoesterno,
			isdoc
			from (
				----------------- annoelab = annorif----------------------
				
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale * isnull(numeropersoneassunzione,1) as totale,
				totale * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzioni.data
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind  ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				-----------------------------+1
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzioni.data,dbo.pcsassunzioni.year+1
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)				

				-------------------+2
						UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data)		
				---------------------+3

				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data)		

			) zz

			GROUP BY contrattokind_title, annoelab, annorif,puntimeno, isdoc		
				
			------------------------assunzioni fine ----------------------------		
			UNION

			---------------stipendioannuo ------------------------

			SELECT * from (
				
				select
				annoelab ,
				annorif,
				title,
				puntipiu,
				sum(puntimeno) as puntimeno,
				sum(importo) as importo,
				sum(importoateneo) as importoateneo,
				sum(importoesterno) as importoesterno,
				isdoc
				from (

				----------------- annoelab = annorif----------------------

				select 
				sa.idstipendioannuo,
				aa.year as annoelab ,
				sa.year as annorif,
				ck.title,
				0 as puntipiu,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
				
				CASE 
				WHEN isnull(YEAR(c.stop),sa.year+4) >= sa.year THEN sa.totale
				ELSE 0 
				END as importo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year THEN sa.totale * isnull(c.percentualesufondiateneo,100) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year THEN sa.totale / 12 * MONTH(c.stop) * isnull(c.percentualesufondiateneo,100) /100  
					ELSE 0 END 
				as importoateneo,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year THEN 
					(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
				ELSE 0 END as importoesterno,
				isnull(ck.tempdef,'N') as isdoc
				from analisiannuale aa
				inner join stipendioannuo sa on sa.year= aa.year 
				inner join contratto c on c.idcontratto = sa.idcontratto
				inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind
				
				UNION
				-----------------------------+1

				select 
				sa.idstipendioannuo,
				aa.year as annoelab ,
				sa.year+1 as annorif,
				ck.title,
				0 as puntipiu,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+1 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN (CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) )  ELSE sa.totale END)  
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+1 THEN (CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) )  ELSE sa.totale END) /12*MONTH(c.stop)     
					ELSE 0 
				END as importo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100))  ELSE sa.totale END)  * isnull(c.percentualesufondiateneo,100) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+1 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100))  ELSE sa.totale END)/12*MONTH(c.stop) * isnull(c.percentualesufondiateneo,100) /100  
					ELSE 0 END 
				as importoateneo,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN 
					(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) )  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
				ELSE 0 END as importoesterno,
				isnull(ck.tempdef,'N') as isdoc
				from analisiannuale aa
				inner join stipendioannuo sa on sa.year= aa.year 
				inner join contratto c on c.idcontratto = sa.idcontratto
				inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind

				UNION
				-----------------------------+2

				select 
				sa.idstipendioannuo,
				aa.year as annoelab ,
				sa.year+2 as annorif,
				ck.title,
				0 as puntipiu,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+2 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END)
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END) /12*MONTH(c.stop)     
					ELSE 0 END as importo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END) * isnull(c.percentualesufondiateneo,100) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END) / 12 * MONTH(c.stop) * isnull(c.percentualesufondiateneo,100) /100  
					ELSE 0 END 
				as importoateneo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100)) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+2 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)) ELSE sa.totale END) / 12 * MONTH(c.stop) * (100 - isnull(c.percentualesufondiateneo,100)) /100  
					ELSE 0 END 
				as importoesterno,
				isnull(ck.tempdef,'N') as isdoc
				from analisiannuale aa
				inner join stipendioannuo sa on sa.year= aa.year 
				inner join contratto c on c.idcontratto = sa.idcontratto
				inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind

				UNION
				-----------------------------+3

				select 
				sa.idstipendioannuo,
				aa.year as annoelab ,
				sa.year+3 as annorif,
				ck.title,
				0 as puntipiu,
				CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+3 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END)  
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END)/12*MONTH(c.stop)   
					ELSE 0 END 
				as importo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END)  * isnull(c.percentualesufondiateneo,100) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END) / 12 * MONTH(c.stop) * isnull(c.percentualesufondiateneo,100) /100
					ELSE 0 END 
				as importoateneo,
				CASE 
					WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END)  * (100 - isnull(c.percentualesufondiateneo,100)) /100
					WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+3 THEN (CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100))  ELSE sa.totale END) / 12 * MONTH(c.stop) * (100 - isnull(c.percentualesufondiateneo,100)) /100
					ELSE 0 END 
				as importoesterno,
				isnull(ck.tempdef,'N') as isdoc
				from analisiannuale aa
				inner join stipendioannuo sa on sa.year= aa.year 
				inner join contratto c on c.idcontratto = sa.idcontratto
				inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind


				) ss

				group by annoelab ,
				annorif,
				title,
				puntipiu,
				isdoc
				
			) tbl1

		) tbl2
		group by annoelab, 
		annorif,
		contrattokind_title,isdoc
		--order by contrattokind_title,annoelab, annorif
		-----------------------------------------------------
				
	) AS GROUPED_VIEW
       CROSS APPLY (VALUES ('puntipiu',puntipiu),
						   ('puntimeno',puntimeno),
                           ('importo',importo),
                           ('importoateneo',importoateneo),
                           ('importoesterno',importoesterno)
						   ) CS(COLUMN_NAME, DATA)) A
       PIVOT (SUM(DATA)
             FOR PIV_COL IN([puntipiu0],
							[puntimeno0],
                            [importo0],
                            [importoateneo0],
                            [importoesterno0],
                            [puntipiu1],
							[puntimeno1],
                            [importo1],
                            [importoateneo1],
                            [importoesterno1],
                            [puntipiu2],
							[puntimeno2],
                            [importo2],
                            [importoateneo2],
                            [importoesterno2],
							[puntipiu3],
							[puntimeno3],
                            [importo3],
                            [importoateneo3],
                            [importoesterno3]
							)) PV



GO

IF exists(SELECT * FROM [contrattokind] WHERE idcontrattokind = '21')
UPDATE [contrattokind] SET active = 'S',assegnoaggiuntivo = 'N',costolordoannuo = null,costolordoannuooneri = null,ct = {ts '2022-01-24 16:49:29.983'},cu = 'ferdinando.giannetti{DIRGEN}',description = null,elementoperequativo = 'N',indennitadiateneo = 'N',indennitadiposizione = 'N',indvacancacontrattuale = 'N',lt = {ts '2022-01-24 16:49:29.983'},lu = 'ferdinando.giannetti{DIRGEN}',oremaxcompitididatempoparziale = null,oremaxcompitididatempopieno = null,oremaxdidatempoparziale = null,oremaxdidatempopieno = null,oremaxgg = null,oremaxtempoparziale = null,oremaxtempopieno = '1720',oremincompitididatempoparziale = null,oremincompitididatempopieno = null,oremindidatempoparziale = null,oremindidatempopieno = null,oremintempoparziale = null,oremintempopieno = null,orestraordinariemax = null,parttime = 'N',puntiorganico = '1.5',scatto = 'S',siglaesportazione = 'PC',siglaimportazione = 'PC',sortcode = '0',tempdef = 'N',title = 'Professore a contratto esterno',totaletredicesima = 'S',tredicesimaindennitaintegrativaspeciale = 'N' WHERE idcontrattokind = '21'
ELSE
INSERT INTO [contrattokind] (idcontrattokind,active,assegnoaggiuntivo,costolordoannuo,costolordoannuooneri,ct,cu,description,elementoperequativo,indennitadiateneo,indennitadiposizione,indvacancacontrattuale,lt,lu,oremaxcompitididatempoparziale,oremaxcompitididatempopieno,oremaxdidatempoparziale,oremaxdidatempopieno,oremaxgg,oremaxtempoparziale,oremaxtempopieno,oremincompitididatempoparziale,oremincompitididatempopieno,oremindidatempoparziale,oremindidatempopieno,oremintempoparziale,oremintempopieno,orestraordinariemax,parttime,puntiorganico,scatto,siglaesportazione,siglaimportazione,sortcode,tempdef,title,totaletredicesima,tredicesimaindennitaintegrativaspeciale) VALUES ('21','S','N',null,null,{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,'N','N','N','N',{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,null,null,null,null,null,'1720',null,null,null,null,null,null,null,'N','1.5','S','PC','PC','0','N','Professore a contratto esterno','S','N')
GO


IF exists(SELECT * FROM [contrattokind] WHERE idcontrattokind = '22')
UPDATE [contrattokind] SET active = 'S',assegnoaggiuntivo = 'N',costolordoannuo = null,costolordoannuooneri = null,ct = {ts '2022-01-24 16:49:29.983'},cu = 'ferdinando.giannetti{DIRGEN}',description = null,elementoperequativo = 'N',indennitadiateneo = 'N',indennitadiposizione = 'N',indvacancacontrattuale = 'N',lt = {ts '2022-01-24 16:49:29.983'},lu = 'ferdinando.giannetti{DIRGEN}',oremaxcompitididatempoparziale = null,oremaxcompitididatempopieno = null,oremaxdidatempoparziale = null,oremaxdidatempopieno = null,oremaxgg = null,oremaxtempoparziale = null,oremaxtempopieno = '1720',oremincompitididatempoparziale = null,oremincompitididatempopieno = null,oremindidatempoparziale = null,oremindidatempopieno = null,oremintempoparziale = null,oremintempopieno = null,orestraordinariemax = null,parttime = 'N',puntiorganico = '1.5',scatto = 'S',siglaesportazione = 'DG',siglaimportazione = 'DG',sortcode = '0',tempdef = 'N',title = 'Direttore generale',totaletredicesima = 'S',tredicesimaindennitaintegrativaspeciale = 'N' WHERE idcontrattokind = '22'
ELSE
INSERT INTO [contrattokind] (idcontrattokind,active,assegnoaggiuntivo,costolordoannuo,costolordoannuooneri,ct,cu,description,elementoperequativo,indennitadiateneo,indennitadiposizione,indvacancacontrattuale,lt,lu,oremaxcompitididatempoparziale,oremaxcompitididatempopieno,oremaxdidatempoparziale,oremaxdidatempopieno,oremaxgg,oremaxtempoparziale,oremaxtempopieno,oremincompitididatempoparziale,oremincompitididatempopieno,oremindidatempoparziale,oremindidatempopieno,oremintempoparziale,oremintempopieno,orestraordinariemax,parttime,puntiorganico,scatto,siglaesportazione,siglaimportazione,sortcode,tempdef,title,totaletredicesima,tredicesimaindennitaintegrativaspeciale) VALUES ('22','S','N',null,null,{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,'N','N','N','N',{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,null,null,null,null,null,'1720',null,null,null,null,null,null,null,'N','1.5','S','DG','DG','0','N','Direttore generale','S','N')
GO

IF exists(SELECT * FROM [contrattokind] WHERE idcontrattokind = '23')
UPDATE [contrattokind] SET active = 'S',assegnoaggiuntivo = 'N',costolordoannuo = null,costolordoannuooneri = null,ct = {ts '2022-01-24 16:49:29.983'},cu = 'ferdinando.giannetti{DIRGEN}',description = null,elementoperequativo = 'N',indennitadiateneo = 'N',indennitadiposizione = 'N',indvacancacontrattuale = 'N',lt = {ts '2022-01-24 16:49:29.983'},lu = 'ferdinando.giannetti{DIRGEN}',oremaxcompitididatempoparziale = null,oremaxcompitididatempopieno = null,oremaxdidatempoparziale = null,oremaxdidatempopieno = null,oremaxgg = null,oremaxtempoparziale = null,oremaxtempopieno = '1720',oremincompitididatempoparziale = null,oremincompitididatempopieno = null,oremindidatempoparziale = null,oremindidatempopieno = null,oremintempoparziale = null,oremintempopieno = null,orestraordinariemax = null,parttime = 'N',puntiorganico = null,scatto = 'S',siglaesportazione = 'LC',siglaimportazione = 'LC',sortcode = '0',tempdef = 'N',title = 'Collaboratore esperto linguistico',totaletredicesima = 'S',tredicesimaindennitaintegrativaspeciale = 'N' WHERE idcontrattokind = '23'
ELSE
INSERT INTO [contrattokind] (idcontrattokind,active,assegnoaggiuntivo,costolordoannuo,costolordoannuooneri,ct,cu,description,elementoperequativo,indennitadiateneo,indennitadiposizione,indvacancacontrattuale,lt,lu,oremaxcompitididatempoparziale,oremaxcompitididatempopieno,oremaxdidatempoparziale,oremaxdidatempopieno,oremaxgg,oremaxtempoparziale,oremaxtempopieno,oremincompitididatempoparziale,oremincompitididatempopieno,oremindidatempoparziale,oremindidatempopieno,oremintempoparziale,oremintempopieno,orestraordinariemax,parttime,puntiorganico,scatto,siglaesportazione,siglaimportazione,sortcode,tempdef,title,totaletredicesima,tredicesimaindennitaintegrativaspeciale) VALUES ('23','S','N',null,null,{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,'N','N','N','N',{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,null,null,null,null,null,'1720',null,null,null,null,null,null,null,'N',null,'S','LC','LC','0','N','Collaboratore esperto linguistico','S','N')
GO

IF EXISTS(select * from [dbo].[metadatamanagedtable] where [tablename] = 'pcsassunzionisimulatedefaultview')
BEGIN 
	DELETE [dbo].[metadataprimarykey] WHERE [tablename] = 'pcsassunzionisimulatedefaultview'
	DELETE [dbo].[metadatastaticfilter] WHERE [tablename] = 'pcsassunzionisimulatedefaultview'
	DELETE [dbo].[metadatasorting] WHERE [tablename] = 'pcsassunzionisimulatedefaultview'
	DELETE [dbo].[metadatamanagedtable]  WHERE [tablename] = 'pcsassunzionisimulatedefaultview'
END
GO