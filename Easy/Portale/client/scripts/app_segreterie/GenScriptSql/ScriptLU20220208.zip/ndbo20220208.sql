--setuser 'amministrazione'
-- CREAZIONE VISTA strutturaperfelenchiview
IF EXISTS(select * from sysobjects where id = object_id(N'[strutturaperfelenchiview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [strutturaperfelenchiview]
GO

CREATE VIEW [strutturaperfelenchiview] AS 
SELECT  struttura.codice AS struttura_codice, struttura.codiceipa AS struttura_codiceipa, struttura.ct AS struttura_ct, struttura.cu AS struttura_cu, struttura.email AS struttura_email, struttura.fax AS struttura_fax,
 [dbo].aoo.title AS aoo_title, struttura.idaoo AS struttura_idaoo, struttura.idreg AS struttura_idreg,
 [dbo].sede.title AS sede_title, struttura.idsede AS struttura_idsede, struttura.idstruttura,
 [dbo].strutturakind.title AS strutturakind_title, struttura.idstrutturakind AS struttura_idstrutturakind,
 upb.title AS upb_title, struttura.idupb, struttura.lt AS struttura_lt, struttura.lu AS struttura_lu,
 strutturaparent.title AS strutturaparent_title, struttura.paridstruttura, struttura.pesoindicatori AS struttura_pesoindicatori, struttura.pesoobiettivi AS struttura_pesoobiettivi, struttura.pesoprogaltreuo AS struttura_pesoprogaltreuo, struttura.pesoproguo AS struttura_pesoproguo, struttura.telefono AS struttura_telefono, struttura.title, struttura.title_en AS struttura_title_en,
 isnull('Denominazione: ' + struttura.title + '; ','') + ' ' + isnull('U.O. madre: ' + strutturaparent.title + '; ','') as dropdown_title
FROM [dbo].struttura WITH (NOLOCK) 
LEFT OUTER JOIN [dbo].aoo WITH (NOLOCK) ON struttura.idaoo = [dbo].aoo.idaoo
LEFT OUTER JOIN [dbo].sede WITH (NOLOCK) ON struttura.idsede = [dbo].sede.idsede
LEFT OUTER JOIN [dbo].strutturakind WITH (NOLOCK) ON struttura.idstrutturakind = [dbo].strutturakind.idstrutturakind
LEFT OUTER JOIN upb WITH (NOLOCK) ON struttura.idupb = upb.idupb
LEFT OUTER JOIN [dbo].struttura AS strutturaparent WITH (NOLOCK) ON struttura.paridstruttura = strutturaparent.idstruttura
WHERE  struttura.idstruttura IS NOT NULL 
GO

-----------------------------------------------------
IF EXISTS(select * from menuweb where idmenuweb = 475)
BEGIN
	--exec menuweb_addentry @idmenuwebparent = 86, @idx = 42, @tableName = 'registry', @editType = 'default', @label = 'Anagrafica generale';
	exec EraseSecureVariable 'mr_475'
	exec EraseSecureVariable 'mw_475'
	delete menuweb where idmenuweb = 475
END
GO
--------------------------------------------------------