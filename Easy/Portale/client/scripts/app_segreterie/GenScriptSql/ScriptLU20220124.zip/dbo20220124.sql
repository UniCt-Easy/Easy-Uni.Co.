-- CREAZIONE TABELLA contrattokind --
IF NOT EXISTS(select * from sysobjects where id = object_id(N'[dbo].[contrattokind]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[contrattokind] (
idcontrattokind int NOT NULL,
active char(1) NOT NULL,
assegnoaggiuntivo char(1) NULL,
costolordoannuo decimal(9,2) NULL,
costolordoannuooneri decimal(9,2) NULL,
ct datetime NOT NULL,
cu varchar(64) NOT NULL,
description varchar(256) NULL,
elementoperequativo char(1) NULL,
indennitadiateneo char(1) NULL,
indennitadiposizione char(1) NULL,
indvacancacontrattuale char(1) NULL,
lt datetime NOT NULL,
lu varchar(64) NOT NULL,
oremaxcompitididatempoparziale int NULL,
oremaxcompitididatempopieno int NULL,
oremaxdidatempoparziale int NULL,
oremaxdidatempopieno int NULL,
oremaxgg int NULL,
oremaxtempoparziale int NULL,
oremaxtempopieno int NULL,
oremincompitididatempoparziale int NULL,
oremincompitididatempopieno int NULL,
oremindidatempoparziale int NULL,
oremindidatempopieno int NULL,
oremintempoparziale int NULL,
oremintempopieno int NULL,
orestraordinariemax int NULL,
parttime char(1) NULL,
puntiorganico decimal(9,2) NULL,
scatto char(1) NULL,
siglaesportazione varchar(10) NULL,
siglaimportazione varchar(1024) NULL,
sortcode int NOT NULL,
tempdef char(1) NULL,
title varchar(50) NOT NULL,
totaletredicesima char(1) NULL,
tredicesimaindennitaintegrativaspeciale char(1) NULL,
 CONSTRAINT xpkcontrattokind PRIMARY KEY (idcontrattokind
)
)
END
GO

-- VERIFICA STRUTTURA contrattokind --
IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'idcontrattokind' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD idcontrattokind int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'idcontrattokind' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'active' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD active char(1) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'active' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN active char(1) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'assegnoaggiuntivo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD assegnoaggiuntivo char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN assegnoaggiuntivo char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'costolordoannuo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD costolordoannuo decimal(9,2) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN costolordoannuo decimal(9,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'costolordoannuooneri' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD costolordoannuooneri decimal(9,2) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN costolordoannuooneri decimal(9,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'ct' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD ct datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'ct' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN ct datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'cu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD cu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'cu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN cu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'description' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD description varchar(256) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN description varchar(256) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'elementoperequativo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD elementoperequativo char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN elementoperequativo char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'indennitadiateneo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD indennitadiateneo char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN indennitadiateneo char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'indennitadiposizione' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD indennitadiposizione char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN indennitadiposizione char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'indvacancacontrattuale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD indvacancacontrattuale char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN indvacancacontrattuale char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'lt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD lt datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'lt' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN lt datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'lu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD lu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'lu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN lu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxcompitididatempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxcompitididatempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxcompitididatempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxcompitididatempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxcompitididatempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxcompitididatempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxdidatempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxdidatempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxdidatempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxdidatempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxdidatempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxdidatempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxgg' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxgg int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxgg int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxtempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxtempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxtempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremaxtempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremaxtempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremaxtempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremincompitididatempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremincompitididatempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremincompitididatempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremincompitididatempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremincompitididatempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremincompitididatempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremindidatempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremindidatempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremindidatempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremindidatempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremindidatempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremindidatempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremintempoparziale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremintempoparziale int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremintempoparziale int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'oremintempopieno' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD oremintempopieno int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN oremintempopieno int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'orestraordinariemax' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD orestraordinariemax int NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN orestraordinariemax int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'parttime' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD parttime char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN parttime char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'puntiorganico' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD puntiorganico decimal(9,2) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN puntiorganico decimal(9,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'scatto' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD scatto char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN scatto char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'siglaesportazione' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD siglaesportazione varchar(10) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN siglaesportazione varchar(10) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'siglaimportazione' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD siglaimportazione varchar(1024) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN siglaimportazione varchar(1024) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'sortcode' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD sortcode int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'sortcode' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN sortcode int NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'tempdef' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD tempdef char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN tempdef char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'title' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD title varchar(50) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('contrattokind') and col.name = 'title' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [contrattokind] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN title varchar(50) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'totaletredicesima' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD totaletredicesima char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN totaletredicesima char(1) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'contrattokind' and C.name = 'tredicesimaindennitaintegrativaspeciale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [contrattokind] ADD tredicesimaindennitaintegrativaspeciale char(1) NULL 
END
ELSE
	ALTER TABLE [contrattokind] ALTER COLUMN tredicesimaindennitaintegrativaspeciale char(1) NULL
GO




-- CREAZIONE TABELLA analisiannuale --
IF NOT EXISTS(select * from sysobjects where id = object_id(N'[dbo].[analisiannuale]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[analisiannuale] (
idanalisiannuale int NOT NULL,
contrattiincarichiinsegnamento0 decimal(19,2) NULL,
contrattiincarichiinsegnamento1 decimal(19,2) NULL,
contrattiincarichiinsegnamento2 decimal(19,2) NULL,
contrattiincarichiinsegnamento3 decimal(19,2) NULL,
costopt decimal(19,2) NULL,
ct datetime NULL,
cu varchar(64) NULL,
ffo0 decimal(19,2) NULL,
ffo1 decimal(19,2) NULL,
ffo2 decimal(19,2) NULL,
ffo3 decimal(19,2) NULL,
finanzesternicontrattiincarichiinsegnamento0 decimal(19,2) NULL,
finanzesternicontrattiincarichiinsegnamento1 decimal(19,2) NULL,
finanzesternicontrattiincarichiinsegnamento2 decimal(19,2) NULL,
finanzesternicontrattiincarichiinsegnamento3 decimal(19,2) NULL,
finanzesternidirPTA0 decimal(19,2) NULL,
finanzesternidirPTA1 decimal(19,2) NULL,
finanzesternidirPTA2 decimal(19,2) NULL,
finanzesternidirPTA3 decimal(19,2) NULL,
finanzesternidocenti0 decimal(19,2) NULL,
finanzesternidocenti1 decimal(19,2) NULL,
finanzesternidocenti2 decimal(19,2) NULL,
finanzesternidocenti3 decimal(19,2) NULL,
fondocontrattazioneintegrativa0 decimal(19,2) NULL,
fondocontrattazioneintegrativa1 decimal(19,2) NULL,
fondocontrattazioneintegrativa2 decimal(19,2) NULL,
fondocontrattazioneintegrativa3 decimal(19,2) NULL,
incrementodocenti1 decimal(19,2) NULL,
incrementodocenti2 decimal(19,2) NULL,
incrementodocenti3 decimal(19,2) NULL,
lt datetime NULL,
lu varchar(64) NULL,
programmazionetriennale0 decimal(19,2) NULL,
programmazionetriennale1 decimal(19,2) NULL,
programmazionetriennale2 decimal(19,2) NULL,
programmazionetriennale3 decimal(19,2) NULL,
speseDG0 decimal(19,2) NULL,
speseDG1 decimal(19,2) NULL,
speseDG2 decimal(19,2) NULL,
speseDG3 decimal(19,2) NULL,
spesedirPTA0 decimal(19,2) NULL,
spesedirPTA1 decimal(19,2) NULL,
spesedirPTA2 decimal(19,2) NULL,
spesedirPTA3 decimal(19,2) NULL,
spesedocenti0 decimal(19,2) NULL,
spesedocenti1 decimal(19,2) NULL,
spesedocenti2 decimal(19,2) NULL,
spesedocenti3 decimal(19,2) NULL,
speseriduzione0 decimal(19,2) NULL,
speseriduzione1 decimal(19,2) NULL,
speseriduzione2 decimal(19,2) NULL,
speseriduzione3 decimal(19,2) NULL,
tasse0 decimal(19,2) NULL,
tasse1 decimal(19,2) NULL,
tasse2 decimal(19,2) NULL,
tasse3 decimal(19,2) NULL,
totspesepersonalecaricoateneo0 decimal(19,2) NULL,
totspesepersonalecaricoateneo1 decimal(19,2) NULL,
totspesepersonalecaricoateneo2 decimal(19,2) NULL,
totspesepersonalecaricoateneo3 decimal(19,2) NULL,
trattamentostipintegrativoCEL0 decimal(19,2) NULL,
trattamentostipintegrativoCEL1 decimal(19,2) NULL,
trattamentostipintegrativoCEL2 decimal(19,2) NULL,
trattamentostipintegrativoCEL3 decimal(19,2) NULL,
year int NOT NULL,
 CONSTRAINT xpkanalisiannuale PRIMARY KEY (idanalisiannuale
)
)
END
GO

-- VERIFICA STRUTTURA analisiannuale --
IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'idanalisiannuale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD idanalisiannuale int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('analisiannuale') and col.name = 'idanalisiannuale' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [analisiannuale] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'contrattiincarichiinsegnamento0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD contrattiincarichiinsegnamento0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN contrattiincarichiinsegnamento0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'contrattiincarichiinsegnamento1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD contrattiincarichiinsegnamento1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN contrattiincarichiinsegnamento1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'contrattiincarichiinsegnamento2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD contrattiincarichiinsegnamento2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN contrattiincarichiinsegnamento2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'contrattiincarichiinsegnamento3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD contrattiincarichiinsegnamento3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN contrattiincarichiinsegnamento3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'costopt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD costopt decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN costopt decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'ct' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD ct datetime NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN ct datetime NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'cu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD cu varchar(64) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN cu varchar(64) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'ffo0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD ffo0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN ffo0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'ffo1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD ffo1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN ffo1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'ffo2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD ffo2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN ffo2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'ffo3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD ffo3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN ffo3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternicontrattiincarichiinsegnamento0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternicontrattiincarichiinsegnamento0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternicontrattiincarichiinsegnamento0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternicontrattiincarichiinsegnamento1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternicontrattiincarichiinsegnamento1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternicontrattiincarichiinsegnamento1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternicontrattiincarichiinsegnamento2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternicontrattiincarichiinsegnamento2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternicontrattiincarichiinsegnamento2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternicontrattiincarichiinsegnamento3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternicontrattiincarichiinsegnamento3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternicontrattiincarichiinsegnamento3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidirPTA0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidirPTA0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidirPTA0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidirPTA1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidirPTA1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidirPTA1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidirPTA2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidirPTA2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidirPTA2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidirPTA3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidirPTA3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidirPTA3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidocenti0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidocenti0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidocenti0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidocenti1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidocenti1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidocenti1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidocenti2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidocenti2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidocenti2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'finanzesternidocenti3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD finanzesternidocenti3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN finanzesternidocenti3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'fondocontrattazioneintegrativa0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD fondocontrattazioneintegrativa0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN fondocontrattazioneintegrativa0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'fondocontrattazioneintegrativa1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD fondocontrattazioneintegrativa1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN fondocontrattazioneintegrativa1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'fondocontrattazioneintegrativa2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD fondocontrattazioneintegrativa2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN fondocontrattazioneintegrativa2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'fondocontrattazioneintegrativa3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD fondocontrattazioneintegrativa3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN fondocontrattazioneintegrativa3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'incrementodocenti1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD incrementodocenti1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN incrementodocenti1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'incrementodocenti2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD incrementodocenti2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN incrementodocenti2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'incrementodocenti3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD incrementodocenti3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN incrementodocenti3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'lt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD lt datetime NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN lt datetime NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'lu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD lu varchar(64) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN lu varchar(64) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'programmazionetriennale0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD programmazionetriennale0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN programmazionetriennale0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'programmazionetriennale1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD programmazionetriennale1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN programmazionetriennale1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'programmazionetriennale2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD programmazionetriennale2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN programmazionetriennale2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'programmazionetriennale3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD programmazionetriennale3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN programmazionetriennale3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseDG0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseDG0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseDG0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseDG1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseDG1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseDG1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseDG2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseDG2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseDG2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseDG3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseDG3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseDG3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedirPTA0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedirPTA0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedirPTA0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedirPTA1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedirPTA1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedirPTA1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedirPTA2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedirPTA2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedirPTA2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedirPTA3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedirPTA3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedirPTA3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedocenti0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedocenti0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedocenti0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedocenti1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedocenti1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedocenti1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedocenti2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedocenti2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedocenti2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'spesedocenti3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD spesedocenti3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN spesedocenti3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseriduzione0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseriduzione0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseriduzione0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseriduzione1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseriduzione1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseriduzione1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseriduzione2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseriduzione2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseriduzione2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'speseriduzione3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD speseriduzione3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN speseriduzione3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'tasse0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD tasse0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN tasse0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'tasse1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD tasse1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN tasse1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'tasse2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD tasse2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN tasse2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'tasse3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD tasse3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN tasse3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'totspesepersonalecaricoateneo0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD totspesepersonalecaricoateneo0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN totspesepersonalecaricoateneo0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'totspesepersonalecaricoateneo1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD totspesepersonalecaricoateneo1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN totspesepersonalecaricoateneo1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'totspesepersonalecaricoateneo2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD totspesepersonalecaricoateneo2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN totspesepersonalecaricoateneo2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'totspesepersonalecaricoateneo3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD totspesepersonalecaricoateneo3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN totspesepersonalecaricoateneo3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'trattamentostipintegrativoCEL0' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD trattamentostipintegrativoCEL0 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN trattamentostipintegrativoCEL0 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'trattamentostipintegrativoCEL1' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD trattamentostipintegrativoCEL1 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN trattamentostipintegrativoCEL1 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'trattamentostipintegrativoCEL2' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD trattamentostipintegrativoCEL2 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN trattamentostipintegrativoCEL2 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'trattamentostipintegrativoCEL3' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD trattamentostipintegrativoCEL3 decimal(19,2) NULL 
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN trattamentostipintegrativoCEL3 decimal(19,2) NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'analisiannuale' and C.name = 'year' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [analisiannuale] ADD year int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('analisiannuale') and col.name = 'year' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [analisiannuale] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [analisiannuale] ALTER COLUMN year int NOT NULL
GO

-- CREAZIONE TABELLA perfvalutazionepersonaleattach --
IF NOT EXISTS(select * from sysobjects where id = object_id(N'[dbo].[perfvalutazionepersonaleattach]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[perfvalutazionepersonaleattach] (
idperfvalutazionepersonaleattach int NOT NULL,
idperfvalutazionepersonale int NOT NULL,
ct datetime NOT NULL,
cu varchar(64) NOT NULL,
idattach int NULL,
lt datetime NOT NULL,
lu varchar(64) NOT NULL,
 CONSTRAINT xpkperfvalutazionepersonaleattach PRIMARY KEY (idperfvalutazionepersonaleattach,
idperfvalutazionepersonale
)
)
END
GO

-- VERIFICA STRUTTURA perfvalutazionepersonaleattach --
IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'idperfvalutazionepersonaleattach' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD idperfvalutazionepersonaleattach int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'idperfvalutazionepersonaleattach' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'idperfvalutazionepersonale' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD idperfvalutazionepersonale int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'idperfvalutazionepersonale' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'ct' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD ct datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'ct' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazionepersonaleattach] ALTER COLUMN ct datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'cu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD cu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'cu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazionepersonaleattach] ALTER COLUMN cu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'idattach' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD idattach int NULL 
END
ELSE
	ALTER TABLE [perfvalutazionepersonaleattach] ALTER COLUMN idattach int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'lt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD lt datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'lt' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazionepersonaleattach] ALTER COLUMN lt datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazionepersonaleattach' and C.name = 'lu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazionepersonaleattach] ADD lu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazionepersonaleattach') and col.name = 'lu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazionepersonaleattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazionepersonaleattach] ALTER COLUMN lu varchar(64) NOT NULL
GO

-- CREAZIONE TABELLA perfvalutazioneuoattach --
IF NOT EXISTS(select * from sysobjects where id = object_id(N'[dbo].[perfvalutazioneuoattach]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
CREATE TABLE [dbo].[perfvalutazioneuoattach] (
idperfvalutazioneuoattach int NOT NULL,
idperfvalutazioneuo int NOT NULL,
ct datetime NOT NULL,
cu varchar(64) NOT NULL,
idattach int NULL,
lt datetime NOT NULL,
lu varchar(64) NOT NULL,
 CONSTRAINT xpkperfvalutazioneuoattach PRIMARY KEY (idperfvalutazioneuoattach,
idperfvalutazioneuo
)
)
END
GO

-- VERIFICA STRUTTURA perfvalutazioneuoattach --
IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'idperfvalutazioneuoattach' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD idperfvalutazioneuoattach int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'idperfvalutazioneuoattach' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'idperfvalutazioneuo' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD idperfvalutazioneuo int NOT NULL DEFAULT 0
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'idperfvalutazioneuo' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'ct' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD ct datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'ct' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazioneuoattach] ALTER COLUMN ct datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'cu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD cu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'cu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazioneuoattach] ALTER COLUMN cu varchar(64) NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'idattach' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD idattach int NULL 
END
ELSE
	ALTER TABLE [perfvalutazioneuoattach] ALTER COLUMN idattach int NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'lt' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD lt datetime NOT NULL DEFAULT 01/01/1000
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'lt' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazioneuoattach] ALTER COLUMN lt datetime NOT NULL
GO

IF NOT exists(select * from [sysobjects] as T inner join syscolumns C on T.ID = C.ID where t.name = 'perfvalutazioneuoattach' and C.name = 'lu' AND (T.uid = USER_ID( ) OR T.uid = USER_ID('dbo')))
BEGIN
	ALTER TABLE [perfvalutazioneuoattach] ADD lu varchar(64) NOT NULL DEFAULT ''
	declare @vincolo varchar(100)
	select @vincolo = object_name(const.constid) from syscolumns col join sysconstraints const on const.id = col.id and const.colid = col.colid where col.id = object_id('perfvalutazioneuoattach') and col.name = 'lu' and objectproperty(const.constid, 'IsDefaultCnst')=1
	exec ('ALTER TABLE [perfvalutazioneuoattach] drop constraint '+@vincolo)
END
ELSE
	ALTER TABLE [perfvalutazioneuoattach] ALTER COLUMN lu varchar(64) NOT NULL
GO



-- CREAZIONE VISTA pcspuntiorganicoview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[pcspuntiorganicoview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[pcspuntiorganicoview]
GO



CREATE VIEW [dbo].[pcspuntiorganicoview]
AS
SELECT *
FROM   (SELECT annoelab AS year,
               contrattokind_title,isdoc,
               DATA,
               CONCAT(COLUMN_NAME,
					  CASE annorif WHEN annoelab THEN 0
								   WHEN annoelab+1 THEN 1
								   WHEN annoelab+2 THEN 2
								   WHEN annoelab+3 THEN 3
								   END
			   ) AS PIV_COL
        FROM   (
------------------------------------	
		select annoelab, 
				 annorif,
				 contrattokind_title,
				 SUM(puntipiu) AS puntipiu,
				 SUM(puntimeno) as puntimeno,
				 SUM(importo) AS importo,
				 sum(importoateneo) as importoateneo,
				 sum(importoesterno) as importoesterno,
				 isdoc
				 from (
		
		------------------------assunzioni----------------------------		
SELECT  annoelab, 
				 annorif,
				 contrattokind_title,
				SUM(puntiorganico) AS puntipiu,
				 puntimeno,
				SUM(totale) AS importo,
				SUM(totaleateneo) AS importoateneo,
				SUM(totaleesterno) AS importoesterno,
				isdoc
				from (
						----------------- annoelab = annorif----------------------
				
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale * isnull(numeropersoneassunzione,1) as totale,
				totale * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzioni.data
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind  ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year = YEAR(pcsassunzioni.data)
				-----------------------------+1
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +1 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale1 * isnull(numeropersoneassunzione,1) as totale1,
				totale1 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale1 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				--,pcsassunzioni.data,dbo.pcsassunzioni.year+1
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)
				
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+1 = YEAR(pcsassunzioni.data)				

				-------------------+2
						UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +2 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale2 * isnull(numeropersoneassunzione,1) as totale2,
				totale2 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale2 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data)
				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+2 = YEAR(pcsassunzioni.data)		
				---------------------+3

				UNION 
				SELECT dbo.pcsassunzioni.year AS annoelab, 
				dbo.pcsassunzioni.year +3 AS annorif,
				ck.title AS contrattokind_title,
				CASE WHEN dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data) THEN puntiorganico * isnull(numeropersoneassunzione,1) ELSE 0 END as puntiorganico,
				0 AS puntimeno,
				totale3 * isnull(numeropersoneassunzione,1) as totale3,
				totale3 * isnull(numeropersoneassunzione,1) * isnull(percentuale,100) / 100 as totaleateneo,
				totale3 * isnull(numeropersoneassunzione,1) * (100 - isnull(percentuale,100)) / 100 as totaleesterno,
				isnull(ck.tempdef,'N') as isdoc
				FROM dbo.pcsassunzioni
				JOIN dbo.contrattokind ck ON ck.idcontrattokind = pcsassunzioni.idcontrattokind
				WHERE dbo.pcsassunzioni.year+3 = YEAR(pcsassunzioni.data)		

				) zz

				GROUP BY contrattokind_title, annoelab, annorif,puntimeno, isdoc		
				
				---------------------------------------------
				UNION

				---------------stipendioannuo ------------------------

				SELECT * from (
				

						select
						annoelab ,
						annorif,
						title,
						puntipiu,
						sum(puntimeno) as puntimeno,
						sum(importo) as importo,
						sum(importoateneo) as importoateneo,
						sum(importoesterno) as importoesterno,
						isdoc
						from (

						----------------- annoelab = annorif----------------------

						select 
						sa.idstipendioannuo,
						aa.year as annoelab ,
						sa.year as annorif,
						ck.title,
						0 as puntipiu,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END)   
						ELSE 0 END as importo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END) * isnull(c.percentualesufondiateneo,100) /100 
						ELSE 0 END as importoateneo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
						ELSE 0 END as importoesterno,
						isnull(ck.tempdef,'N') as isdoc
						from analisiannuale aa
						inner join stipendioannuo sa on sa.year= aa.year 
						inner join contratto c on c.idcontratto = sa.idcontratto
						inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind
						
						UNION
						-----------------------------+1

						select 
						sa.idstipendioannuo,
						aa.year as annoelab ,
						sa.year+1 as annorif,
						ck.title,
						0 as puntipiu,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+1 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN 
							CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)   ELSE sa.totale END  
						ELSE 0 END as importo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END) * isnull(c.percentualesufondiateneo,100) /100 
						ELSE 0 END as importoateneo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+1 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100)) /100)  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
						ELSE 0 END as importoesterno,
						isnull(ck.tempdef,'N') as isdoc
						from analisiannuale aa
						inner join stipendioannuo sa on sa.year= aa.year 
						inner join contratto c on c.idcontratto = sa.idcontratto
						inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind

						UNION
						-----------------------------+2

						select 
						sa.idstipendioannuo,
						aa.year as annoelab ,
						sa.year+2 as annorif,
						ck.title,
						0 as puntipiu,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+2 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN 
							CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)/100)  ELSE sa.totale END  
						ELSE 0 END as importo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100))* ((aa.incrementodocenti2 + 100)/100) /100)  ELSE sa.totale END) * isnull(c.percentualesufondiateneo,100) /100 
						ELSE 0 END as importoateneo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+2 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100))* ((aa.incrementodocenti2 + 100)/100) /100)  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
						ELSE 0 END as importoesterno,
						isnull(ck.tempdef,'N') as isdoc
						from analisiannuale aa
						inner join stipendioannuo sa on sa.year= aa.year 
						inner join contratto c on c.idcontratto = sa.idcontratto
						inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind

						UNION
						-----------------------------+3

						select 
						sa.idstipendioannuo,
						aa.year as annoelab ,
						sa.year+3 as annorif,
						ck.title,
						0 as puntipiu,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) = sa.year+3 THEN ((isnull(ck.puntiorganico,0) /100) * isnull(c.percentualesufondiateneo,100)) ELSE 0 END as puntimeno,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN 
							CASE WHEN ck.tempdef = 'S' THEN (sa.totale * ((aa.incrementodocenti1 + 100)/100)* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100)/100)  ELSE sa.totale END  
						ELSE 0 END as importo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100))* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100) /100)  ELSE sa.totale END) * isnull(c.percentualesufondiateneo,100) /100 
						ELSE 0 END as importoateneo,
						CASE WHEN isnull(YEAR(c.stop),sa.year+4) > sa.year+3 THEN 
							(CASE WHEN ck.tempdef = 'S' THEN ((sa.totale * ((aa.incrementodocenti1 + 100)/100))* ((aa.incrementodocenti2 + 100)/100)* ((aa.incrementodocenti3 + 100)/100) /100)  ELSE sa.totale END) * (100 - isnull(c.percentualesufondiateneo,100) )/100 
						ELSE 0 END as importoesterno,
						isnull(ck.tempdef,'N') as isdoc
						from analisiannuale aa
						inner join stipendioannuo sa on sa.year= aa.year 
						inner join contratto c on c.idcontratto = sa.idcontratto
						inner join contrattokind ck on ck.idcontrattokind = c.idcontrattokind


						) ss

						group by annoelab ,
						annorif,
						title,
						puntipiu,
						isdoc
				
				) tbl1

				) tbl2
				 group by annoelab, 
				 annorif,
				 contrattokind_title,isdoc
				 --order by contrattokind_title,annoelab, annorif
				------------------------------------------------------
				
	) AS GROUPED_VIEW
       CROSS APPLY (VALUES ('puntipiu',puntipiu),
						   ('puntimeno',puntimeno),
                           ('importo',importo),
                           ('importoateneo',importoateneo),
                           ('importoesterno',importoesterno)
						   ) CS(COLUMN_NAME, DATA)) A
       PIVOT (SUM(DATA)
             FOR PIV_COL IN([puntipiu0],
							[puntimeno0],
                            [importo0],
                            [importoateneo0],
                            [importoesterno0],
                            [puntipiu1],
							[puntimeno1],
                            [importo1],
                            [importoateneo1],
                            [importoesterno1],
                            [puntipiu2],
							[puntimeno2],
                            [importo2],
                            [importoateneo2],
                            [importoesterno2],
							[puntipiu3],
							[puntimeno3],
                            [importo3],
                            [importoateneo3],
                            [importoesterno3]
							)) PV



GO

-- CREAZIONE VISTA registrypersoneview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[registrypersoneview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[registrypersoneview]
GO

CREATE VIEW [dbo].[registrypersoneview] AS 
SELECT CASE WHEN registry.active = 'S' THEN 'Si' WHEN registry.active = 'N' THEN 'No' END AS registry_active, registry.annotation AS registry_annotation,CASE WHEN registry.authorization_free = 'S' THEN 'Si' WHEN registry.authorization_free = 'N' THEN 'No' END AS registry_authorization_free, registry.badgecode AS registry_badgecode, registry.birthdate AS registry_birthdate, registry.ccp AS registry_ccp, registry.cf AS registry_cf, registry.ct AS registry_ct, registry.cu AS registry_cu, registry.email_fe AS registry_email_fe, registry.extension AS registry_extension, registry.extmatricula,CASE WHEN registry.flag_pa = 'S' THEN 'Si' WHEN registry.flag_pa = 'N' THEN 'No' END AS registry_flag_pa,CASE WHEN registry.flagbankitaliaproceeds = 'S' THEN 'Si' WHEN registry.flagbankitaliaproceeds = 'N' THEN 'No' END AS registry_flagbankitaliaproceeds, registry.foreigncf AS registry_foreigncf, registry.forename AS registry_forename,CASE WHEN registry.gender = 'S' THEN 'Si' WHEN registry.gender = 'N' THEN 'No' END AS registry_gender,
 [dbo].accmotive.codemotive AS accmotive_codemotive, [dbo].accmotive.title AS accmotive_title, registry.idaccmotivecredit,
 accmotive_registry.codemotive AS accmotive_registry_codemotive, accmotive_registry.title AS accmotive_registry_title, registry.idaccmotivedebit,
 [dbo].category.description AS category_description, registry.idcategory,
 [dbo].centralizedcategory.description AS centralizedcategory_description, registry.idcentralizedcategory,
 [dbo].geo_city.title AS geo_city_title, registry.idcity, registry.idexternal AS registry_idexternal,
 [dbo].maritalstatus.description AS maritalstatus_description, registry.idmaritalstatus AS registry_idmaritalstatus,
 [dbo].geo_nation.title AS geo_nation_title, registry.idnation, registry.idreg,
 [dbo].registryclass.description AS registryclass_description, registry.idregistryclass,
 [dbo].registrykind.description AS registrykind_description, registry.idregistrykind AS registry_idregistrykind,
 [dbo].title.description AS title_description, registry.idtitle, registry.ipa_fe AS registry_ipa_fe, registry.ipa_perlapa AS registry_ipa_perlapa, registry.location AS registry_location, registry.lt AS registry_lt, registry.lu AS registry_lu, registry.maritalsurname AS registry_maritalsurname,CASE WHEN registry.multi_cf = 'S' THEN 'Si' WHEN registry.multi_cf = 'N' THEN 'No' END AS registry_multi_cf, registry.p_iva AS registry_p_iva, registry.pec_fe AS registry_pec_fe,
 [dbo].residence.description AS residence_description, registry.residence, registry.rtf AS registry_rtf, registry.sdi_defrifamm AS registry_sdi_defrifamm,CASE WHEN registry.sdi_norifamm = 'S' THEN 'Si' WHEN registry.sdi_norifamm = 'N' THEN 'No' END AS registry_sdi_norifamm, registry.surname AS registry_surname, registry.title AS registry_title, registry.toredirect AS registry_toredirect, registry.txt AS registry_txt,
 isnull('Matricola: ' + registry.extmatricula + '; ','') + ' ' + isnull('Cognome Nome: ' + registry.title + '; ','') + ' ' + isnull('Codice fiscale: ' + registry.cf + '; ','') + ' ' + isnull('Partita iva: ' + registry.p_iva + '; ','') as dropdown_title
FROM [dbo].registry WITH (NOLOCK) 
LEFT OUTER JOIN [dbo].accmotive WITH (NOLOCK) ON registry.idaccmotivecredit = [dbo].accmotive.idaccmotive
LEFT OUTER JOIN [dbo].accmotive AS accmotive_registry WITH (NOLOCK) ON registry.idaccmotivedebit = accmotive_registry.idaccmotive
LEFT OUTER JOIN [dbo].category WITH (NOLOCK) ON registry.idcategory = [dbo].category.idcategory
LEFT OUTER JOIN [dbo].centralizedcategory WITH (NOLOCK) ON registry.idcentralizedcategory = [dbo].centralizedcategory.idcentralizedcategory
LEFT OUTER JOIN [dbo].geo_city WITH (NOLOCK) ON registry.idcity = [dbo].geo_city.idcity
LEFT OUTER JOIN [dbo].maritalstatus WITH (NOLOCK) ON registry.idmaritalstatus = [dbo].maritalstatus.idmaritalstatus
LEFT OUTER JOIN [dbo].geo_nation WITH (NOLOCK) ON registry.idnation = [dbo].geo_nation.idnation
LEFT OUTER JOIN [dbo].registryclass WITH (NOLOCK) ON registry.idregistryclass = [dbo].registryclass.idregistryclass
LEFT OUTER JOIN [dbo].registrykind WITH (NOLOCK) ON registry.idregistrykind = [dbo].registrykind.idregistrykind
LEFT OUTER JOIN [dbo].title WITH (NOLOCK) ON registry.idtitle = [dbo].title.idtitle
LEFT OUTER JOIN [dbo].residence WITH (NOLOCK) ON registry.residence = [dbo].residence.idresidence
WHERE  registry.idreg IS NOT NULL 
GO

-- CREAZIONE VISTA inquadramentodefaultview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[inquadramentodefaultview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[inquadramentodefaultview]
GO

CREATE VIEW [dbo].[inquadramentodefaultview] AS 
SELECT  inquadramento.costolordoannuo AS inquadramento_costolordoannuo, inquadramento.costolordoannuooneri AS inquadramento_costolordoannuooneri, inquadramento.ct AS inquadramento_ct, inquadramento.cu AS inquadramento_cu, inquadramento.idcontrattokind, inquadramento.idinquadramento, inquadramento.lt AS inquadramento_lt, inquadramento.lu AS inquadramento_lu, inquadramento.siglaimportazione AS inquadramento_siglaimportazione, inquadramento.start AS inquadramento_start, inquadramento.stop AS inquadramento_stop,CASE WHEN inquadramento.tempdef = 'S' THEN 'Si' WHEN inquadramento.tempdef = 'N' THEN 'No' END AS inquadramento_tempdef, inquadramento.title,
 isnull('Denominazione: ' + inquadramento.title + '; ','') + ' ' + isnull('' + CASE WHEN inquadramento.tempdef = 'S' THEN 'Tempo definito' ELSE 'non Tempo definito' END,'') as dropdown_title
FROM [dbo].inquadramento WITH (NOLOCK) 
WHERE  inquadramento.idcontrattokind IS NOT NULL  AND inquadramento.idinquadramento IS NOT NULL 
GO


-- GENERAZIONE DATI PER inquadramentodefaultview --
-- CREAZIONE VISTA analisiannualedefaultview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[analisiannualedefaultview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[analisiannualedefaultview]
GO

CREATE VIEW [dbo].[analisiannualedefaultview] AS 
SELECT  analisiannuale.contrattiincarichiinsegnamento0 AS analisiannuale_contrattiincarichiinsegnamento0, analisiannuale.contrattiincarichiinsegnamento1 AS analisiannuale_contrattiincarichiinsegnamento1, analisiannuale.contrattiincarichiinsegnamento2 AS analisiannuale_contrattiincarichiinsegnamento2, analisiannuale.contrattiincarichiinsegnamento3 AS analisiannuale_contrattiincarichiinsegnamento3, analisiannuale.costopt AS analisiannuale_costopt, analisiannuale.ct AS analisiannuale_ct, analisiannuale.cu AS analisiannuale_cu, analisiannuale.ffo0 AS analisiannuale_ffo0, analisiannuale.ffo1 AS analisiannuale_ffo1, analisiannuale.ffo2 AS analisiannuale_ffo2, analisiannuale.ffo3 AS analisiannuale_ffo3, analisiannuale.finanzesternicontrattiincarichiinsegnamento0 AS analisiannuale_finanzesternicontrattiincarichiinsegnamento0, analisiannuale.finanzesternicontrattiincarichiinsegnamento1 AS analisiannuale_finanzesternicontrattiincarichiinsegnamento1, analisiannuale.finanzesternicontrattiincarichiinsegnamento2 AS analisiannuale_finanzesternicontrattiincarichiinsegnamento2, analisiannuale.finanzesternicontrattiincarichiinsegnamento3 AS analisiannuale_finanzesternicontrattiincarichiinsegnamento3, analisiannuale.finanzesternidirPTA0 AS analisiannuale_finanzesternidirPTA0, analisiannuale.finanzesternidirPTA1 AS analisiannuale_finanzesternidirPTA1, analisiannuale.finanzesternidirPTA2 AS analisiannuale_finanzesternidirPTA2, analisiannuale.finanzesternidirPTA3 AS analisiannuale_finanzesternidirPTA3, analisiannuale.finanzesternidocenti0 AS analisiannuale_finanzesternidocenti0, analisiannuale.finanzesternidocenti1 AS analisiannuale_finanzesternidocenti1, analisiannuale.finanzesternidocenti2 AS analisiannuale_finanzesternidocenti2, analisiannuale.finanzesternidocenti3 AS analisiannuale_finanzesternidocenti3, analisiannuale.fondocontrattazioneintegrativa0 AS analisiannuale_fondocontrattazioneintegrativa0, analisiannuale.fondocontrattazioneintegrativa1 AS analisiannuale_fondocontrattazioneintegrativa1, analisiannuale.fondocontrattazioneintegrativa2 AS analisiannuale_fondocontrattazioneintegrativa2, analisiannuale.fondocontrattazioneintegrativa3 AS analisiannuale_fondocontrattazioneintegrativa3, analisiannuale.idanalisiannuale, analisiannuale.incrementodocenti1 AS analisiannuale_incrementodocenti1, analisiannuale.incrementodocenti2 AS analisiannuale_incrementodocenti2, analisiannuale.incrementodocenti3 AS analisiannuale_incrementodocenti3, analisiannuale.lt AS analisiannuale_lt, analisiannuale.lu AS analisiannuale_lu, analisiannuale.programmazionetriennale0 AS analisiannuale_programmazionetriennale0, analisiannuale.programmazionetriennale1 AS analisiannuale_programmazionetriennale1, analisiannuale.programmazionetriennale2 AS analisiannuale_programmazionetriennale2, analisiannuale.programmazionetriennale3 AS analisiannuale_programmazionetriennale3, analisiannuale.speseDG0 AS analisiannuale_speseDG0, analisiannuale.speseDG1 AS analisiannuale_speseDG1, analisiannuale.speseDG2 AS analisiannuale_speseDG2, analisiannuale.speseDG3 AS analisiannuale_speseDG3, analisiannuale.spesedirPTA0 AS analisiannuale_spesedirPTA0, analisiannuale.spesedirPTA1 AS analisiannuale_spesedirPTA1, analisiannuale.spesedirPTA2 AS analisiannuale_spesedirPTA2, analisiannuale.spesedirPTA3 AS analisiannuale_spesedirPTA3, analisiannuale.spesedocenti0 AS analisiannuale_spesedocenti0, analisiannuale.spesedocenti1 AS analisiannuale_spesedocenti1, analisiannuale.spesedocenti2 AS analisiannuale_spesedocenti2, analisiannuale.spesedocenti3 AS analisiannuale_spesedocenti3, analisiannuale.speseriduzione0 AS analisiannuale_speseriduzione0, analisiannuale.speseriduzione1 AS analisiannuale_speseriduzione1, analisiannuale.speseriduzione2 AS analisiannuale_speseriduzione2, analisiannuale.speseriduzione3 AS analisiannuale_speseriduzione3, analisiannuale.tasse0 AS analisiannuale_tasse0, analisiannuale.tasse1 AS analisiannuale_tasse1, analisiannuale.tasse2 AS analisiannuale_tasse2, analisiannuale.tasse3 AS analisiannuale_tasse3, analisiannuale.totspesepersonalecaricoateneo0 AS analisiannuale_totspesepersonalecaricoateneo0, analisiannuale.totspesepersonalecaricoateneo1 AS analisiannuale_totspesepersonalecaricoateneo1, analisiannuale.totspesepersonalecaricoateneo2 AS analisiannuale_totspesepersonalecaricoateneo2, analisiannuale.totspesepersonalecaricoateneo3 AS analisiannuale_totspesepersonalecaricoateneo3, analisiannuale.trattamentostipintegrativoCEL0 AS analisiannuale_trattamentostipintegrativoCEL0, analisiannuale.trattamentostipintegrativoCEL1 AS analisiannuale_trattamentostipintegrativoCEL1, analisiannuale.trattamentostipintegrativoCEL2 AS analisiannuale_trattamentostipintegrativoCEL2, analisiannuale.trattamentostipintegrativoCEL3 AS analisiannuale_trattamentostipintegrativoCEL3, analisiannuale.year
FROM [dbo].analisiannuale WITH (NOLOCK) 
WHERE  analisiannuale.idanalisiannuale IS NOT NULL  AND analisiannuale.year IS NOT NULL 
GO

-- CREAZIONE VISTA contrattoprevview
IF EXISTS(select * from sysobjects where id = object_id(N'[dbo].[contrattoprevview]') and OBJECTPROPERTY(id, N'IsView') = 1)
DROP VIEW [dbo].[contrattoprevview]
GO

CREATE VIEW [dbo].[contrattoprevview] AS 
SELECT  contratto.classe AS contratto_classe, contratto.ct AS contratto_ct, contratto.cu AS contratto_cu, contratto.datarivalutazione AS contratto_datarivalutazione, contratto.estremibando AS contratto_estremibando, contratto.idcontratto,
 [dbo].contrattokind.title AS contrattokind_title, contratto.idcontrattokind,
 [dbo].inquadramento.title AS inquadramento_title, [dbo].inquadramento.tempdef AS inquadramento_tempdef, contratto.idinquadramento AS contratto_idinquadramento, contratto.idreg, contratto.lt AS contratto_lt, contratto.lu AS contratto_lu, contratto.parttime AS contratto_parttime, contratto.percentualesufondiateneo AS contratto_percentualesufondiateneo, contratto.scatto AS contratto_scatto, contratto.start AS contratto_start, contratto.stop AS contratto_stop,CASE WHEN contratto.tempdef = 'S' THEN 'Si' WHEN contratto.tempdef = 'N' THEN 'No' END AS contratto_tempdef,CASE WHEN contratto.tempindet = 'S' THEN 'Si' WHEN contratto.tempindet = 'N' THEN 'No' END AS contratto_tempindet,
 isnull('Tipologia di contratto: ' + [dbo].contrattokind.title + '; ','') + ' ' + isnull('Percentuale su fondi interni: ' + CAST( contratto.percentualesufondiateneo AS NVARCHAR(64)) + '; ','') + ' ' + isnull('Inquadramento: ' + [dbo].inquadramento.title + '; ','') + ' ' + isnull('Inquadramento: ' + [dbo].inquadramento.tempdef + '; ','') + ' ' + isnull('dal ' + CONVERT(VARCHAR, contratto.start, 103),'') + ' ' + isnull('al ' + CONVERT(VARCHAR, contratto.stop, 103),'') + ' ' + isnull('Part-time %: ' + CAST( contratto.parttime AS NVARCHAR(64)) + '; ','') as dropdown_title
FROM [dbo].contratto WITH (NOLOCK) 
LEFT OUTER JOIN [dbo].contrattokind WITH (NOLOCK) ON contratto.idcontrattokind = [dbo].contrattokind.idcontrattokind
LEFT OUTER JOIN [dbo].inquadramento WITH (NOLOCK) ON contratto.idinquadramento = [dbo].inquadramento.idinquadramento
WHERE  contratto.idcontratto IS NOT NULL  AND contratto.idreg IS NOT NULL 
GO
------------------------------------------------------------------------------
IF NOT EXISTS(SELECT * FROM [dbo].[metadatamanagedtable] WHERE [tablename] = 'incomedefaultview')
INSERT INTO [dbo].[metadatamanagedtable] ([tablename]) VALUES  ('incomedefaultview')
GO
IF NOT EXISTS(SELECT * FROM [dbo].[metadatamanagedtable] WHERE [tablename] = 'contrattoprevview')
INSERT INTO [dbo].[metadatamanagedtable] ([tablename]) VALUES  ('contrattoprevview')
GO
-----------
IF NOT EXISTS(SELECT * FROM [dbo].[metadataprimarykey] WHERE [tablename] = 'incomedefaultview')
INSERT INTO [dbo].[metadataprimarykey] ([tablename], [primarykey]) VALUES ('incomedefaultview', '"idinc"')
ELSE
UPDATE [dbo].[metadataprimarykey] SET [primarykey] = '"idinc"' WHERE [tablename] = 'incomedefaultview'
GO
IF NOT EXISTS(SELECT * FROM [dbo].[metadataprimarykey] WHERE [tablename] = 'contrattoprevview')
INSERT INTO [dbo].[metadataprimarykey] ([tablename], [primarykey]) VALUES ('contrattoprevview', '"idcontratto","idreg"')
ELSE
UPDATE [dbo].[metadataprimarykey] SET [primarykey] = '"idcontratto","idreg"' WHERE [tablename] = 'contrattoprevview'
GO

IF NOT EXISTS(SELECT * FROM [dbo].[metadatasorting] WHERE [tablename] = 'inquadramentodefaultview' AND [listtype] = 'default')
INSERT INTO [dbo].[metadatasorting] ([tablename], [listtype], [sorting]) VALUES ('inquadramentodefaultview', 'default', 'title desc')
ELSE 
UPDATE [dbo].[metadatasorting] SET [sorting] = 'title desc' WHERE [tablename] = 'inquadramentodefaultview' AND [listtype] = 'default'
GO

-------------------------


IF EXISTS(select * from [dbo].[metadatamanagedtable] where [tablename] = 'registrypersoneview')
BEGIN 
	DELETE [dbo].[metadataprimarykey] WHERE [tablename] = 'registrypersoneview'
	DELETE [dbo].[metadatastaticfilter] WHERE [tablename] = 'registrypersoneview'
	DELETE [dbo].[metadatasorting] WHERE [tablename] = 'registrypersoneview'
	DELETE [dbo].[metadatamanagedtable]  WHERE [tablename] = 'registrypersoneview'
END
GO

---------------------------

 IF exists(SELECT * FROM [web_listredir] WHERE listtype = 'prev' AND tablename = 'contratto')
UPDATE[web_listredir] SET ct = null, cu = null, lt = null, lu = null, newlisttype = 'prev', newtablename = 'contrattoprevview' WHERE listtype = 'prev' AND tablename = 'contratto'
ELSE
INSERT INTO [dbo].[web_listredir] ([tablename],[listtype],[newtablename],[newlisttype],[ct],[cu],[lt],[lu])VALUES('contratto', 'prev', 'contrattoprevview', 'prev', NULL, NULL, NULL, NULL)
GO

IF exists(SELECT * FROM [contrattokind] WHERE idcontrattokind = '21')
UPDATE [contrattokind] SET active = 'S',assegnoaggiuntivo = 'N',costolordoannuo = null,costolordoannuooneri = null,ct = {ts '2022-01-24 16:49:29.983'},cu = 'ferdinando.giannetti{DIRGEN}',description = null,elementoperequativo = 'N',indennitadiateneo = 'N',indennitadiposizione = 'N',indvacancacontrattuale = 'N',lt = {ts '2022-01-24 16:49:29.983'},lu = 'ferdinando.giannetti{DIRGEN}',oremaxcompitididatempoparziale = null,oremaxcompitididatempopieno = null,oremaxdidatempoparziale = null,oremaxdidatempopieno = null,oremaxgg = null,oremaxtempoparziale = null,oremaxtempopieno = '1720',oremincompitididatempoparziale = null,oremincompitididatempopieno = null,oremindidatempoparziale = null,oremindidatempopieno = null,oremintempoparziale = null,oremintempopieno = null,orestraordinariemax = null,parttime = 'N',puntiorganico = '1.5',scatto = 'S',siglaesportazione = 'DG',siglaimportazione = 'DG',sortcode = '0',tempdef = 'N',title = 'Professore a contratto esterno',totaletredicesima = 'S',tredicesimaindennitaintegrativaspeciale = 'N' WHERE idcontrattokind = '21'
ELSE
INSERT INTO [contrattokind] (idcontrattokind,active,assegnoaggiuntivo,costolordoannuo,costolordoannuooneri,ct,cu,description,elementoperequativo,indennitadiateneo,indennitadiposizione,indvacancacontrattuale,lt,lu,oremaxcompitididatempoparziale,oremaxcompitididatempopieno,oremaxdidatempoparziale,oremaxdidatempopieno,oremaxgg,oremaxtempoparziale,oremaxtempopieno,oremincompitididatempoparziale,oremincompitididatempopieno,oremindidatempoparziale,oremindidatempopieno,oremintempoparziale,oremintempopieno,orestraordinariemax,parttime,puntiorganico,scatto,siglaesportazione,siglaimportazione,sortcode,tempdef,title,totaletredicesima,tredicesimaindennitaintegrativaspeciale) VALUES ('21','S','N',null,null,{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,'N','N','N','N',{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,null,null,null,null,null,'1720',null,null,null,null,null,null,null,'N','1.5','S','DG','DG','0','N','Professore a contratto esterno','S','N')
GO


IF exists(SELECT * FROM [contrattokind] WHERE idcontrattokind = '22')
UPDATE [contrattokind] SET active = 'S',assegnoaggiuntivo = 'N',costolordoannuo = null,costolordoannuooneri = null,ct = {ts '2022-01-24 16:49:29.983'},cu = 'ferdinando.giannetti{DIRGEN}',description = null,elementoperequativo = 'N',indennitadiateneo = 'N',indennitadiposizione = 'N',indvacancacontrattuale = 'N',lt = {ts '2022-01-24 16:49:29.983'},lu = 'ferdinando.giannetti{DIRGEN}',oremaxcompitididatempoparziale = null,oremaxcompitididatempopieno = null,oremaxdidatempoparziale = null,oremaxdidatempopieno = null,oremaxgg = null,oremaxtempoparziale = null,oremaxtempopieno = '1720',oremincompitididatempoparziale = null,oremincompitididatempopieno = null,oremindidatempoparziale = null,oremindidatempopieno = null,oremintempoparziale = null,oremintempopieno = null,orestraordinariemax = null,parttime = 'N',puntiorganico = '1.5',scatto = 'S',siglaesportazione = 'DG',siglaimportazione = 'DG',sortcode = '0',tempdef = 'N',title = 'Direttore generale',totaletredicesima = 'S',tredicesimaindennitaintegrativaspeciale = 'N' WHERE idcontrattokind = '22'
ELSE
INSERT INTO [contrattokind] (idcontrattokind,active,assegnoaggiuntivo,costolordoannuo,costolordoannuooneri,ct,cu,description,elementoperequativo,indennitadiateneo,indennitadiposizione,indvacancacontrattuale,lt,lu,oremaxcompitididatempoparziale,oremaxcompitididatempopieno,oremaxdidatempoparziale,oremaxdidatempopieno,oremaxgg,oremaxtempoparziale,oremaxtempopieno,oremincompitididatempoparziale,oremincompitididatempopieno,oremindidatempoparziale,oremindidatempopieno,oremintempoparziale,oremintempopieno,orestraordinariemax,parttime,puntiorganico,scatto,siglaesportazione,siglaimportazione,sortcode,tempdef,title,totaletredicesima,tredicesimaindennitaintegrativaspeciale) VALUES ('22','S','N',null,null,{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,'N','N','N','N',{ts '2022-01-24 16:49:29.983'},'ferdinando.giannetti{DIRGEN}',null,null,null,null,null,null,'1720',null,null,null,null,null,null,null,'N','1.5','S','DG','DG','0','N','Direttore generale','S','N')
GO

-- CREAZIONE PROCEDURE [dbo].[sp_import_cessazionicsa]
IF EXISTS (select * from sysobjects where id = object_id(N'[dbo].[sp_import_cessazionicsa]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[sp_import_cessazionicsa]
GO
CREATE procedure [dbo].[sp_import_cessazionicsa]
(
	@idparents nvarchar(255),
	@nometabella nvarchar(255)
)
AS
BEGIN
	SET XACT_ABORT ON
	SET NoCount ON

	DECLARE @rollbackFlag bit;
	DECLARE @SqlDrop NVARCHAR(MAX);
	SET @SqlDrop = N'DROP TABLE ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + N';';

    BEGIN TRY

		BEGIN TRANSACTION;

		DECLARE @outmsg nvarchar(255);

		DECLARE @idparent nvarchar(255);
		SET @idparent = (select top 1 value from STRING_SPLIT(@idparents, ','));

		DECLARE @Sql NVARCHAR(MAX);
		DECLARE @SqlExport NVARCHAR(MAX);
		DECLARE @CRLF nchar(2) = NCHAR(13) + NCHAR(10);
		DECLARE @i int = (SELECT isnull(MAX(idpcscessazioni),0) FROM dbo.pcscessazioni);

		SET @Sql = N'UPDATE dbo.contratto' + @CRLF +
		N'SET contratto.stop = CONVERT(DATE, temp.finerapp, 103)' + @CRLF +
		N'FROM' + @CRLF +
		N'contratto' + @CRLF +
		N'JOIN ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + ' temp' + @CRLF +
		N'ON CONVERT(DATE, temp.assunz, 103) = contratto.start' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula' + @CRLF +
		N';';


		DECLARE @SqlErrorRows NVARCHAR(MAX) = N'SELECT registry.idreg, CONVERT(DATE, temp.assunz, 103) as start, CONVERT(DATE, temp.finerapp, 103) as stop FROM ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + ' temp' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula' + @CRLF +
		N'WHERE not registry.extmatricula like ''%[^0-9]%''' + @CRLF +
		N'AND NOT EXISTS (SELECT idreg, start, stop FROM dbo.contratto)' + N';';

		exec (@Sql)
		
		SET @outmsg = 'Operation Successful';
		select @outmsg;

		/*INSERT INTO OPENROWSET('Microsoft.ACE.OLEDB.12.0','Excel 12.0;
		Database=\\Mac\Home\Desktop\pcscessazioni.xlsx;','SELECT * FROM [Foglio1$]')*/

		exec (@SqlErrorRows)

		exec (@SqlDrop)


		COMMIT TRANSACTION
    END TRY
    BEGIN CATCH

			set @rollbackFlag = 1;

			SET @outmsg = ERROR_MESSAGE();
			select @outmsg;

			ROLLBACK TRANSACTION
			/*SELECT
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;*/
        
    END CATCH

	IF @rollbackFlag = 1
		BEGIN
			exec (@SqlDrop)
		END
END;

GO
-- CREAZIONE PROCEDURE [dbo].[sp_import_contratticsa]
IF EXISTS (select * from sysobjects where id = object_id(N'[dbo].[sp_import_contratticsa]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[sp_import_contratticsa]
GO
CREATE procedure [dbo].[sp_import_contratticsa]
(
	@idparents nvarchar(255),
	@nometabella nvarchar(255)
)
AS
BEGIN
	SET XACT_ABORT ON
	SET NoCount ON
	DECLARE @rollbackFlag bit;
	DECLARE @SqlDrop NVARCHAR(MAX);
	SET @SqlDrop = N'DROP TABLE ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + N';';

    BEGIN TRY

		BEGIN TRANSACTION;

		DECLARE @outmsg nvarchar(255);

		DECLARE @idparent nvarchar(255);
		SET @idparent = (select top 1 items from dbo.split(@idparents, ','));

		DECLARE @Sql NVARCHAR(MAX);
		DECLARE @CRLF nchar(2) = NCHAR(13) + NCHAR(10);
		DECLARE @i int = (SELECT isnull(MAX(idcontratto),0) FROM dbo.contratto);

		SET @Sql = N'INSERT INTO dbo.contratto (idcontratto,ct,cu,estremibando,idcontrattokind,idinquadramento,idreg,lt,lu,parttime,scatto,start,stop,tempdef,tempindet)' + @CRLF +
		N'SELECT row_number() over(order by registry.idreg) +' + convert(nvarchar, @i) + ', GETDATE(), ''sp_import_contratticsa'', null,' + @CRLF +
		N'CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
		end as idcontrattokind,
		CASE 
			WHEN exists(select top 1 idinquadramento from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idinquadramento from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idinquadramento from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idinquadramento from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
		end as idinquadramento,' + @CRLF +
		N'registry.idreg, GETDATE(), ''sp_import_contratticsa'', null, null, 
		CONVERT(date,temp.datainizio ,103),
		ltrim(rtrim(CASE WHEN temp.datafine = '''' THEN NULL ELSE CONVERT(date,temp.datafine ,103) END)) as datafine,' + @CRLF +
		N'CASE      
			WHEN exists(select top 1 isnull(tempdef,''N'') from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)      
			THEN (select top 1 isnull(tempdef,''N'') from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)     
			WHEN exists(select top 1 idinquadramento from stipendio where stipendio.siglaimportazione =  temp.inquadramento)      
			THEN (select top 1 isnull(tempdef,''N'') from stipendio inner join inquadramento i on i.idinquadramento = stipendio.idinquadramento where stipendio.siglaimportazione =  temp.inquadramento) 
			ELSE ''N''  END as tempdef, ''S''' + @CRLF +
		N'FROM' + @CRLF +
		N'(SELECT matricola, ruolo, inquadramento, datainizio, datafine' + @CRLF 
		SET @Sql = @Sql +
        N'FROM ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + ') as temp' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula
		WHERE CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
		end is not null
		and not exists (select top 1 c.idcontratto from contratto c where  c.idreg = registry.idreg  
			and YEAR(c.start) = YEAR(CONVERT(date,temp.datainizio ,103))
			and MONTH(c.start) = MONTH(CONVERT(date,temp.datainizio ,103)) 
			and DAY(c.start) = DAY(CONVERT(date,temp.datainizio ,103)) 
			and c.idcontrattokind = CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
			END)' + @CRLF + N';';

		/*select @@RowCount*/

		--aggiungere le select delle righe non importate perch� 
		--1 idcontrattokind � null
		--2 � un doppione
		DECLARE @SqlErrorRows NVARCHAR(MAX) = 'select temp.*, 
		CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
		end as idcontratto' + @CRLF +
		N'FROM' + @CRLF +
		N'(SELECT matricola, ruolo, inquadramento, datainizio, datafine' + @CRLF 
		SET @SqlErrorRows = @SqlErrorRows +
        N'FROM ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + ') as temp' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula
		WHERE CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
		end is null
		OR exists (select top 1 c.idcontratto from contratto c where  c.idreg = registry.idreg  
			and YEAR(c.start) = YEAR(CONVERT(date,temp.datainizio ,103))
			and MONTH(c.start) = MONTH(CONVERT(date,temp.datainizio ,103)) 
			and DAY(c.start) = DAY(CONVERT(date,temp.datainizio ,103)) 
			and c.idcontrattokind = CASE 
			WHEN exists(select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo) 
			THEN (select top 1 idcontrattokind from contrattokind where siglaimportazione =  temp.ruolo)
			WHEN exists(select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento) 
			THEN (select top 1 idcontrattokind from inquadramento where inquadramento.siglaimportazione =  temp.inquadramento)
			WHEN exists(select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', '''')) 
			THEN (select top 1 idcontrattokind from stipendio where replace(stipendio.siglaimportazione, '' '', '''') =  replace(temp.inquadramento, '' '', ''''))
			END)' + @CRLF + N';';


		--select @Sql
		--select @SqlErrorRows
		exec (@Sql)

		exec (@SqlDrop)
		
		SET @outmsg = 'Operation Successful';
		select @outmsg;

		COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
			set @rollbackFlag = 1;

			SET @outmsg = ERROR_MESSAGE();
			select @outmsg;

			ROLLBACK TRANSACTION
			/*SELECT
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;*/
        
    END CATCH

	IF @rollbackFlag = 1
		BEGIN
			exec (@SqlDrop)
		END
END;

--exec [dbo].[sp_import_contratticsa] '1', '_temp1637323744064'

--CHECK DUPLICATI
--select --idreg,start, idcontrattokind, idinquadramento, cu , 
--* from contratto  
--where idreg in (select idreg from (select count(idreg) as cc, idreg,start from contratto group by idreg,start) tbl1 where cc>1)
--and idreg in (select idreg from contratto where cu = 'sp_import_contratticsa')
--order by idreg, start

GO

-- CREAZIONE PROCEDURE [dbo].[sp_import_stipendicsa]
IF EXISTS (select * from sysobjects where id = object_id(N'[dbo].[sp_import_stipendicsa]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[sp_import_stipendicsa]
GO
CREATE procedure [dbo].[sp_import_stipendicsa]
(
	@idparents nvarchar(255),
	@nometabella nvarchar(255)
)
AS
BEGIN
	SET XACT_ABORT ON
	SET NoCount ON

	DECLARE @rollbackFlag bit;
	DECLARE @SqlDrop NVARCHAR(MAX);
	SET @SqlDrop = N'DROP TABLE ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + N';';

    BEGIN TRY

		BEGIN TRANSACTION;

		DECLARE @outmsg nvarchar(255);

		DECLARE @idparent nvarchar(255);
		SET @idparent = (select top 1 items from dbo.split(@idparents, ','));

		DECLARE @Sql NVARCHAR(MAX);
		DECLARE @CRLF nchar(2) = NCHAR(13) + NCHAR(10);
		DECLARE @i int = (SELECT isnull(MAX(idstipendioannuo),0) FROM dbo.stipendioannuo);

		SET @Sql = N'INSERT INTO dbo.stipendioannuo (idreg, idstipendioannuo, year,lordo,caricoente,irap,totale,ct,lt,cu,lu,idcontratto)' + @CRLF +
		N'SELECT registry.idreg, row_number() over(order by registry.idreg) +' + convert(nvarchar, @i) + ', temp.anno, temp.lordo, temp.oneri, temp.lordo * 0.085 as irap, (temp.lordo + temp.oneri +  (temp.lordo * 0.085)) as totale, GETDATE(), GETDATE(), ''sp_import_stipendicsa'', ''sp_import_stipendicsa'',
		(select top 1 idcontratto from contratto c 
		 where isnull(c.stop, ''22221231'') >= temp.anno + ''0101'' and c.start<= temp.anno + ''1231'' and c.idreg = registry.idreg
		 order by c.start desc, c.stop desc) as idcontratto' + @CRLF +
		N'FROM' + @CRLF +
		N'(SELECT anno, matricola, sum(cast(lordo as decimal(18,2))) as lordo, sum(cast(oneri as decimal(18,2))) as oneri, sum(cast(totale as decimal(18,2))) as totale' + @CRLF +
        N'FROM ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + @CRLF +
		N'GROUP BY matricola, anno' + @CRLF + ') as temp' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula
		where exists (select top 1 idcontratto from contratto c 
		 where isnull(c.stop, ''22221231'') >= temp.anno + ''0101'' and c.start<= temp.anno + ''1231'' and c.idreg = registry.idreg
		 order by c.start desc, c.stop desc)' + @CRLF + N';';

		 --aggiungere l'export delle righe in errore perch� non risulta un contratto attivo per l'anno dello stipendio indicato
		 DECLARE @SqlErrorRows NVARCHAR(MAX) = 'select temp.* from 
		 (SELECT anno, matricola, sum(cast(lordo as decimal(18,2))) as lordo, sum(cast(oneri as decimal(18,2))) as oneri, sum(cast(totale as decimal(18,2))) as totale' + @CRLF +
        N'FROM ' + QUOTENAME('amministrazione') + N'.' + QUOTENAME(@nometabella) + @CRLF +
		N'GROUP BY matricola, anno' + @CRLF + ') as temp' + @CRLF +
		N'JOIN registry ON format(CAST(temp.matricola as int) ,''000000'') = registry.extmatricula
		 where not exists (select top 1 idcontratto from contratto c 
		 where isnull(c.stop, ''22221231'') >= temp.anno + ''0101'' and c.start<= temp.anno + ''1231'' and c.idreg = registry.idreg
		 order by c.start desc, c.stop desc)'


		--select @Sql
		--select @SqlErrorRows
		exec (@Sql)

		exec (@SqlDrop)
		
		SET @outmsg = 'Operation Successful';
		select @outmsg;

		COMMIT TRANSACTION
    END TRY
    BEGIN CATCH
        
			set @rollbackFlag = 1;

			SET @outmsg = ERROR_MESSAGE();
			select @outmsg;

			ROLLBACK TRANSACTION
			/*SELECT
				ERROR_NUMBER() AS ErrorNumber,
				ERROR_STATE() AS ErrorState,
				ERROR_SEVERITY() AS ErrorSeverity,
				ERROR_PROCEDURE() AS ErrorProcedure,
				ERROR_LINE() AS ErrorLine,
				ERROR_MESSAGE() AS ErrorMessage;*/
        
    END CATCH

	IF @rollbackFlag = 1
		BEGIN
			exec (@SqlDrop)
		END
END;

--exec [dbo].[sp_import_stipendicsa] '1', '_temp1637247421803'

GO


