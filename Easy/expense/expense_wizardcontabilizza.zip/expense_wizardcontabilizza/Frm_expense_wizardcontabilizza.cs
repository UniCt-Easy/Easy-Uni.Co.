using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using metadatalibrary;
using funzioni_configurazione;//funzioni_configurazione

namespace expense_wizardcontabilizza//SpesaWizardContabilizza//
{
	/// <summary>
	/// Summary description for FrmSpesaContabilizza.
	/// </summary>
	public class Frm_expense_wizardcontabilizza : System.Windows.Forms.Form
	{
		#region System declarations
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.Button btnNext;
		private System.Windows.Forms.Button btnBack;
		private Crownwood.Magic.Controls.TabControl tabController;
		private Crownwood.Magic.Controls.TabPage tabIntro;
		private Crownwood.Magic.Controls.TabPage tabConfirm;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.GroupBox groupBox20;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.TextBox txtDataCont;
		private System.Windows.Forms.TextBox txtScadenza;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.GroupBox groupBox18;
		private System.Windows.Forms.TextBox SubEntity_txtImportoMovimento;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.GroupBox groupBox17;
		private System.Windows.Forms.TextBox txtDescrizione;
		private System.Windows.Forms.GroupBox gboxBilAnnuale;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtCodiceBilancio;
		private System.Windows.Forms.TextBox txtDenominazioneBilancio;
		private System.Windows.Forms.GroupBox groupCredDeb;
		private System.Windows.Forms.TextBox txtCredDeb;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label lblImportoDisponibile;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.TextBox txtImportoDisponibile;
		private System.Windows.Forms.TextBox txtImportoCorrente;
		private System.Windows.Forms.GroupBox gboxMovimento;
		private System.Windows.Forms.Button btnSelectMov;
		private System.Windows.Forms.TextBox txtNumeroMovimento;
		private System.Windows.Forms.TextBox txtEsercizioMovimento;
		private System.Windows.Forms.Label lblFaseMovimento;
		private System.Windows.Forms.ComboBox cmbFaseSpesa;
		private Crownwood.Magic.Controls.TabPage tabSelectMov;
		private Crownwood.Magic.Controls.TabPage tabSelectDoc;
		private System.Windows.Forms.Label label19;
		private System.Windows.Forms.ComboBox cmbCausale;
		private System.Windows.Forms.ComboBox cmbTipoContabilizzazione;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.GroupBox gboxDocumento;
		private System.Windows.Forms.Button btnDocumento;
		private System.Windows.Forms.ComboBox cmbTipoDocumento;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox txtNumDoc;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox txtEsercDoc;
		private System.Windows.Forms.Label labelTipoDocumento;
		private System.Windows.Forms.Label labelCausale;
		public vistaForm DS;
		#endregion

		MetaData Meta;
		DataAccess Conn;
		string CustomTitle;
		int fasespesacont;
		int faseivaspesa;
		private System.Windows.Forms.Label labContabAttuale;
		private System.Windows.Forms.CheckBox chkCredDeb;
		decimal currimp;
		object NuovoDocumento;
		object NuovoDataDocumento;
		object NuovoDescrizione;
		string CurrCausaleIva;
		string CurrCausaleOrdine;
		string CurrCausaleMissione;
		string CurrCausaleCedolino;
		string CurrCausaleOccasionale;
		string CurrCausaleProfessionale;
		string CurrCausaleDipendente;

		string CurrDocDescr;
		private System.Windows.Forms.Label labOperazione;
		private System.Windows.Forms.Label labNum;
		private System.Windows.Forms.Label labEserc;
		private System.Windows.Forms.ImageList imageList1;
		private System.Windows.Forms.GroupBox gboxUPB;
		private System.Windows.Forms.ComboBox SubEntity_comboUPB;
		private System.Windows.Forms.TextBox txtDescrUPB;
		private System.Windows.Forms.Button btnUPBCode;
		private System.Windows.Forms.GroupBox groupBox16;
		private System.Windows.Forms.ComboBox cmbResponsabile;
        private Crownwood.Magic.Controls.TabPage tabDettagli;
        private GroupBox gboxDettInvoice;
        private Button btnEditInvDet;
        private TextBox txtTotInvoiceDetail;
        private Label label17;
        private Button btnRemoveDettInvoice;
        private Button btnAddDettInvoice;
        private DataGrid dgrDettagliFattura;
        private GroupBox gboxDettmandate;
        private Button btnEditMandDet;
        private TextBox txtTotMandateDetail;
        private Label label16;
        private Button btnRemoveDetMandate;
        private DataGrid dgrDettagliOrdine;
        private Button btnAddDetMandate;
        private CheckBox chkFilterResidual;
		private System.ComponentModel.IContainer components;

		public Frm_expense_wizardcontabilizza()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			tabController.HideTabsMode = 
				Crownwood.Magic.Controls.TabControl.HideTabsModes.HideAlways;
		}


		int currphase()
		{
			return CfgFn.GetNoNullInt32( cmbFaseSpesa.SelectedValue);
		}
		public void MetaData_AfterActivation(){
			CustomTitle= "Wizard Aggiunta Contabilizzazioni";
			//Selects first tab
			DisplayTabs(0);

			MetaData MetaMandDet = MetaData.GetMetaData(this,"mandatedetailview");
			MetaMandDet.DescribeColumns(DS.mandatedetail_taxable,"listaimpon");
			MetaMandDet.DescribeColumns(DS.mandatedetail_iva,"listaimpos");

			MetaData MetaInvDet = MetaData.GetMetaData(this,"invoicedetailview");
			MetaInvDet.DescribeColumns(DS.invoicedetail_taxable,"listaimpon");
			MetaInvDet.DescribeColumns(DS.invoicedetail_iva,"listaimpos");


		}

        public void MetaData_AfterRowSelect(DataTable T, DataRow R) {

            if(((T.TableName == "mandatedetail_taxable") || (T.TableName == "mandatedetail_iva")) && Meta.DrawStateIsDone) {
                if((T.TableName == "mandatedetail_taxable") && (CurrCausaleOrdine == "ORDIN")) {
                    if(R != null) R["idexp_iva"] = R["idexp_taxable"];
                }
            }
            if(((T.TableName == "invoicedetail_taxable") || (T.TableName == "invoicedetail_iva")) && Meta.DrawStateIsDone) {
                if((T.TableName == "invoicedetail_taxable") && (CurrCausaleOrdine == "DOCUM")) {
                    if(R != null) R["idexp_iva"] = R["idexp_taxable"];
                }
            }

        }
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Frm_expense_wizardcontabilizza));
            this.DS = new expense_wizardcontabilizza.vistaForm();
            this.tabController = new Crownwood.Magic.Controls.TabControl();
            this.tabSelectDoc = new Crownwood.Magic.Controls.TabPage();
            this.chkFilterResidual = new System.Windows.Forms.CheckBox();
            this.chkCredDeb = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cmbCausale = new System.Windows.Forms.ComboBox();
            this.cmbTipoContabilizzazione = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.gboxDocumento = new System.Windows.Forms.GroupBox();
            this.btnDocumento = new System.Windows.Forms.Button();
            this.cmbTipoDocumento = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txtNumDoc = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtEsercDoc = new System.Windows.Forms.TextBox();
            this.labelTipoDocumento = new System.Windows.Forms.Label();
            this.labelCausale = new System.Windows.Forms.Label();
            this.tabIntro = new Crownwood.Magic.Controls.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabSelectMov = new Crownwood.Magic.Controls.TabPage();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.cmbResponsabile = new System.Windows.Forms.ComboBox();
            this.gboxUPB = new System.Windows.Forms.GroupBox();
            this.SubEntity_comboUPB = new System.Windows.Forms.ComboBox();
            this.txtDescrUPB = new System.Windows.Forms.TextBox();
            this.btnUPBCode = new System.Windows.Forms.Button();
            this.labContabAttuale = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtDataCont = new System.Windows.Forms.TextBox();
            this.txtScadenza = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.SubEntity_txtImportoMovimento = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.txtDescrizione = new System.Windows.Forms.TextBox();
            this.gboxBilAnnuale = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.txtCodiceBilancio = new System.Windows.Forms.TextBox();
            this.txtDenominazioneBilancio = new System.Windows.Forms.TextBox();
            this.groupCredDeb = new System.Windows.Forms.GroupBox();
            this.txtCredDeb = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblImportoDisponibile = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtImportoDisponibile = new System.Windows.Forms.TextBox();
            this.txtImportoCorrente = new System.Windows.Forms.TextBox();
            this.gboxMovimento = new System.Windows.Forms.GroupBox();
            this.btnSelectMov = new System.Windows.Forms.Button();
            this.txtNumeroMovimento = new System.Windows.Forms.TextBox();
            this.labNum = new System.Windows.Forms.Label();
            this.txtEsercizioMovimento = new System.Windows.Forms.TextBox();
            this.labEserc = new System.Windows.Forms.Label();
            this.lblFaseMovimento = new System.Windows.Forms.Label();
            this.cmbFaseSpesa = new System.Windows.Forms.ComboBox();
            this.tabDettagli = new Crownwood.Magic.Controls.TabPage();
            this.gboxDettInvoice = new System.Windows.Forms.GroupBox();
            this.btnEditInvDet = new System.Windows.Forms.Button();
            this.txtTotInvoiceDetail = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.btnRemoveDettInvoice = new System.Windows.Forms.Button();
            this.btnAddDettInvoice = new System.Windows.Forms.Button();
            this.dgrDettagliFattura = new System.Windows.Forms.DataGrid();
            this.gboxDettmandate = new System.Windows.Forms.GroupBox();
            this.btnEditMandDet = new System.Windows.Forms.Button();
            this.txtTotMandateDetail = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.btnRemoveDetMandate = new System.Windows.Forms.Button();
            this.dgrDettagliOrdine = new System.Windows.Forms.DataGrid();
            this.btnAddDetMandate = new System.Windows.Forms.Button();
            this.tabConfirm = new Crownwood.Magic.Controls.TabPage();
            this.labOperazione = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.tabController.SuspendLayout();
            this.tabSelectDoc.SuspendLayout();
            this.gboxDocumento.SuspendLayout();
            this.tabIntro.SuspendLayout();
            this.tabSelectMov.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.gboxUPB.SuspendLayout();
            this.groupBox20.SuspendLayout();
            this.groupBox18.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.gboxBilAnnuale.SuspendLayout();
            this.groupCredDeb.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.gboxMovimento.SuspendLayout();
            this.tabDettagli.SuspendLayout();
            this.gboxDettInvoice.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrDettagliFattura)).BeginInit();
            this.gboxDettmandate.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrDettagliOrdine)).BeginInit();
            this.tabConfirm.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabController
            // 
            this.tabController.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.tabController.IDEPixelArea = true;
            this.tabController.Location = new System.Drawing.Point(8, 8);
            this.tabController.Name = "tabController";
            this.tabController.SelectedIndex = 2;
            this.tabController.SelectedTab = this.tabSelectDoc;
            this.tabController.Size = new System.Drawing.Size(708, 484);
            this.tabController.TabIndex = 0;
            this.tabController.TabPages.AddRange(new Crownwood.Magic.Controls.TabPage[] {
            this.tabIntro,
            this.tabSelectMov,
            this.tabSelectDoc,
            this.tabDettagli,
            this.tabConfirm});
            this.tabController.SelectionChanged += new System.EventHandler(this.tabController_SelectionChanged);
            // 
            // tabSelectDoc
            // 
            this.tabSelectDoc.Controls.Add(this.chkFilterResidual);
            this.tabSelectDoc.Controls.Add(this.chkCredDeb);
            this.tabSelectDoc.Controls.Add(this.label19);
            this.tabSelectDoc.Controls.Add(this.cmbCausale);
            this.tabSelectDoc.Controls.Add(this.cmbTipoContabilizzazione);
            this.tabSelectDoc.Controls.Add(this.label8);
            this.tabSelectDoc.Controls.Add(this.gboxDocumento);
            this.tabSelectDoc.Controls.Add(this.labelCausale);
            this.tabSelectDoc.Location = new System.Drawing.Point(0, 0);
            this.tabSelectDoc.Name = "tabSelectDoc";
            this.tabSelectDoc.Size = new System.Drawing.Size(708, 459);
            this.tabSelectDoc.TabIndex = 6;
            this.tabSelectDoc.Title = "Pagina 3 di 5";
            // 
            // chkFilterResidual
            // 
            this.chkFilterResidual.AutoSize = true;
            this.chkFilterResidual.Checked = true;
            this.chkFilterResidual.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkFilterResidual.Location = new System.Drawing.Point(8, 202);
            this.chkFilterResidual.Name = "chkFilterResidual";
            this.chkFilterResidual.Size = new System.Drawing.Size(353, 17);
            this.chkFilterResidual.TabIndex = 103;
            this.chkFilterResidual.Text = "Cerca documento con residuo maggiore della disponibilit� movimento";
            this.chkFilterResidual.UseVisualStyleBackColor = true;
            // 
            // chkCredDeb
            // 
            this.chkCredDeb.Checked = true;
            this.chkCredDeb.CheckState = System.Windows.Forms.CheckState.Checked;
            this.chkCredDeb.Location = new System.Drawing.Point(8, 160);
            this.chkCredDeb.Name = "chkCredDeb";
            this.chkCredDeb.Size = new System.Drawing.Size(680, 48);
            this.chkCredDeb.TabIndex = 102;
            this.chkCredDeb.Text = "Cerca solo documenti con lo stesso percipiente del movimento di spesa";
            // 
            // label19
            // 
            this.label19.Location = new System.Drawing.Point(8, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(688, 23);
            this.label19.TabIndex = 101;
            this.label19.Text = "Selezionare il documento da ASSOCIARE al movimento di spesa";
            // 
            // cmbCausale
            // 
            this.cmbCausale.DataSource = this.DS.tipomovimento;
            this.cmbCausale.DisplayMember = "descrizione";
            this.cmbCausale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.cmbCausale.ItemHeight = 13;
            this.cmbCausale.Location = new System.Drawing.Point(64, 56);
            this.cmbCausale.Name = "cmbCausale";
            this.cmbCausale.Size = new System.Drawing.Size(256, 21);
            this.cmbCausale.TabIndex = 100;
            this.cmbCausale.ValueMember = "idtipo";
            this.cmbCausale.SelectedIndexChanged += new System.EventHandler(this.cmbCausale_SelectedIndexChanged);
            // 
            // cmbTipoContabilizzazione
            // 
            this.cmbTipoContabilizzazione.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.cmbTipoContabilizzazione.ItemHeight = 13;
            this.cmbTipoContabilizzazione.Location = new System.Drawing.Point(128, 32);
            this.cmbTipoContabilizzazione.Name = "cmbTipoContabilizzazione";
            this.cmbTipoContabilizzazione.Size = new System.Drawing.Size(192, 21);
            this.cmbTipoContabilizzazione.TabIndex = 99;
            this.cmbTipoContabilizzazione.SelectedIndexChanged += new System.EventHandler(this.cmbTipoContabilizzazione_SelectedIndexChanged);
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(8, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(120, 23);
            this.label8.TabIndex = 98;
            this.label8.Text = "Tipo contabilizzazione";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gboxDocumento
            // 
            this.gboxDocumento.Controls.Add(this.btnDocumento);
            this.gboxDocumento.Controls.Add(this.cmbTipoDocumento);
            this.gboxDocumento.Controls.Add(this.label7);
            this.gboxDocumento.Controls.Add(this.txtNumDoc);
            this.gboxDocumento.Controls.Add(this.label10);
            this.gboxDocumento.Controls.Add(this.txtEsercDoc);
            this.gboxDocumento.Controls.Add(this.labelTipoDocumento);
            this.gboxDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.gboxDocumento.Location = new System.Drawing.Point(8, 80);
            this.gboxDocumento.Name = "gboxDocumento";
            this.gboxDocumento.Size = new System.Drawing.Size(392, 72);
            this.gboxDocumento.TabIndex = 97;
            this.gboxDocumento.TabStop = false;
            this.gboxDocumento.Text = "Documento contabilizzato";
            this.gboxDocumento.Visible = false;
            // 
            // btnDocumento
            // 
            this.btnDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDocumento.Location = new System.Drawing.Point(8, 48);
            this.btnDocumento.Name = "btnDocumento";
            this.btnDocumento.Size = new System.Drawing.Size(144, 20);
            this.btnDocumento.TabIndex = 10;
            this.btnDocumento.Text = "Documento";
            this.btnDocumento.Click += new System.EventHandler(this.btnDocumento_Click);
            // 
            // cmbTipoDocumento
            // 
            this.cmbTipoDocumento.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTipoDocumento.Location = new System.Drawing.Point(40, 16);
            this.cmbTipoDocumento.Name = "cmbTipoDocumento";
            this.cmbTipoDocumento.Size = new System.Drawing.Size(336, 21);
            this.cmbTipoDocumento.TabIndex = 9;
            this.cmbTipoDocumento.Tag = "";
            this.cmbTipoDocumento.SelectedIndexChanged += new System.EventHandler(this.cmbTipoDocumento_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(152, 48);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(48, 16);
            this.label7.TabIndex = 1;
            this.label7.Text = "Eserc.";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtNumDoc
            // 
            this.txtNumDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNumDoc.Location = new System.Drawing.Point(312, 48);
            this.txtNumDoc.Name = "txtNumDoc";
            this.txtNumDoc.ReadOnly = true;
            this.txtNumDoc.Size = new System.Drawing.Size(64, 20);
            this.txtNumDoc.TabIndex = 4;
            this.txtNumDoc.Leave += new System.EventHandler(this.txtNumDoc_Leave);
            // 
            // label10
            // 
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(280, 48);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(32, 16);
            this.label10.TabIndex = 3;
            this.label10.Text = "Num.";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtEsercDoc
            // 
            this.txtEsercDoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEsercDoc.Location = new System.Drawing.Point(200, 48);
            this.txtEsercDoc.Name = "txtEsercDoc";
            this.txtEsercDoc.ReadOnly = true;
            this.txtEsercDoc.Size = new System.Drawing.Size(56, 20);
            this.txtEsercDoc.TabIndex = 2;
            this.txtEsercDoc.Leave += new System.EventHandler(this.txtEsercDoc_Leave);
            // 
            // labelTipoDocumento
            // 
            this.labelTipoDocumento.Location = new System.Drawing.Point(8, 16);
            this.labelTipoDocumento.Name = "labelTipoDocumento";
            this.labelTipoDocumento.Size = new System.Drawing.Size(32, 16);
            this.labelTipoDocumento.TabIndex = 6;
            this.labelTipoDocumento.Text = "Tipo";
            this.labelTipoDocumento.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // labelCausale
            // 
            this.labelCausale.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.World, ((byte)(0)));
            this.labelCausale.Location = new System.Drawing.Point(8, 56);
            this.labelCausale.Name = "labelCausale";
            this.labelCausale.Size = new System.Drawing.Size(48, 23);
            this.labelCausale.TabIndex = 96;
            this.labelCausale.Text = "Causale";
            this.labelCausale.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tabIntro
            // 
            this.tabIntro.Controls.Add(this.label4);
            this.tabIntro.Controls.Add(this.label3);
            this.tabIntro.Controls.Add(this.label2);
            this.tabIntro.Controls.Add(this.label1);
            this.tabIntro.Location = new System.Drawing.Point(0, 0);
            this.tabIntro.Name = "tabIntro";
            this.tabIntro.Selected = false;
            this.tabIntro.Size = new System.Drawing.Size(708, 459);
            this.tabIntro.TabIndex = 3;
            this.tabIntro.Title = "Pagina 1 di 5";
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.Location = new System.Drawing.Point(24, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(660, 40);
            this.label4.TabIndex = 3;
            this.label4.Text = "L\'unica informazione che sar� aggiunta sar� L\'ASSOCIAZIONE tra il movimento di sp" +
                "esa ed il documento.";
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.Location = new System.Drawing.Point(24, 104);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(660, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Non sar� creato alcun movimento di spesa, e neanche alcun documento.";
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.Location = new System.Drawing.Point(24, 72);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(660, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "E\' da notare che uno stesso movimento di spesa NON PUO\' contabilizzare pi� di un " +
                "documento.";
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.Location = new System.Drawing.Point(24, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(660, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = resources.GetString("label1.Text");
            // 
            // tabSelectMov
            // 
            this.tabSelectMov.Controls.Add(this.groupBox16);
            this.tabSelectMov.Controls.Add(this.gboxUPB);
            this.tabSelectMov.Controls.Add(this.labContabAttuale);
            this.tabSelectMov.Controls.Add(this.label6);
            this.tabSelectMov.Controls.Add(this.groupBox20);
            this.tabSelectMov.Controls.Add(this.groupBox18);
            this.tabSelectMov.Controls.Add(this.groupBox17);
            this.tabSelectMov.Controls.Add(this.gboxBilAnnuale);
            this.tabSelectMov.Controls.Add(this.groupCredDeb);
            this.tabSelectMov.Controls.Add(this.groupBox1);
            this.tabSelectMov.Controls.Add(this.gboxMovimento);
            this.tabSelectMov.Location = new System.Drawing.Point(0, 0);
            this.tabSelectMov.Name = "tabSelectMov";
            this.tabSelectMov.Selected = false;
            this.tabSelectMov.Size = new System.Drawing.Size(708, 459);
            this.tabSelectMov.TabIndex = 4;
            this.tabSelectMov.Title = "Pagina 2 di 5";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.cmbResponsabile);
            this.groupBox16.Location = new System.Drawing.Point(8, 216);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(344, 40);
            this.groupBox16.TabIndex = 90;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Responsabile";
            // 
            // cmbResponsabile
            // 
            this.cmbResponsabile.DataSource = this.DS.manager;
            this.cmbResponsabile.DisplayMember = "title";
            this.cmbResponsabile.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbResponsabile.Enabled = false;
            this.cmbResponsabile.Location = new System.Drawing.Point(8, 14);
            this.cmbResponsabile.Name = "cmbResponsabile";
            this.cmbResponsabile.Size = new System.Drawing.Size(328, 21);
            this.cmbResponsabile.TabIndex = 1;
            this.cmbResponsabile.Tag = "expense.idman";
            this.cmbResponsabile.ValueMember = "idman";
            // 
            // gboxUPB
            // 
            this.gboxUPB.Controls.Add(this.SubEntity_comboUPB);
            this.gboxUPB.Controls.Add(this.txtDescrUPB);
            this.gboxUPB.Controls.Add(this.btnUPBCode);
            this.gboxUPB.Location = new System.Drawing.Point(8, 160);
            this.gboxUPB.Name = "gboxUPB";
            this.gboxUPB.Size = new System.Drawing.Size(344, 56);
            this.gboxUPB.TabIndex = 89;
            this.gboxUPB.TabStop = false;
            this.gboxUPB.Tag = "";
            // 
            // SubEntity_comboUPB
            // 
            this.SubEntity_comboUPB.DataSource = this.DS.upb;
            this.SubEntity_comboUPB.DisplayMember = "codeupb";
            this.SubEntity_comboUPB.Enabled = false;
            this.SubEntity_comboUPB.Location = new System.Drawing.Point(8, 32);
            this.SubEntity_comboUPB.Name = "SubEntity_comboUPB";
            this.SubEntity_comboUPB.Size = new System.Drawing.Size(128, 21);
            this.SubEntity_comboUPB.TabIndex = 1;
            this.SubEntity_comboUPB.Tag = "upb.idupb?expenseview.idupb";
            this.SubEntity_comboUPB.ValueMember = "idupb";
            // 
            // txtDescrUPB
            // 
            this.txtDescrUPB.Location = new System.Drawing.Point(136, 8);
            this.txtDescrUPB.Multiline = true;
            this.txtDescrUPB.Name = "txtDescrUPB";
            this.txtDescrUPB.ReadOnly = true;
            this.txtDescrUPB.Size = new System.Drawing.Size(200, 44);
            this.txtDescrUPB.TabIndex = 4;
            this.txtDescrUPB.TabStop = false;
            this.txtDescrUPB.Tag = "upb.title";
            // 
            // btnUPBCode
            // 
            this.btnUPBCode.BackColor = System.Drawing.SystemColors.Control;
            this.btnUPBCode.Enabled = false;
            this.btnUPBCode.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUPBCode.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btnUPBCode.Location = new System.Drawing.Point(8, 8);
            this.btnUPBCode.Name = "btnUPBCode";
            this.btnUPBCode.Size = new System.Drawing.Size(112, 20);
            this.btnUPBCode.TabIndex = 2;
            this.btnUPBCode.TabStop = false;
            this.btnUPBCode.Tag = "manage.upb.tree";
            this.btnUPBCode.Text = "UPB:";
            this.btnUPBCode.UseVisualStyleBackColor = false;
            // 
            // labContabAttuale
            // 
            this.labContabAttuale.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.labContabAttuale.Location = new System.Drawing.Point(8, 328);
            this.labContabAttuale.Name = "labContabAttuale";
            this.labContabAttuale.Size = new System.Drawing.Size(664, 16);
            this.labContabAttuale.TabIndex = 88;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(8, 8);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(688, 23);
            this.label6.TabIndex = 87;
            this.label6.Text = "Selezionare il movimento di spesa che si desidera ASSOCIARE al documento ";
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.label15);
            this.groupBox20.Controls.Add(this.txtDataCont);
            this.groupBox20.Controls.Add(this.txtScadenza);
            this.groupBox20.Controls.Add(this.label13);
            this.groupBox20.Location = new System.Drawing.Point(360, 216);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(344, 40);
            this.groupBox20.TabIndex = 85;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Data";
            // 
            // label15
            // 
            this.label15.Location = new System.Drawing.Point(2, 16);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(56, 20);
            this.label15.TabIndex = 0;
            this.label15.Text = "Contabile";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtDataCont
            // 
            this.txtDataCont.Location = new System.Drawing.Point(67, 15);
            this.txtDataCont.Name = "txtDataCont";
            this.txtDataCont.ReadOnly = true;
            this.txtDataCont.Size = new System.Drawing.Size(72, 21);
            this.txtDataCont.TabIndex = 1;
            this.txtDataCont.Tag = "";
            this.txtDataCont.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtScadenza
            // 
            this.txtScadenza.Location = new System.Drawing.Point(264, 16);
            this.txtScadenza.Name = "txtScadenza";
            this.txtScadenza.ReadOnly = true;
            this.txtScadenza.Size = new System.Drawing.Size(72, 21);
            this.txtScadenza.TabIndex = 2;
            this.txtScadenza.Tag = "";
            this.txtScadenza.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label13
            // 
            this.label13.Location = new System.Drawing.Point(192, 14);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(64, 20);
            this.label13.TabIndex = 0;
            this.label13.Text = "Scadenza:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.SubEntity_txtImportoMovimento);
            this.groupBox18.Controls.Add(this.label11);
            this.groupBox18.Location = new System.Drawing.Point(8, 120);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(344, 40);
            this.groupBox18.TabIndex = 84;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Importo";
            // 
            // SubEntity_txtImportoMovimento
            // 
            this.SubEntity_txtImportoMovimento.Location = new System.Drawing.Point(225, 12);
            this.SubEntity_txtImportoMovimento.Name = "SubEntity_txtImportoMovimento";
            this.SubEntity_txtImportoMovimento.ReadOnly = true;
            this.SubEntity_txtImportoMovimento.Size = new System.Drawing.Size(112, 21);
            this.SubEntity_txtImportoMovimento.TabIndex = 1;
            this.SubEntity_txtImportoMovimento.Tag = "";
            this.SubEntity_txtImportoMovimento.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label11
            // 
            this.label11.Location = new System.Drawing.Point(8, 12);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 20);
            this.label11.TabIndex = 0;
            this.label11.Text = "Originale:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(this.txtDescrizione);
            this.groupBox17.Location = new System.Drawing.Point(360, 32);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(336, 72);
            this.groupBox17.TabIndex = 82;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Descrizione";
            // 
            // txtDescrizione
            // 
            this.txtDescrizione.Location = new System.Drawing.Point(8, 16);
            this.txtDescrizione.Multiline = true;
            this.txtDescrizione.Name = "txtDescrizione";
            this.txtDescrizione.ReadOnly = true;
            this.txtDescrizione.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDescrizione.Size = new System.Drawing.Size(328, 48);
            this.txtDescrizione.TabIndex = 1;
            this.txtDescrizione.Tag = "";
            // 
            // gboxBilAnnuale
            // 
            this.gboxBilAnnuale.Controls.Add(this.label9);
            this.gboxBilAnnuale.Controls.Add(this.txtCodiceBilancio);
            this.gboxBilAnnuale.Controls.Add(this.txtDenominazioneBilancio);
            this.gboxBilAnnuale.Location = new System.Drawing.Point(8, 256);
            this.gboxBilAnnuale.Name = "gboxBilAnnuale";
            this.gboxBilAnnuale.Size = new System.Drawing.Size(344, 64);
            this.gboxBilAnnuale.TabIndex = 79;
            this.gboxBilAnnuale.TabStop = false;
            this.gboxBilAnnuale.Tag = "";
            // 
            // label9
            // 
            this.label9.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.label9.ImageIndex = 0;
            this.label9.ImageList = this.imageList1;
            this.label9.Location = new System.Drawing.Point(8, 11);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(64, 18);
            this.label9.TabIndex = 3;
            this.label9.Text = "Bilancio";
            this.label9.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // imageList1
            // 
            this.imageList1.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList1.ImageStream")));
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList1.Images.SetKeyName(0, "");
            // 
            // txtCodiceBilancio
            // 
            this.txtCodiceBilancio.Location = new System.Drawing.Point(8, 32);
            this.txtCodiceBilancio.Name = "txtCodiceBilancio";
            this.txtCodiceBilancio.ReadOnly = true;
            this.txtCodiceBilancio.Size = new System.Drawing.Size(136, 21);
            this.txtCodiceBilancio.TabIndex = 1;
            this.txtCodiceBilancio.Tag = "";
            // 
            // txtDenominazioneBilancio
            // 
            this.txtDenominazioneBilancio.Location = new System.Drawing.Point(152, 8);
            this.txtDenominazioneBilancio.Multiline = true;
            this.txtDenominazioneBilancio.Name = "txtDenominazioneBilancio";
            this.txtDenominazioneBilancio.ReadOnly = true;
            this.txtDenominazioneBilancio.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtDenominazioneBilancio.Size = new System.Drawing.Size(184, 48);
            this.txtDenominazioneBilancio.TabIndex = 2;
            this.txtDenominazioneBilancio.TabStop = false;
            this.txtDenominazioneBilancio.Tag = "";
            // 
            // groupCredDeb
            // 
            this.groupCredDeb.Controls.Add(this.txtCredDeb);
            this.groupCredDeb.Location = new System.Drawing.Point(360, 104);
            this.groupCredDeb.Name = "groupCredDeb";
            this.groupCredDeb.Size = new System.Drawing.Size(336, 40);
            this.groupCredDeb.TabIndex = 81;
            this.groupCredDeb.TabStop = false;
            this.groupCredDeb.Tag = "";
            this.groupCredDeb.Text = "Percipiente";
            // 
            // txtCredDeb
            // 
            this.txtCredDeb.Location = new System.Drawing.Point(8, 16);
            this.txtCredDeb.Name = "txtCredDeb";
            this.txtCredDeb.ReadOnly = true;
            this.txtCredDeb.Size = new System.Drawing.Size(320, 21);
            this.txtCredDeb.TabIndex = 1;
            this.txtCredDeb.Tag = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblImportoDisponibile);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.txtImportoDisponibile);
            this.groupBox1.Controls.Add(this.txtImportoCorrente);
            this.groupBox1.Location = new System.Drawing.Point(360, 256);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(336, 64);
            this.groupBox1.TabIndex = 86;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Situazione riassuntiva importo del movimento";
            // 
            // lblImportoDisponibile
            // 
            this.lblImportoDisponibile.Location = new System.Drawing.Point(8, 40);
            this.lblImportoDisponibile.Name = "lblImportoDisponibile";
            this.lblImportoDisponibile.Size = new System.Drawing.Size(192, 20);
            this.lblImportoDisponibile.TabIndex = 0;
            this.lblImportoDisponibile.Text = "Disponibile:";
            this.lblImportoDisponibile.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label12
            // 
            this.label12.Location = new System.Drawing.Point(8, 12);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(200, 24);
            this.label12.TabIndex = 0;
            this.label12.Text = "Attuale (comprensivo delle variazioni):";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtImportoDisponibile
            // 
            this.txtImportoDisponibile.Location = new System.Drawing.Point(227, 40);
            this.txtImportoDisponibile.Name = "txtImportoDisponibile";
            this.txtImportoDisponibile.ReadOnly = true;
            this.txtImportoDisponibile.Size = new System.Drawing.Size(96, 21);
            this.txtImportoDisponibile.TabIndex = 0;
            this.txtImportoDisponibile.TabStop = false;
            this.txtImportoDisponibile.Tag = "";
            this.txtImportoDisponibile.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtImportoCorrente
            // 
            this.txtImportoCorrente.Location = new System.Drawing.Point(227, 16);
            this.txtImportoCorrente.Name = "txtImportoCorrente";
            this.txtImportoCorrente.ReadOnly = true;
            this.txtImportoCorrente.Size = new System.Drawing.Size(96, 21);
            this.txtImportoCorrente.TabIndex = 0;
            this.txtImportoCorrente.TabStop = false;
            this.txtImportoCorrente.Tag = "";
            this.txtImportoCorrente.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // gboxMovimento
            // 
            this.gboxMovimento.Controls.Add(this.btnSelectMov);
            this.gboxMovimento.Controls.Add(this.txtNumeroMovimento);
            this.gboxMovimento.Controls.Add(this.labNum);
            this.gboxMovimento.Controls.Add(this.txtEsercizioMovimento);
            this.gboxMovimento.Controls.Add(this.labEserc);
            this.gboxMovimento.Controls.Add(this.lblFaseMovimento);
            this.gboxMovimento.Controls.Add(this.cmbFaseSpesa);
            this.gboxMovimento.Location = new System.Drawing.Point(8, 32);
            this.gboxMovimento.Name = "gboxMovimento";
            this.gboxMovimento.Size = new System.Drawing.Size(344, 80);
            this.gboxMovimento.TabIndex = 78;
            this.gboxMovimento.TabStop = false;
            this.gboxMovimento.Tag = "";
            this.gboxMovimento.Text = "Movimento";
            // 
            // btnSelectMov
            // 
            this.btnSelectMov.Location = new System.Drawing.Point(15, 17);
            this.btnSelectMov.Name = "btnSelectMov";
            this.btnSelectMov.Size = new System.Drawing.Size(75, 23);
            this.btnSelectMov.TabIndex = 4;
            this.btnSelectMov.Tag = "";
            this.btnSelectMov.Text = "Seleziona";
            this.btnSelectMov.Click += new System.EventHandler(this.btnSelectMov_Click);
            // 
            // txtNumeroMovimento
            // 
            this.txtNumeroMovimento.Location = new System.Drawing.Point(134, 49);
            this.txtNumeroMovimento.Name = "txtNumeroMovimento";
            this.txtNumeroMovimento.Size = new System.Drawing.Size(48, 21);
            this.txtNumeroMovimento.TabIndex = 3;
            this.txtNumeroMovimento.Tag = "";
            this.txtNumeroMovimento.Leave += new System.EventHandler(this.txtNumeroMovimento_Leave);
            // 
            // labNum
            // 
            this.labNum.Location = new System.Drawing.Point(102, 49);
            this.labNum.Name = "labNum";
            this.labNum.Size = new System.Drawing.Size(32, 20);
            this.labNum.TabIndex = 0;
            this.labNum.Text = "Num.";
            this.labNum.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtEsercizioMovimento
            // 
            this.txtEsercizioMovimento.Location = new System.Drawing.Point(52, 49);
            this.txtEsercizioMovimento.Name = "txtEsercizioMovimento";
            this.txtEsercizioMovimento.Size = new System.Drawing.Size(39, 21);
            this.txtEsercizioMovimento.TabIndex = 2;
            this.txtEsercizioMovimento.Tag = "";
            this.txtEsercizioMovimento.Leave += new System.EventHandler(this.txtEsercizioFasePrecedente_Leave);
            // 
            // labEserc
            // 
            this.labEserc.Location = new System.Drawing.Point(12, 49);
            this.labEserc.Name = "labEserc";
            this.labEserc.Size = new System.Drawing.Size(40, 20);
            this.labEserc.TabIndex = 0;
            this.labEserc.Text = "Eserc.";
            this.labEserc.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblFaseMovimento
            // 
            this.lblFaseMovimento.Location = new System.Drawing.Point(102, 19);
            this.lblFaseMovimento.Name = "lblFaseMovimento";
            this.lblFaseMovimento.Size = new System.Drawing.Size(32, 20);
            this.lblFaseMovimento.TabIndex = 0;
            this.lblFaseMovimento.Text = "Fase";
            this.lblFaseMovimento.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbFaseSpesa
            // 
            this.cmbFaseSpesa.DataSource = this.DS.expensephase;
            this.cmbFaseSpesa.DisplayMember = "description";
            this.cmbFaseSpesa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFaseSpesa.Location = new System.Drawing.Point(134, 19);
            this.cmbFaseSpesa.Name = "cmbFaseSpesa";
            this.cmbFaseSpesa.Size = new System.Drawing.Size(198, 21);
            this.cmbFaseSpesa.TabIndex = 1;
            this.cmbFaseSpesa.Tag = "expense.nphase";
            this.cmbFaseSpesa.ValueMember = "nphase";
            this.cmbFaseSpesa.SelectedIndexChanged += new System.EventHandler(this.cmbFaseSpesa_SelectedIndexChanged);
            // 
            // tabDettagli
            // 
            this.tabDettagli.Controls.Add(this.gboxDettInvoice);
            this.tabDettagli.Controls.Add(this.gboxDettmandate);
            this.tabDettagli.Location = new System.Drawing.Point(0, 0);
            this.tabDettagli.Name = "tabDettagli";
            this.tabDettagli.Selected = false;
            this.tabDettagli.Size = new System.Drawing.Size(708, 459);
            this.tabDettagli.TabIndex = 7;
            this.tabDettagli.Title = "Pagina 4 di 5";
            // 
            // gboxDettInvoice
            // 
            this.gboxDettInvoice.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gboxDettInvoice.Controls.Add(this.btnEditInvDet);
            this.gboxDettInvoice.Controls.Add(this.txtTotInvoiceDetail);
            this.gboxDettInvoice.Controls.Add(this.label17);
            this.gboxDettInvoice.Controls.Add(this.btnRemoveDettInvoice);
            this.gboxDettInvoice.Controls.Add(this.btnAddDettInvoice);
            this.gboxDettInvoice.Controls.Add(this.dgrDettagliFattura);
            this.gboxDettInvoice.Location = new System.Drawing.Point(3, 205);
            this.gboxDettInvoice.Name = "gboxDettInvoice";
            this.gboxDettInvoice.Size = new System.Drawing.Size(701, 251);
            this.gboxDettInvoice.TabIndex = 7;
            this.gboxDettInvoice.TabStop = false;
            this.gboxDettInvoice.Text = "Dettagli Fattura";
            // 
            // btnEditInvDet
            // 
            this.btnEditInvDet.Location = new System.Drawing.Point(8, 88);
            this.btnEditInvDet.Name = "btnEditInvDet";
            this.btnEditInvDet.Size = new System.Drawing.Size(75, 23);
            this.btnEditInvDet.TabIndex = 7;
            this.btnEditInvDet.Text = "Modifica..";
            this.btnEditInvDet.Click += new System.EventHandler(this.btnModificaDettInvoice_Click);
            // 
            // txtTotInvoiceDetail
            // 
            this.txtTotInvoiceDetail.Location = new System.Drawing.Point(8, 184);
            this.txtTotInvoiceDetail.Name = "txtTotInvoiceDetail";
            this.txtTotInvoiceDetail.ReadOnly = true;
            this.txtTotInvoiceDetail.Size = new System.Drawing.Size(80, 21);
            this.txtTotInvoiceDetail.TabIndex = 6;
            this.txtTotInvoiceDetail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label17
            // 
            this.label17.Location = new System.Drawing.Point(8, 168);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(48, 16);
            this.label17.TabIndex = 5;
            this.label17.Text = "Totale";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnRemoveDettInvoice
            // 
            this.btnRemoveDettInvoice.Location = new System.Drawing.Point(8, 56);
            this.btnRemoveDettInvoice.Name = "btnRemoveDettInvoice";
            this.btnRemoveDettInvoice.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveDettInvoice.TabIndex = 4;
            this.btnRemoveDettInvoice.Text = "Rimuovi";
            this.btnRemoveDettInvoice.Click += new System.EventHandler(this.btnScollegaDettInvoice_Click);
            // 
            // btnAddDettInvoice
            // 
            this.btnAddDettInvoice.Location = new System.Drawing.Point(8, 24);
            this.btnAddDettInvoice.Name = "btnAddDettInvoice";
            this.btnAddDettInvoice.Size = new System.Drawing.Size(75, 23);
            this.btnAddDettInvoice.TabIndex = 3;
            this.btnAddDettInvoice.Text = "Aggiungi";
            this.btnAddDettInvoice.Click += new System.EventHandler(this.btnCollegaDettInvoice_Click);
            // 
            // dgrDettagliFattura
            // 
            this.dgrDettagliFattura.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgrDettagliFattura.DataMember = "";
            this.dgrDettagliFattura.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgrDettagliFattura.Location = new System.Drawing.Point(96, 16);
            this.dgrDettagliFattura.Name = "dgrDettagliFattura";
            this.dgrDettagliFattura.Size = new System.Drawing.Size(597, 227);
            this.dgrDettagliFattura.TabIndex = 2;
            // 
            // gboxDettmandate
            // 
            this.gboxDettmandate.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.gboxDettmandate.Controls.Add(this.btnEditMandDet);
            this.gboxDettmandate.Controls.Add(this.txtTotMandateDetail);
            this.gboxDettmandate.Controls.Add(this.label16);
            this.gboxDettmandate.Controls.Add(this.btnRemoveDetMandate);
            this.gboxDettmandate.Controls.Add(this.dgrDettagliOrdine);
            this.gboxDettmandate.Controls.Add(this.btnAddDetMandate);
            this.gboxDettmandate.Location = new System.Drawing.Point(5, 4);
            this.gboxDettmandate.Name = "gboxDettmandate";
            this.gboxDettmandate.Size = new System.Drawing.Size(701, 200);
            this.gboxDettmandate.TabIndex = 6;
            this.gboxDettmandate.TabStop = false;
            this.gboxDettmandate.Text = "Dettagli Contratto Passivo";
            // 
            // btnEditMandDet
            // 
            this.btnEditMandDet.Location = new System.Drawing.Point(8, 80);
            this.btnEditMandDet.Name = "btnEditMandDet";
            this.btnEditMandDet.Size = new System.Drawing.Size(75, 23);
            this.btnEditMandDet.TabIndex = 5;
            this.btnEditMandDet.Text = "Modifica..";
            this.btnEditMandDet.Click += new System.EventHandler(this.btnModificaDettOrdine_Click);
            // 
            // txtTotMandateDetail
            // 
            this.txtTotMandateDetail.Location = new System.Drawing.Point(8, 168);
            this.txtTotMandateDetail.Name = "txtTotMandateDetail";
            this.txtTotMandateDetail.ReadOnly = true;
            this.txtTotMandateDetail.Size = new System.Drawing.Size(80, 21);
            this.txtTotMandateDetail.TabIndex = 4;
            this.txtTotMandateDetail.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label16
            // 
            this.label16.Location = new System.Drawing.Point(8, 152);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(48, 16);
            this.label16.TabIndex = 3;
            this.label16.Text = "Totale";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnRemoveDetMandate
            // 
            this.btnRemoveDetMandate.Location = new System.Drawing.Point(8, 48);
            this.btnRemoveDetMandate.Name = "btnRemoveDetMandate";
            this.btnRemoveDetMandate.Size = new System.Drawing.Size(75, 23);
            this.btnRemoveDetMandate.TabIndex = 2;
            this.btnRemoveDetMandate.Text = "Rimuovi";
            this.btnRemoveDetMandate.Click += new System.EventHandler(this.btnScollegaDettOrdine_Click);
            // 
            // dgrDettagliOrdine
            // 
            this.dgrDettagliOrdine.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.dgrDettagliOrdine.DataMember = "";
            this.dgrDettagliOrdine.HeaderForeColor = System.Drawing.SystemColors.ControlText;
            this.dgrDettagliOrdine.Location = new System.Drawing.Point(96, 16);
            this.dgrDettagliOrdine.Name = "dgrDettagliOrdine";
            this.dgrDettagliOrdine.Size = new System.Drawing.Size(597, 176);
            this.dgrDettagliOrdine.TabIndex = 1;
            // 
            // btnAddDetMandate
            // 
            this.btnAddDetMandate.Location = new System.Drawing.Point(8, 16);
            this.btnAddDetMandate.Name = "btnAddDetMandate";
            this.btnAddDetMandate.Size = new System.Drawing.Size(75, 23);
            this.btnAddDetMandate.TabIndex = 0;
            this.btnAddDetMandate.Text = "Aggiungi";
            this.btnAddDetMandate.Click += new System.EventHandler(this.btnCollegaDettOrdine_Click);
            // 
            // tabConfirm
            // 
            this.tabConfirm.Controls.Add(this.labOperazione);
            this.tabConfirm.Location = new System.Drawing.Point(0, 0);
            this.tabConfirm.Name = "tabConfirm";
            this.tabConfirm.Selected = false;
            this.tabConfirm.Size = new System.Drawing.Size(708, 459);
            this.tabConfirm.TabIndex = 5;
            this.tabConfirm.Title = "Pagina 5 di 5";
            // 
            // labOperazione
            // 
            this.labOperazione.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.labOperazione.Location = new System.Drawing.Point(8, 8);
            this.labOperazione.Name = "labOperazione";
            this.labOperazione.Size = new System.Drawing.Size(692, 48);
            this.labOperazione.TabIndex = 0;
            // 
            // btnCancel
            // 
            this.btnCancel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(644, 500);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 13;
            this.btnCancel.Tag = "maincancel";
            this.btnCancel.Text = "Cancel";
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnNext
            // 
            this.btnNext.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnNext.Location = new System.Drawing.Point(524, 500);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(88, 23);
            this.btnNext.TabIndex = 12;
            this.btnNext.Text = "Avanti >";
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnBack
            // 
            this.btnBack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnBack.Location = new System.Drawing.Point(436, 500);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(80, 23);
            this.btnBack.TabIndex = 11;
            this.btnBack.Text = "< Indietro";
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Frm_expense_wizardcontabilizza
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(724, 529);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.tabController);
            this.Name = "Frm_expense_wizardcontabilizza";
            this.Text = "FrmSpesaContabilizza";
            ((System.ComponentModel.ISupportInitialize)(this.DS.address)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.apactivitykind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.casualcontract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expense)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensecasualcontract)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expenseinvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expenseitineration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensemandate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensepayroll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensephase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expenseprofservice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensevar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expensewageaddition)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.expenseyear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.fin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.income)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.incomeinvoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.incomephase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.incomevar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.incomeyear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.invoice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.invoicedetail_iva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.invoicedetail_taxable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.invoicekind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.itineration)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.itinerationresidual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.manager)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.mandate)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.mandatedetail_iva)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.mandatedetail_taxable)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.mandatekind)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.payroll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.profservice)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS.registry)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DS)).EndInit();
            this.tabController.ResumeLayout(false);
            this.tabSelectDoc.ResumeLayout(false);
            this.tabSelectDoc.PerformLayout();
            this.gboxDocumento.ResumeLayout(false);
            this.gboxDocumento.PerformLayout();
            this.tabIntro.ResumeLayout(false);
            this.tabSelectMov.ResumeLayout(false);
            this.groupBox16.ResumeLayout(false);
            this.gboxUPB.ResumeLayout(false);
            this.gboxUPB.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.gboxBilAnnuale.ResumeLayout(false);
            this.gboxBilAnnuale.PerformLayout();
            this.groupCredDeb.ResumeLayout(false);
            this.groupCredDeb.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gboxMovimento.ResumeLayout(false);
            this.gboxMovimento.PerformLayout();
            this.tabDettagli.ResumeLayout(false);
            this.gboxDettInvoice.ResumeLayout(false);
            this.gboxDettInvoice.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrDettagliFattura)).EndInit();
            this.gboxDettmandate.ResumeLayout(false);
            this.gboxDettmandate.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgrDettagliOrdine)).EndInit();
            this.tabConfirm.ResumeLayout(false);
            this.ResumeLayout(false);

		}
		#endregion

		public void MetaData_AfterLink(){
			Meta = MetaData.GetMetaData(this);
			Conn = Meta.Conn;
			GetData.CacheTable(DS.expensephase);
			GetData.CacheTable(DS.incomephase);
			GetData.CacheTable(DS.manager,null,null,true);
			txtEsercizioMovimento.Text= Meta.GetSys("esercizio").ToString();
			fasespesacont= CfgFn.GetNoNullInt32( Meta.GetSys("itinerationphase"));
				//CfgFn.GetNoNullInt32( Conn.DO_READ_VALUE("expensesetup", "(ayear='"+Meta.GetSys("esercizio").ToString()+"')", "fasespesa"));
			faseivaspesa = CfgFn.GetNoNullInt32( Meta.GetSys("invoiceexpensephase"));
				//CfgFn.GetNoNullInt32( Conn.DO_READ_VALUE("invoicesetup", "(ayear='"+Meta.GetSys("esercizio").ToString()+"')", "fasespesa"));

			currcont = tipocont.cont_none;
			string filteresercizio= "(ayear='"+Meta.GetSys("esercizio").ToString()+"')";
			GetData.CacheTable(DS.invoicekind,"(flagbuysell='A')AND(flagvariation='N')",null,true);
			GetData.CacheTable(DS.mandatekind,null,null,true);

            DataAccess.SetTableForReading(DS.mandatedetail_iva, "mandatedetailview");
            DataAccess.SetTableForReading(DS.mandatedetail_taxable, "mandatedetailview");
            QueryCreator.SetTableForPosting(DS.mandatedetail_iva, "mandatedetail");
            QueryCreator.SetTableForPosting(DS.mandatedetail_taxable, "mandatedetail");
            DataAccess.SetTableForReading(DS.invoicedetail_iva, "invoicedetailview");
            DataAccess.SetTableForReading(DS.invoicedetail_taxable, "invoicedetailview");
            QueryCreator.SetTableForPosting(DS.invoicedetail_iva, "invoicedetail");
            QueryCreator.SetTableForPosting(DS.invoicedetail_taxable, "invoicedetail");
            GetData.SetSorting(DS.mandatedetail_iva, "idgroup");
            GetData.SetSorting(DS.mandatedetail_taxable, "idgroup");

		}

		public void MetaData_AfterClear(){
			DisplayTabs(tabController.SelectedIndex);
		}

		#region Gestione Tabs

		/// <summary>
		/// Displays tab n. NewTab and updates buttons
		/// </summary>
		/// <param name="newTab"></param>
		void DisplayTabs(int newTab)
		{
			tabController.SelectedIndex= newTab;
			//Evaluates Buttons Appearance
			btnBack.Visible=(newTab>0);
			if (newTab== tabController.TabPages.Count-1)
				btnNext.Text="Associa.";
			else
				btnNext.Text="Next >";
			Text = CustomTitle+ " (Pagina "+(newTab+1)+" di "+tabController.TabPages.Count+")";
		}
		void StandardChangeTab(int step){
			int oldTab= tabController.SelectedIndex;
			int newTab= oldTab+step;
			if ((newTab<0)||(newTab>tabController.TabPages.Count))return;
			if (!CustomChangeTab(oldTab,newTab))return;
			if (newTab==tabController.TabPages.Count){
				DialogResult= DialogResult.OK;
				Close();
				return;
			}
			DisplayTabs(newTab);
		}
		private void btnBack_Click(object sender, System.EventArgs e) {
			StandardChangeTab(-1);
		}


		private void btnNext_Click(object sender, System.EventArgs e) {
			StandardChangeTab(+1);
		}

		bool CustomChangeTab(int oldTab, int newTab){
			if (oldTab==0) 	{
				return true ; // 0->1: nothing to do
			}
			if ((oldTab==1)&&(newTab==0))return true; //1->0:nothing to do!
			if ((oldTab==1)&&(newTab==2)){
				if (! GetMovimentoSelezionato()) return false; 
				CalcolaContabilizzazioniPossibili();
				AbilitaDisabilitaControlliContabilizzazione(true);
				return true;
			}
			if ((oldTab==2)&&(newTab==1)){
				ClearContabilizzazioni();
				SetContabilizzazione(tipocont.cont_none);
				ClearComboCausale();
				return true;
			}; 
			if ((oldTab==2)&&(newTab==3)){
				if (!GetDocumentoSelezionato()) return false; 
				DataRow Curr = DS.expense.Rows[0];
				labOperazione.Text="Il movimento di spesa "+
						Curr["ymov"].ToString()+"/"+Curr["nmov"].ToString()+
					" sar� associato " + CurrDocDescr;
				return true;
			}
			if ((oldTab==4)&&(newTab==5))return doAssocia(); 
			return true;
		}

		#endregion


		#region Gestione Selezione Movimento

		void ClearContabilizzazioni(){
			DS.expenseitineration.Clear();
			DS.expensemandate.Clear();
			DS.expensepayroll.Clear();
			DS.expensecasualcontract.Clear();
			DS.expenseprofservice.Clear();
			DS.expensewageaddition.Clear();
			DS.expenseinvoice.Clear();

			DS.mandate.Clear();
			DS.itineration.Clear();
			DS.payroll.Clear();
			DS.invoice.Clear();
			DS.casualcontract.Clear();
			DS.profservice.Clear();
			DS.wageaddition.Clear();
		}

		bool GetMovimentoSelezionato()
		{
			if (txtNumeroMovimento.Text.Trim()==""){
				MessageBox.Show("Selezionare un movimento per procedere");
				return false;
			}
			if (currcont!= tipocont.cont_none){
				MessageBox.Show("Al movimento selezionato � gi� associata una contabilizzazione.");
				return false;
			}
			string filter= GetFasePrecFilter(true);
			MetaData MFase = MetaData.GetMetaData(this,"expense");
			MFase.FilterLocked=true;
			MFase.DS=DS.Copy();
			
			DataRow MyDR = MFase.SelectOne("default",filter,null,null);
			if (MyDR==null) return false;
			AddAllCollegate(MyDR);

			string keyspesafilter= "(idexp="+QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")";
			keyspesafilter+="AND(ayear='"+Meta.GetSys("esercizio").ToString()+"')";
			currimp= CfgFn.GetNoNullDecimal(Conn.DO_READ_VALUE("expenseview", keyspesafilter, 
				"curramount"));

			DS.expenseitineration.Clear();
			DS.expensepayroll.Clear();
			DS.expensemandate.Clear();
			DS.expenseinvoice.Clear();
			DS.expenseprofservice.Clear();
			DS.expensecasualcontract.Clear();
			DS.expensewageaddition.Clear();
			return true;
		}

		void AddVociFiglieWhereEmpty(DataTable T, string filter){
			if (T.Select(filter).Length>0) return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,T,null,filter,null,true);
		}

		void AddVoceBilancio(string ID){
			if (ID=="") return;
			if (DS.fin.Select("(idfin="+
				QueryCreator.quotedstrvalue(ID,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.fin,null,"(idfin="+
				QueryCreator.quotedstrvalue(ID,true)+")",null,true);			
		}
		void AddVoceUPB(string ID){
			if (ID=="") return;
			if (DS.upb.Select("(idupb="+
				QueryCreator.quotedstrvalue(ID,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.upb,null,"(idupb="+
				QueryCreator.quotedstrvalue(ID,true)+")",null,true);			
		}

		void AddVoceFaseSpesa(string codice){
			if (codice=="") return;
			if (DS.expensephase.Select("(nphase="+
				QueryCreator.quotedstrvalue(codice,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expensephase,null,"(nphase="+
				QueryCreator.quotedstrvalue(codice,true)+")",null,true);			

		}
		void AddVoceFaseEntrata(string codice){
			if (codice=="") return;
			if (DS.incomephase.Select("(nphase="+
				QueryCreator.quotedstrvalue(codice,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.incomephase,null,"(nphase="+
				QueryCreator.quotedstrvalue(codice,true)+")",null,true);			
		}

		void AddVoceCreditore(string codice){
			if (codice=="")return;
			if (DS.registry.Select("(idreg="+
				QueryCreator.quotedstrvalue(codice,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.registry,null,"(idreg="+
				QueryCreator.quotedstrvalue(codice,true)+")",null,true);			
		}
		void AddVoceResponsabile(string codice){
			if (codice=="")return;
			if (DS.manager.Select("(idman="+
				QueryCreator.quotedstrvalue(codice,false)+")").Length>0)return;
			DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.manager,null,"(idman="+
				QueryCreator.quotedstrvalue(codice,true)+")",null,true);			
		}

		void AddVociCollegate(DataRow Row){
			
			if (Row.Table.TableName == "expense")
				AddVoceFaseSpesa(Row["nphase"].ToString());
			else
				AddVoceFaseEntrata(Row["nphase"].ToString());
			AddVoceCreditore(Row["idreg"].ToString());
			AddVoceResponsabile(Row["idman"].ToString());
			DataRow Imputazione=null;
			if (Row.Table.TableName == "expense"){
				DataRow [] Imputazioni = Row.GetChildRows("expenseexpenseyear");
				if (Imputazioni.Length>0) Imputazione= Imputazioni[0];
			}
			else {
				DataRow [] Imputazioni = Row.GetChildRows("incomeincomeyear");
				if (Imputazioni.Length>0) Imputazione= Imputazioni[0];
			}
			if (Imputazione!=null) {
				AddVoceBilancio(Imputazione["idfin"].ToString());
				AddVoceUPB(Imputazione["idupb"].ToString());
			}
		}

		void AddVociFiglie(DataRow Mov){
			string filter;
			int fasespesamax= MetaData.MaxFromColumn(DS.expensephase,"nphase");
			int faseentratamax= MetaData.MaxFromColumn(DS.incomephase,"nphase");
			//			int fasespesacont= CfgFn.GetNoNullInt32( Conn.DO_READ_VALUE("persspesa",
			//				"(esercizio='"+Conn.sys["esercizio"].ToString()+"')",
			//				"fasespesa"));
			//			int faseivaspesa = CfgFn.GetNoNullInt32( Conn.DO_READ_VALUE("persiva",
			//				"(esercizio='"+Conn.sys["esercizio"].ToString()+"')",
			//				"fasespesa"));
			int faseivaentrata = CfgFn.GetNoNullInt32(Meta.GetSys("invoiceincomephase"));
				//CfgFn.GetNoNullInt32( Conn.DO_READ_VALUE("invoicesetup", 
				//				"(ayear='"+Meta.GetSys("esercizio").ToString()+"')", "faseentrata"));

			DataRow []BilEnt = DS.incomephase.Select("(flagfinance='S')");
			int fasebilent = Convert.ToInt32(BilEnt[0]["nphase"]);

			if (Mov.Table.TableName == "expense"){
				int lenidspesa=Mov["idexp"].ToString().Length;

				filter= "(idexp="+
					QueryCreator.quotedstrvalue(Mov["idexp"].ToString(),true)
					+")";

				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expensemandate,filter);
				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expenseitineration,filter);
				if (lenidspesa == faseivaspesa*8)
					AddVociFiglieWhereEmpty(DS.expenseinvoice,filter);
				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expensepayroll,filter);
				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expensecasualcontract,filter);
				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expenseprofservice,filter);
				if (lenidspesa == fasespesacont*8)
					AddVociFiglieWhereEmpty(DS.expensewageaddition,filter);

				AddVociFiglieWhereEmpty(DS.expensevar,filter);
				AddVociFiglieWhereEmpty(DS.expenseyear,filter);
			}
			else {
				int lenidentrata=Mov["idinc"].ToString().Length;
				filter= "(idinc="+
					QueryCreator.quotedstrvalue(Mov["idinc"].ToString(),true)
					+")";

				AddVociFiglieWhereEmpty(DS.incomevar,filter);
				AddVociFiglieWhereEmpty(DS.incomeyear,filter);

				if (lenidentrata == faseivaentrata*8)
					AddVociFiglieWhereEmpty(DS.incomeinvoice,filter);
			}
		}


		void AddAllCollegate(DataRow R){
			DS.expense.Clear();
			DS.income.Clear();

			DS.expensemandate.Clear();
			DS.expenseitineration.Clear();
			DS.expensepayroll.Clear();
			DS.expenseprofservice.Clear();
			DS.expensecasualcontract.Clear();
			DS.expensewageaddition.Clear();
			DS.expenseinvoice.Clear();
			DS.incomeinvoice.Clear();

			DS.incomeyear.Clear();
			DS.expenseyear.Clear();
			DS.incomevar.Clear();
			DS.expensevar.Clear();

			int NSpesa = DS.expense.Rows.Count;
			int NEntrata = DS.income.Rows.Count;
			string filter;
			DataRow Curr;
			if (R.Table.TableName.StartsWith("expense")){
				filter= "(idexp="+
					QueryCreator.quotedstrvalue(R["idexp"].ToString(),true)
					+")";
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expense,null,filter,null,true);
				Curr= DS.expense.Rows[0];
				
			}
			else {
				filter= "(idinc="+
					QueryCreator.quotedstrvalue(R["idinc"].ToString(),true)
					+")";
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.income,null,filter,null,true);
				Curr=DS.income.Rows[0];
			}

			foreach (DataRow R1 in DS.expense.Rows){
				AddVociFiglie(R1);
				AddVociCollegate(R1);
			}
			foreach (DataRow R2 in DS.income.Rows){
				AddVociFiglie(R2);
				AddVociCollegate(R2);
			}


		}


		string GetFasePrecFilter(bool FiltraNumMovimento){
            string filterfase = "";
            if(cmbFaseSpesa.SelectedIndex > 0) {
                string codicefase = cmbFaseSpesa.SelectedValue.ToString();
                int codfase = Convert.ToInt16(codicefase);
                filterfase="(nphase='" + Convert.ToString(codfase) + "')AND";
            }
			string MyFilter=filterfase+
				"(ayear='"+Meta.GetSys("esercizio").ToString()+"')";
			if(txtEsercizioMovimento.Text.Trim() != "")
				MyFilter +=  "AND(ymov='" + txtEsercizioMovimento.Text.Trim() + "')";
			if((FiltraNumMovimento) && (txtNumeroMovimento.Text.Trim()!=""))
				MyFilter += "AND(nmov = '" + txtNumeroMovimento.Text.Trim() +"')";

			return MyFilter;
		}

		private void btnSelectMov_Click(object sender, System.EventArgs e) {
			string MyFilter; 
			
			if (((Control)sender).Name == "txtNumeroMovimento")
				MyFilter = GetFasePrecFilter(true);
			else
				MyFilter = GetFasePrecFilter(false);

			MetaData MFase = MetaData.GetMetaData(this,"expense");
			MFase.FilterLocked=true;
			MFase.DS=DS;
			
			DataRow MyDR = MFase.SelectOne("default",MyFilter,null,null);
			
			if(MyDR == null) {
				if (Meta.InsertMode){
					if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
						if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
					}
				}
				currcont=tipocont.cont_none;
				return;
			}
            DS.RejectChanges();
            Meta.DoMainCommand("mainsetsearch");
            string keyfilter = "(idexp=" + QueryCreator.quotedstrvalue(MyDR["idexp"], true) + ")";
            DataRow SEL = Meta.SelectOne("default", keyfilter, null, null);
            Meta.SelectRow(SEL, "default");

					
			//txtCredDeb.Text = MyDR["denominazione"].ToString();		
			txtEsercizioMovimento.Text=MyDR["ymov"].ToString();
			txtNumeroMovimento.Text=MyDR["nmov"].ToString();

			txtCredDeb.Text= MyDR["registry"].ToString();
			txtDescrizione.Text= MyDR["description"].ToString();
			SubEntity_txtImportoMovimento.Text= CfgFn.GetNoNullDecimal(MyDR["amount"]).ToString("c");
			txtDataCont.Text= ((DateTime)MyDR["adate"]).ToShortDateString();
			txtCodiceBilancio.Text=MyDR["codefin"].ToString();
			txtDenominazioneBilancio.Text=MyDR["finance"].ToString();			
			HelpForm.SetComboBoxValue(SubEntity_comboUPB,MyDR["idupb"].ToString());
			txtDescrUPB.Text=MyDR["upb"].ToString();
			HelpForm.SetComboBoxValue(cmbResponsabile,MyDR["idman"].ToString());
            HelpForm.SetComboBoxValue(cmbFaseSpesa, MyDR["nphase"].ToString());

			
			txtImportoCorrente.Text= CfgFn.GetNoNullDecimal(MyDR["curramount"]).ToString("c");
			txtImportoDisponibile.Text= CfgFn.GetNoNullDecimal(MyDR["available"]).ToString("c");

			DS.expenseitineration.Clear();
			DS.expensemandate.Clear();
			DS.expenseinvoice.Clear();
			DS.expensepayroll.Clear();
			DS.expensecasualcontract.Clear();
			DS.expenseprofservice.Clear();
			DS.expensewageaddition.Clear();
            DS.mandatedetail_iva.Clear();
            DS.mandatedetail_taxable.Clear();
            DS.invoicedetail_iva.Clear();
            DS.invoicedetail_taxable.Clear();

			int lenidspesa= MyDR["idexp"].ToString().Length;
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expensemandate,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expenseitineration,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == faseivaspesa*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expenseinvoice,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expensepayroll,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expensecasualcontract,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expenseprofservice,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);
			if (lenidspesa == fasespesacont*8)
				DataAccess.RUN_SELECT_INTO_TABLE(Conn,DS.expensewageaddition,null,"(idexp="+
					QueryCreator.quotedstrvalue(MyDR["idexp"],true)+")",null,true);


			currcont=DeduciTipoContabilizzazione();

			if (currcont==tipocont.cont_none) {
				labContabAttuale.Text="";
				return;
			}

			string MSG;
			MSG = "Il movimento di spesa selezionato contabilizza ";
			switch(currcont){
				case tipocont.cont_missione: 
					DataRow Mis = DS.expenseitineration.Rows[0];
					MSG+= "la missione "+Mis["yitineration"].ToString()+"/"+Mis["nitineration"].ToString()+".";
					break;
				case tipocont.cont_cedolino: 
					DataRow Ced = DS.expensepayroll.Rows[0];
					int mese= CfgFn.GetNoNullInt32(Meta.Conn.DO_READ_VALUE("payroll", "(idpayroll="+QueryCreator.quotedstrvalue(Ced["idpayroll"]
						,true)+")", "npayroll"));
					int anno= CfgFn.GetNoNullInt32(Meta.Conn.DO_READ_VALUE("payroll", "(idpayroll="+QueryCreator.quotedstrvalue(Ced["idpayroll"]
						,true)+")", "fiscalyear"));


					MSG+= "il cedolino  "+anno.ToString()+"/"+mese.ToString()+".";
					break;

				case tipocont.cont_iva: 
					DataRow Iva = DS.expenseinvoice.Rows[0];
					string codicetipodoc = Iva["idinvkind"].ToString();
					DataRow[] TipoDoc= DS.invoicekind.Select("idinvkind="+
						QueryCreator.quotedstrvalue(codicetipodoc,false));
					string TIPO="";
					if (TipoDoc.Length==1){
						TIPO= "("+TipoDoc[0]["description"].ToString()+")";
					}
					MSG+= "il documento iva "+TIPO+" "+ 
						Iva["yinv"].ToString()+"/"+Iva["ninv"].ToString()+".";
					break;
				case tipocont.cont_ordine: 
					DataRow Ord = DS.expensemandate.Rows[0];
					string codicetipoord = Ord["idmankind"].ToString();
					DataRow[] TipoOrd= DS.mandatekind.Select("idmankind="+
						QueryCreator.quotedstrvalue(codicetipoord,false));
					string TIPOORD="";
					if (TipoOrd.Length==1){
						TIPOORD= "("+TipoOrd[0]["description"].ToString()+")";
					}
					MSG+= "il contratto passivo "+TIPOORD+" "+ 
						Ord["yman"].ToString()+"/"+Ord["nman"].ToString()+".";
					break;
				case tipocont.cont_occasionale: 
					DataRow Occ = DS.expensecasualcontract.Rows[0];
					MSG+= "il contratto occasionale "+Occ["ycon"].ToString()+"/"+Occ["ncon"].ToString()+".";
					break;
				case tipocont.cont_professionale: 
					DataRow Prof = DS.expenseprofservice.Rows[0];
					MSG+= "il contratto professionale "+Prof["ycon"].ToString()+"/"+Prof["ncon"].ToString()+".";
					break;
				case tipocont.cont_dipendente: 
					DataRow Dip = DS.expensewageaddition.Rows[0];
					MSG+= "il compenso a dipendente "+Dip["ycon"].ToString()+"/"+Dip["ncon"].ToString()+".";
					break;
			}
			labContabAttuale.Text= MSG;
            
	
		}
		public tipocont currcont;



		private void txtNumeroMovimento_Leave(object sender, System.EventArgs e) {
			if (txtNumeroMovimento.Text.Trim()==""){
				Clear(true);
				return;
			}
			btnSelectMov_Click(sender,e);
		}




		private void txtEsercizioFasePrecedente_Leave(object sender, System.EventArgs e) {			
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercizioMovimento);		
			Clear(false);
			//CalcolaStartFilter(null);

		}

		#endregion

		private void FormattaDataDelTexBox(TextBox TB) 
		{
			if(!TB.Modified)return;
			HelpForm.FormatLikeYear(TB);
		}

		private void btnCancel_Click(object sender, System.EventArgs e) {
			DS.AcceptChanges();
			Close();
		}


		private void cmbFaseSpesa_SelectedIndexChanged(object sender, System.EventArgs e) {
			Clear(true);
		}
		void Clear(bool all){
			txtNumeroMovimento.Text="";
			if (all) txtCredDeb.Text= "";
			txtDescrizione.Text= "";
			SubEntity_txtImportoMovimento.Text= "";
			txtDataCont.Text= "";
			txtCodiceBilancio.Text="";
			txtDenominazioneBilancio.Text="";
			SubEntity_comboUPB.SelectedIndex=0;
			txtDescrUPB.Text="";
			cmbResponsabile.SelectedIndex=0;

			txtImportoCorrente.Text= "";
			txtImportoDisponibile.Text= "";
			currcont=tipocont.cont_none;
			gboxDocumento.Visible=false;

		}






		bool GetDocumentoSelezionato(){
			tipocont TC = DeduciTipoContabilizzazione();
			if (TC==tipocont.cont_none) {
				MessageBox.Show("Non � stato selezionato alcun documento da contabilizzare.");
				return false;
			}
			if (cmbCausale.SelectedValue==null){
				MessageBox.Show("Non � stata selezionata la causale del documento.");
				return false;
			}
			switch (TC){
				case tipocont.cont_iva:
					DataRow CurrIva= DS.invoice.Rows[0];
					CurrDocDescr="al documento iva "+CurrIva["yinv"].ToString()+
										"/"+CurrIva["ninv"].ToString();
					break;
				case tipocont.cont_missione:
					DataRow CurrMiss= DS.itineration.Rows[0];
					CurrDocDescr="alla missione "+CurrMiss["yitineration"].ToString()+
						"/"+CurrMiss["nitineration"].ToString();
					break;
				case tipocont.cont_ordine:
					DataRow CurrOrd= DS.mandate.Rows[0];
					CurrDocDescr="al contratto passivo "+CurrOrd["yman"].ToString()+
						"/"+CurrOrd["nman"].ToString();
					break;
				case tipocont.cont_cedolino:
					DataRow CurrCed= DS.payroll.Rows[0];
					CurrDocDescr="al cedolino "+CurrCed["fiscalyear"].ToString()+
						"/"+CurrCed["npayroll"].ToString();
					break;
				case tipocont.cont_occasionale:
					DataRow CurrOcc= DS.casualcontract.Rows[0];
					CurrDocDescr="al contratto occasionale "+CurrOcc["ycon"].ToString()+
						"/"+CurrOcc["ncon"].ToString();
					break;
				case tipocont.cont_professionale:
					DataRow CurrProf= DS.profservice.Rows[0];
					CurrDocDescr="al contratto professionale "+CurrProf["ycon"].ToString()+
						"/"+CurrProf["ncon"].ToString();
					break;
				case tipocont.cont_dipendente:
					DataRow CurrDip= DS.wageaddition.Rows[0];
					CurrDocDescr="al compenso dipendente "+CurrDip["ycon"].ToString()+
						"/"+CurrDip["ncon"].ToString();
					break;

			}
			
			return true;
		}

		bool doAssocia(){
				
			DataRow Curr= DS.expense.Rows[0];

			
			if (MessageBox.Show(this,"Aggiorno i campi documento e data documento del movimento di spesa "+
				"in base al documento selezionato?","Conferma",MessageBoxButtons.OKCancel)==DialogResult.OK) {
				if ((NuovoDocumento!=null)&&(NuovoDocumento!=DBNull.Value)) Curr["doc"]= NuovoDocumento;
				if (NuovoDataDocumento!=null)  Curr["docdate"]= NuovoDataDocumento;
			}
			if (MessageBox.Show(this,"Aggiorno il campo DESCRIZIONE del movimento di spesa "+
				"in base al documento selezionato?","Conferma",MessageBoxButtons.OKCancel)==DialogResult.OK){
				if ((NuovoDescrizione!=null)&&(NuovoDescrizione!=DBNull.Value)) Curr["description"]= NuovoDescrizione;
			}
			
			
			PostData Post = Meta.Get_PostData();
			Post.InitClass(DS,Conn);
			bool res= Post.DO_POST();
			if (res)MessageBox.Show("Aggiunta della contabilizzazione eseguita con successo.");
			if (!res) Curr.RejectChanges();
			return res;
		}



		#region Gestione ComboBox Causali (generico)

		/// <summary>
		/// Svuota la tabella DS.tipomovimento, a cui � agganciato il combo causale
		/// </summary>
		void ClearComboCausale(){
			DataTable TCombo= DS.tipomovimento;
			TCombo.Clear();
			cmbCausale.Enabled=false;
		}

		void EnableTipoMovimento(string IDtipo, string descrtipo){
			DataRow R = DS.tipomovimento.NewRow();
			R["idtipo"]= IDtipo;
			R["descrizione"]= descrtipo;
			DS.tipomovimento.Rows.Add(R);
			DS.tipomovimento.AcceptChanges();
		}

		/// <summary>
		/// Restituisce la contabilizzazione selezionata nel combobox cmbTipoContabilizz.
		/// </summary>
		/// <returns></returns>
		tipocont ContabilizzazioneSelezionata(){
			if (cmbTipoContabilizzazione.Items.Count==0) return tipocont.cont_none;
			if (cmbTipoContabilizzazione.SelectedItem == null) return tipocont.cont_none;
			string currTipo = cmbTipoContabilizzazione.SelectedItem.ToString();
			tipocont codecont= CodiceContabilizzazione(currTipo);
			return codecont;
		}
		private void cmbTipoContabilizzazione_SelectedIndexChanged(object sender, System.EventArgs e) {
			if (!cmbTipoContabilizzazione.Enabled) return;
			tipocont codecont = ContabilizzazioneSelezionata();
			AttivaContabilizzazione(codecont);
		}
		

		/// <summary>
		/// Imposta il valore del combobox ed aggiorna l'importo del movimento
		/// </summary>
		/// <param name="tipomovimento"></param>
		void SetValueComboCausale(string tipomovimento){
			cmbCausale.SelectedValue= tipomovimento;
			RecalcImporto();
		}

		void RecalcImporto(){
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_missione:
					ReCalcImporto_Missione();
					return;
				case tipocont.cont_ordine:
					ReCalcImporto_Ordine();
					return;
				case tipocont.cont_iva:
					ReCalcImporto_Iva();
					return;
				case tipocont.cont_cedolino:
					ReCalcImporto_Cedolino();
					return;
				case tipocont.cont_occasionale:
					ReCalcImporto_Occasionale();
					return;
				case tipocont.cont_professionale:
					ReCalcImporto_Professionale();
					return;
				case tipocont.cont_dipendente:
					ReCalcImporto_Dipendente();
					return;
				case tipocont.cont_none:
					return;
			}
		}


		#endregion

		#region Gestione Documenti Contabilizzazione

		private void cmbCausale_SelectedIndexChanged(object sender, System.EventArgs e) {
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_missione:
					cmbCausaleMissione_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_ordine:
					cmbCausaleOrdine_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_iva:
					cmbCausaleIva_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_cedolino:
					cmbCausaleCedolino_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_occasionale:
					cmbCausaleOccasionale_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_professionale:
					cmbCausaleProfessionale_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_dipendente:
					cmbCausaleDipendente_SelectedIndexChanged(sender,e);
					break;
			}
		}

		private void btnDocumento_Click(object sender, System.EventArgs e) {
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_missione:
					btnMissione_Click(sender,e);
					break;
				case tipocont.cont_ordine:
					btnOrdine_Click(sender,e);
					break;
				case tipocont.cont_iva:
					btnIva_Click(sender,e);
					break;
				case tipocont.cont_cedolino:
					btnCedolino_Click(sender,e);
					break;
				case tipocont.cont_professionale:
					btnProfessionale_Click(sender,e);
					break;
				case tipocont.cont_occasionale:
					btnOccasionale_Click(sender,e);
					break;
				case tipocont.cont_dipendente:
					btnDipendente_Click(sender,e);
					break;
			}
		}

		private void txtEsercDoc_Leave(object sender, System.EventArgs e) {
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_missione:
					txtEsercMissione_Leave(sender,e);
					break;
				case tipocont.cont_ordine:
					txtEsercOrdine_Leave(sender,e);
					break;
				case tipocont.cont_iva:
					txtEsercIva_Leave(sender,e);
					break;
				case tipocont.cont_cedolino:
					txtEsercCedolino_Leave(sender,e);
					break;
				case tipocont.cont_occasionale:
					txtEsercOccasionale_Leave(sender,e);
					break;
				case tipocont.cont_professionale:
					txtEsercProfessionale_Leave(sender,e);
					break;
				case tipocont.cont_dipendente:
					txtEsercDipendente_Leave(sender,e);
					break;
				
			}
		}

		private void txtNumDoc_Leave(object sender, System.EventArgs e) {
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_missione:
					txtNumMissione_Leave(sender,e);
					break;
				case tipocont.cont_ordine:
					txtNumOrdine_Leave(sender,e);
					break;
				case tipocont.cont_iva:
					txtNumIva_Leave(sender,e);
					break;
				case tipocont.cont_cedolino:
					txtNumCedolino_Leave(sender,e);
					break;
				case tipocont.cont_occasionale:
					txtNumOccasionale_Leave(sender,e);
					break;
				case tipocont.cont_professionale:
					txtNumProfessionale_Leave(sender,e);
					break;
				case tipocont.cont_dipendente:
					txtNumDipendente_Leave(sender,e);
					break;
			}
		}

		private void cmbTipoDocumentoGenerico_SelectedIndexChanged(object sender, System.EventArgs e) {
			tipocont currcont= ContabilizzazioneSelezionata();
			switch (currcont){
				case tipocont.cont_ordine:
					cmbTipoOrdine_SelectedIndexChanged(sender,e);
					break;
				case tipocont.cont_iva:
					cmbTipoDocumento_SelectedIndexChanged(sender,e);
					break;
			}
		}

		tipocont DeduciTipoContabilizzazione(){
			if (DS.expenseitineration.Rows.Count>0) return tipocont.cont_missione;
			if (DS.expensemandate.Rows.Count>0) return tipocont.cont_ordine;
			if (DS.expenseinvoice.Rows.Count>0) return tipocont.cont_iva;
			if (DS.expensepayroll.Rows.Count>0) return tipocont.cont_cedolino;
			if (DS.expenseprofservice.Rows.Count>0) return tipocont.cont_professionale;
			if (DS.expensecasualcontract.Rows.Count>0) return tipocont.cont_occasionale;
			if (DS.expensewageaddition.Rows.Count>0) return tipocont.cont_dipendente;
			return tipocont.cont_none;
		}

		// DEVO CONTINUARE DA QUI <<<<<<<<<<<<<<<<<<<<----------------------->>>>>>>>>>>>>>>>>>>>>>>>
		

		
		/// <summary>
		/// Imposta il combo del tipo contabilizzazione con un valore assegnato
		/// </summary>
		/// <param name="tipo"></param>
		void SetContabilizzazione(tipocont tipo){
			for (int i=0; i< cmbTipoContabilizzazione.Items.Count; i++){
				if (cmbTipoContabilizzazione.Items[i].ToString()== 
					NomeContabilizzazione(tipo)){
					cmbTipoContabilizzazione.SelectedIndex=i;
				}
			}
		}

		/// <summary>
		/// Ricalcola il combo delle contabilizzazioni in base alle fasi selezionate,
		///  ed eventualmente scollega i documenti non pi� collegabili
		/// </summary>
//		void GestioneFasePerDocumentoCollegato(){
//			tipocont oldcont = ContabilizzazioneSelezionata();
//			//disabilita gli eventi collegati al cmbTipoContabilizzazione
//			cmbTipoContabilizzazione.Enabled=false;
//			cmbTipoContabilizzazione.Items.Clear();
//			CalcolaContabilizzazioniPossibili();
//			if (ContabilizzazioneAttivabile(oldcont)){
//				SetContabilizzazione(oldcont);
//				if (!Meta.EditMode) cmbTipoContabilizzazione.Enabled=true;
//				VisualizzaControlliContabilizzazione(oldcont);
//				return;
//			}
//			if (!Meta.EditMode)cmbTipoContabilizzazione.Enabled=true;
//			SetContabilizzazione(tipocont.cont_none);
//			AttivaContabilizzazione(tipocont.cont_none);
//		}
//
		void AbilitaDisabilitaControlliContabilizzazione(bool abilita){
			cmbCausale.Enabled= abilita ;
			cmbTipoDocumento.Enabled= abilita ;
			btnDocumento.Enabled=abilita ;
			txtEsercDoc.ReadOnly=(!abilita) ;
			txtNumDoc.ReadOnly=(!abilita);
			cmbTipoContabilizzazione.Enabled=abilita ;
		}

		/// <summary>
		/// Visualizza/Nasconde i controlli relativi alla contabilizzazione scelta, 
		///  (inclusi btn, txtCredDeb, etc. ) impostandone anche i tag. 
		/// </summary>
		/// <param name="codecont"></param>
		void VisualizzaControlliContabilizzazione(tipocont codecont){
			cmbCausale.Visible=true;
			labelCausale.Visible=true;
			gboxDocumento.Visible=true;
			txtEsercDoc.ReadOnly= false;
			txtNumDoc.ReadOnly= false;
			btnDocumento.Enabled= true;
			cmbTipoDocumento.Enabled = true;
            gboxDettInvoice.Visible = false;
            gboxDettmandate.Visible = false;

			switch(codecont){
				case tipocont.cont_missione:
					labEserc.Text="Eserc.";
					labNum.Text="Num.";
					labelTipoDocumento.Visible=false;
					cmbTipoDocumento.Visible=false;
					btnDocumento.Text="Missione";
					txtEsercDoc.Tag=
						"expenseitineration.yitineration?"+
						"itinerationexpensedownview.yitineration";
					txtNumDoc.Tag="expenseitineration.nitineration?"+
						"itinerationexpensedownview.nitineration";
					cmbTipoDocumento.Tag= null;
					AbilitaDisabilitaControlliMissione(false);
					//					txtDataInizioPrest.ReadOnly=true;
					//					txtDataFinePrest.ReadOnly=true;
					//					btnPrestazione.Enabled=false;
					//					cmbTipoprestazione.Enabled=false;
					//					btnCalcoloGuidato.Enabled=false;
					break;
				case tipocont.cont_iva:
					labEserc.Text="Eserc.";
					labNum.Text="Num.";
					labelTipoDocumento.Visible=true;
					cmbTipoDocumento.Visible=true;
					btnDocumento.Text="Documento";
					txtEsercDoc.Tag=
						"expenseinvoice.yinv?"+
						"expenseinvoiceview.yinv";
					txtNumDoc.Tag=
						"expenseinvoice.ninv?"+
						"expenseinvoiceview.ninv";
					cmbTipoDocumento.Tag=
						"expenseinvoice.idinvkind?"+
						"expenseinvoiceview.idinvkind";
					ImpostaComboInvoiceKind();
					AbilitaDisabilitaControlliIva(true);
					break;
				case tipocont.cont_ordine:
					labelTipoDocumento.Visible=true;
					cmbTipoDocumento.Visible=true;
					labEserc.Text="Eserc.";
					labNum.Text="Num.";
					btnDocumento.Text="Contratto Passivo";
					txtEsercDoc.Tag=
						"expensemandate.yman?"+
						"expensemandateview.yman";
					txtNumDoc.Tag="expensemandate.nman?"+
						"expensemandateview.nman";
					cmbTipoDocumento.Tag=
						"expensemandate.idmankind?"+
						"expensemandateview.idmankind";
					ImpostaComboMandateKind();
                    AbilitaDisabilitaControlliOrdine(true);
					break;
				case tipocont.cont_cedolino:
					cmbCausale.Visible=false;
					labelCausale.Visible=false;
					labEserc.Text="Eserc";	//"Anno";
					labNum.Text="Num";	//"Mese";

					labelTipoDocumento.Visible=false;
					cmbTipoDocumento.Visible=false;
					btnDocumento.Text="Cedolino";
					txtEsercDoc.Tag=
						"payroll.fiscalyear?"+
						"expensepayrollview.fiscalyear";
					txtNumDoc.Tag="payroll.npayroll?"+
						"expensepayrollview.npayroll";
					cmbTipoDocumento.Tag= null;
					AbilitaDisabilitaControlliCedolino(false);
					break;
				case tipocont.cont_occasionale:
					cmbCausale.Visible=false;
					labelCausale.Visible=false;
					gboxDocumento.Visible=true;
					labEserc.Text="Eserc.";
					labNum.Text="Num.";

					labelTipoDocumento.Visible=false;
					cmbTipoDocumento.Visible=false;
					btnDocumento.Text="Contratto Occasionale";
					txtEsercDoc.Tag=
						"expensecasualcontract.ycon?"+
						"expensecasualcontractview.ycon";
					txtNumDoc.Tag="expensecasualcontract.ncon?"+
						"expensecasualcontractview.ncon";
					cmbTipoDocumento.Tag= null;
					AbilitaDisabilitaControlliCedolino(false);
					break;
				case tipocont.cont_professionale:
					cmbCausale.Visible=true;
					labelCausale.Visible=true;
					gboxDocumento.Visible=true;
					labEserc.Text="Eserc.";
					labNum.Text="Num.";

					labelTipoDocumento.Visible=false;
					cmbTipoDocumento.Visible=false;
					btnDocumento.Text="Contratto Professionale";
					txtEsercDoc.Tag=
						"expenseprofservice.ycon?"+
						"expenseprofserviceview.ycon";
					txtNumDoc.Tag="expenseprofservice.ncon?"+
						"expenseprofserviceview.ncon";
					cmbTipoDocumento.Tag= null;
					AbilitaDisabilitaControlliProfessionale(false);
					break;
				case tipocont.cont_dipendente:
					cmbCausale.Visible=false;
					labelCausale.Visible=false;
					gboxDocumento.Visible=true;
					labEserc.Text="Eserc.";
					labNum.Text="Num.";

					labelTipoDocumento.Visible=false;
					cmbTipoDocumento.Visible=false;
					btnDocumento.Text="Contratto Dipendente";
					txtEsercDoc.Tag=
						"expensewageaddition.ycon?"+
						"expensewageadditionview.ycon";
					txtNumDoc.Tag="expensewageaddition.ncon?"+
						"expensewageadditionview.ncon";
					cmbTipoDocumento.Tag= null;
					AbilitaDisabilitaControlliDipendente(false);
					break;


				case tipocont.cont_none:
					cmbTipoDocumento.Tag= null;
					txtEsercDoc.Tag=null;
					txtNumDoc.Tag=null;
					NascondiControlliContabilizzazione();
					break;
			}
			//ClearComboCausale();
		}

		void ImpostaComboMandateKind(){
			if (cmbTipoDocumento.DataSource!=null){
				DataTable T = cmbTipoDocumento.DataSource as DataTable;
				if (T.Columns["idmankind"]!=null) return;
			}
			TipoDocChangePilotato=true;
			cmbTipoDocumento.DataSource= DS.mandatekind;
			cmbTipoDocumento.DisplayMember="title";
			cmbTipoDocumento.ValueMember="idmankind";
			Meta.myHelpForm.PreFillControlsTable(cmbTipoDocumento,null);
			TipoDocChangePilotato=false;
		}

		void ImpostaComboInvoiceKind(){
			if (cmbTipoDocumento.DataSource!=null){
				DataTable T = cmbTipoDocumento.DataSource as DataTable;
				if (T.Columns["idinvkind"]!=null) return;
			}
			TipoDocChangePilotato=true;
			cmbTipoDocumento.DataSource= DS.invoicekind;
			cmbTipoDocumento.DisplayMember="description";
			cmbTipoDocumento.ValueMember="idinvkind";
			Meta.myHelpForm.PreFillControlsTable(cmbTipoDocumento,null);
			TipoDocChangePilotato=false;
		}

		void NascondiControlliContabilizzazione(){
			cmbCausale.Visible=false;
			labelCausale.Visible=false;
			gboxDocumento.Visible=false;
		}

		public enum tipocont {cont_none,cont_ordine,cont_missione,cont_iva,cont_cedolino,cont_occasionale,
			cont_professionale,cont_dipendente};
		string NomeContabilizzazione(tipocont TIPO){
			switch (TIPO){
				case tipocont.cont_ordine: return "Contratto Passivo";
				case tipocont.cont_missione: return "Missione";
				case tipocont.cont_iva: return "Documento Iva";
				case tipocont.cont_cedolino: return "Cedolino Parasubordinati";
				case tipocont.cont_occasionale: return "Prestazione Occasionale";
				case tipocont.cont_professionale: return "Prestazione Professionale";
				case tipocont.cont_dipendente: return "Compenso a Dipendente";
				case tipocont.cont_none: return "";
			}
			return null;
		}
		tipocont CodiceContabilizzazione(string nomecont){
			switch(nomecont){
				case "Contratto Passivo":return tipocont.cont_ordine;
				case "Missione": return tipocont.cont_missione;
				case "Documento Iva": return tipocont.cont_iva;
				case "Cedolino Parasubordinati":return tipocont.cont_cedolino;
				case "Prestazione Occasionale": return tipocont.cont_occasionale;
				case "Prestazione Professionale": return tipocont.cont_professionale;
				case "Compenso a Dipendente": return tipocont.cont_dipendente;
				case "":return tipocont.cont_none;
			}
			return tipocont.cont_none;
		}

		/// <summary>
		/// Stabilisce se � possibile con la fase corrente contabilizzare un
		///  certo tipo di documento
		/// </summary>
		/// <returns></returns>
		bool ContabilizzazioneAttivabile(tipocont codecont){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			switch(codecont){
				case tipocont.cont_missione:
					if (faseMissioneInclusa()) return true;
					return false;
				case tipocont.cont_ordine:
					if (faseOrdineInclusa()) return true;
					return false;
				case tipocont.cont_iva:
					if (faseIvaInclusa())return true;
					return false;
				case tipocont.cont_cedolino:
					if (faseCedolinoInclusa())return true;
					return false;
				case tipocont.cont_occasionale:
					if (faseOccasionaleInclusa())return true;
					return false;
				case tipocont.cont_professionale:
					if (faseProfessionaleInclusa())return true;
					return false;
				case tipocont.cont_dipendente:
					if (faseDipendenteInclusa())return true;
					return false;

				default:
					return false;
			}
		}

		bool faseMissioneInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}
		bool faseCedolinoInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}
		bool faseOrdineInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}
		bool faseIvaInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==faseivaspesa)return true;
			return false;
		}
		bool faseOccasionaleInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}
		bool faseProfessionaleInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}
		bool faseDipendenteInclusa(){
			int currphase= CfgFn.GetNoNullInt32(cmbFaseSpesa.SelectedValue);
			if (currphase==fasespesacont)return true;
			return false;
		}


		/// <summary>
		/// Riempie il Combo del tipo di Contabilizzazione con
		///  le scelte possibili in base alla fase corrente
		/// </summary>
		void CalcolaContabilizzazioniPossibili(){
			cmbTipoContabilizzazione.Items.Clear();
			cmbTipoContabilizzazione.Items.Add("");
			foreach (tipocont codecont in new tipocont[] {
															 tipocont.cont_ordine, 
															 tipocont.cont_missione, 
															 tipocont.cont_iva,
															 tipocont.cont_cedolino,
															tipocont.cont_occasionale,
															tipocont.cont_professionale,
															tipocont.cont_dipendente}){
				if (ContabilizzazioneAttivabile(codecont))
					cmbTipoContabilizzazione.Items.Add(
						NomeContabilizzazione(codecont));
			}																								   
		}
		
		/// <summary>
		/// Funzione chiamata quando cambia il combo delle contabilizzazioni
		/// Disattiva tutte le contabilizzazioni e poi attiva quella indicata.
		/// Scollega qualsiasi documento collegato
		/// </summary>
		/// <param name="codecont"></param>
		void AttivaContabilizzazione(tipocont codecont){
			foreach(tipocont disattivacont in new tipocont[]{
																tipocont.cont_missione, 
																tipocont.cont_ordine, 
																tipocont.cont_iva,
																tipocont.cont_cedolino,
																tipocont.cont_occasionale,
																tipocont.cont_professionale,
																tipocont.cont_dipendente
																}){
				DisattivaContabilizzazione(disattivacont);
			}
			txtEsercDoc.Text="";
			txtNumDoc.Text="";
			VisualizzaControlliContabilizzazione(codecont);
			ClearComboCausale();
		}

		void DisattivaContabilizzazione(tipocont codecont){
			switch(codecont){
				case tipocont.cont_missione:
					if (faseMissioneInclusa()) ScollegaMissione();
					return;
				case tipocont.cont_ordine:
					if (faseOrdineInclusa()) ScollegaOrdine();
					return;
				case tipocont.cont_iva:
					if (faseIvaInclusa()) ScollegaIva();
					return;
				case tipocont.cont_cedolino:
					if (faseCedolinoInclusa()) ScollegaCedolino();
					return;
				case tipocont.cont_occasionale:
					if (faseOccasionaleInclusa()) ScollegaOccasionale();
					return;
				case tipocont.cont_professionale:
					if (faseProfessionaleInclusa()) ScollegaProfessionale();
					return;
				case tipocont.cont_dipendente:
					if (faseDipendenteInclusa()) ScollegaDipendente();
					return;
			}

		}



	
		#endregion

		#region Gestione Selezione Documento Iva 

		string FilterIva;

		//		void AbilitaDisabilitaBtnOrdine(){
		//			bool SelezioneOrdineAttiva = ((Meta.IsEmpty)||(Meta.InsertMode));
		//			btnOrdine.Enabled=  SelezioneOrdineAttiva;
		//			txtNumOrdine.ReadOnly= !SelezioneOrdineAttiva;
		//			txtEsercOrdine.ReadOnly= !SelezioneOrdineAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumOrdine.Text.Trim()!="");
		//			txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//		}

		private void txtEsercIva_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
			//CalcolaStartFilter(null);
		}

		string GetFilterIva(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			FilterIva="(yinv<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int esercdocumento= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (esercdocumento <= esercizio) 
						FilterIva="(yinv='"+esercdocumento.ToString()+"')";
					else 
						FilterIva = //GetData.MergeFilters(FilterIva,
							"(yinv='"+esercdocumento.ToString()+"')";
					//);
				}
				catch {
				}
			} 

			if (FiltraNum){
				int numdocumento= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterIva = GetData.MergeFilters(FilterIva,
						"(ninv='"+numdocumento.ToString()+"')");
				} 
			}
			string filtertipodoc;
			if (cmbTipoDocumento.SelectedIndex<=0){
				filtertipodoc= "(flagbuysell='A')AND(flagvariation='N')";
			}
			else {
				filtertipodoc = "(idinvkind="+
					QueryCreator.quotedstrvalue(cmbTipoDocumento.SelectedValue,true)+")";
			}
			FilterIva = GetData.MergeFilters(FilterIva, filtertipodoc);

			//eventualmente appende al filtro sull'ordine un filtro sul creditore.
			//Questo accade se la fase creditore � precedente a quella della missione e la
			// fase creditore � precedente alla prima fase selezionata ed il 
			// movimento relativo alla fase precedente � stato selezionato
			//			int fasecreditore = ManageCreditore.faseattivazione;
			//			bool fasecredcond = (fasecreditore<currphase) && (fasecreditore<faseiva);
			//			if (Meta.IsEmpty) return FilterIva;
			//			DataRow Curr = DS.spesa.Rows[0];
			//			bool faseprecselected = (Curr["livsupidspesa"]!=DBNull.Value);
			//			if (fasecredcond && faseprecselected){
			//				FilterIva = GetData.MergeFilters(FilterIva,
			//					"(codicecreddeb="+QueryCreator.quotedstrvalue(
			//					Curr["codicecreddeb"],true)+")");
			//			}
			//
			return FilterIva;
		}


		private void btnIva_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);
			string MyIvaFilter;
			string MyFilterIvaOperativo;
			if (((Control)sender).Name == "txtNumDoc")
				MyIvaFilter = GetFilterIva(true);
			else
				MyIvaFilter = GetFilterIva(false);

			MyFilterIvaOperativo= MyIvaFilter;

			bool condfasecred = chkCredDeb.Checked;
			if (condfasecred){
				MyFilterIvaOperativo= GetData.MergeFilters(MyFilterIvaOperativo,
					"(registry="+
					QueryCreator.quotedstrvalue(txtCredDeb.Text,true)+")");
			}

			MetaData MDocumentoIva;
			DataRow MyDRIva;

			MDocumentoIva = MetaData.GetMetaData(this,"invoiceavailable");
			MDocumentoIva.FilterLocked=true;
			MDocumentoIva.DS = DS.Clone();
			string filter2 = "(residual >= " + QueryCreator.quotedstrvalue(currimp,true)
				+ ") and ((active is null) or (active = 'S'))";
            if(!chkFilterResidual.Checked) filter2 = "((active is null) or (active = 'S'))";

			MyDRIva = MDocumentoIva.SelectOne("default",
				GetData.MergeFilters(MyFilterIvaOperativo, filter2
				//"(residual>="+QueryCreator.quotedstrvalue(currimp,true)+")"
				),

					null,null);
			
			if(MyDRIva == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectord= 
				"(idinvkind="+QueryCreator.quotedstrvalue(MyDRIva["idinvkind"],true)+")AND"+
				"(yinv='"+MyDRIva["yinv"].ToString()+"')AND"+
				"(ninv='"+MyDRIva["ninv"].ToString()+"')";

			string columnlist = QueryCreator.ColumnNameList(DS.invoice)+
				",registry";
			DataTable Temp = Meta.Conn.RUN_SELECT("invoiceview",columnlist,null,selectord,null,null,true);
			
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			ResetIva();
			CollegaIva(MyDR);
            //CollegaTuttiDettagliIva();
            RintracciaIva();
            AbilitaDisabilitaControlliIva(true);


		}

		private void txtNumIva_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;
			//CalcolaStartFilter(null);


			if (txtNumDoc.Text.Trim()==""){
				ScollegaIva();				
				ClearControlliIva(true);
				return;
			}
			btnIva_Click(sender,e);
		}

		void ClearControlliIva(bool skipTipoDoc){
			//txtCredDeb.Text = "";		
			if (!skipTipoDoc) cmbTipoDocumento.SelectedIndex=0;
		}

		void AbilitaDisabilitaControlliIva(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
            gboxDettInvoice.Visible = abilita;
            CurrCausaleIva = GetCausaleIva();
            if(CurrCausaleIva == "DOCUM" || CurrCausaleIva == "IMPON") {
                dgrDettagliFattura.Tag = "invoicedetail_taxable.listaimpon";
                dgrDettagliFattura.TableStyles.Clear();
                HelpForm.SetDataGrid(dgrDettagliFattura, DS.invoicedetail_taxable);
                if(Meta.EditMode) DS.invoicedetail_iva.Clear(); //Importante per evitare problemi in fase di delete
            }
            if(CurrCausaleIva == "IMPOS") {
                dgrDettagliFattura.TableStyles.Clear();
                dgrDettagliFattura.Tag = "invoicedetail_iva.listaimpos";
                HelpForm.SetDataGrid(dgrDettagliFattura, DS.invoicedetail_iva);
                if(Meta.EditMode) DS.invoicedetail_taxable.Clear(); //Importante per evitare problemi in fase di delete
            }

		}


		/// <summary>
		/// Collega la riga al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		void CollegaIva(DataRow Iva2){

			Hashtable ValoriDocumentoIva = new Hashtable();
			foreach (DataColumn C in DS.invoice.Columns) 
				ValoriDocumentoIva[C.ColumnName]= Iva2[C.ColumnName];

			ScollegaIva();

			if (!faseIvaInclusa()) return;

			DataRow NewIvaR = DS.invoice.NewRow();

			foreach (DataColumn C in DS.invoice.Columns){
				NewIvaR[C.ColumnName]= ValoriDocumentoIva[C.ColumnName];
			}

			DS.invoice.Rows.Add(NewIvaR);
			NewIvaR.AcceptChanges();

			DataRow CurrRow= DS.expense.Rows[0];
			MetaData MovIva = MetaData.GetMetaData(this,"expenseinvoice");
			MovIva.SetDefaults(DS.expenseinvoice);
			DS.expenseinvoice.Columns["idinvkind"].DefaultValue=ValoriDocumentoIva["idinvkind"];
			DS.expenseinvoice.Columns["ninv"].DefaultValue= ValoriDocumentoIva["ninv"];
			DS.expenseinvoice.Columns["yinv"].DefaultValue= ValoriDocumentoIva["yinv"];
			txtNumDoc.Text=ValoriDocumentoIva["ninv"].ToString();
			txtEsercDoc.Text=ValoriDocumentoIva["yinv"].ToString();
			TipoDocChangePilotato=true;
			HelpForm.SetComboBoxValue(cmbTipoDocumento,ValoriDocumentoIva["idinvkind"].ToString());
			TipoDocChangePilotato=false;

			DataRow RMovIva = MovIva.Get_New_Row(CurrRow, DS.expenseinvoice);
			DS.expenseinvoice.Columns["idinvkind"].DefaultValue = DBNull.Value;
			DS.expenseinvoice.Columns["ninv"].DefaultValue= DBNull.Value;
			DS.expenseinvoice.Columns["yinv"].DefaultValue= DBNull.Value;

			NuovoDocumento= "Doc."+ValoriDocumentoIva["doc"];
			NuovoDataDocumento = (DateTime)ValoriDocumentoIva["docdate"];
			NuovoDescrizione = ValoriDocumentoIva["description"];

			RintracciaIva();
			SetComboCausaleIva(NewIvaR);
			AbilitaDisabilitaControlliIva(true);
			cmbCausale.Enabled=true;
		}

		void ScollegaIva(){
			if (DS.expenseinvoice.Rows.Count==0) return;
			DS.expenseinvoice.Clear();
			DS.invoice.Clear();
            DS.invoicedetail_iva.Clear();
            DS.invoicedetail_taxable.Clear();
			ClearComboCausale();
			ClearControlliIva(false);
			NuovoDocumento=null;
			NuovoDataDocumento=null;
			NuovoDescrizione=null;
		}

        void CollegaTuttiDettagliFattura() {
            CurrCausaleIva = GetCausaleIva();
            string filter = CalculateFilterForInvoiceDetailLinking(true);
            DS.invoicedetail_iva.Clear();
            DS.invoicedetail_taxable.Clear();
            string idexp = DS.expense.Rows[0]["idexp"].ToString();
            if(CurrCausaleIva == "DOCUM") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.invoicedetail_taxable, null, filter, null, true);
                foreach(DataRow R in DS.invoicedetail_taxable.Rows) {
                    R["idexp_taxable"] = idexp;
                    R["idexp_iva"] = idexp;
                }
                GetData.CalculateTable(DS.invoicedetail_taxable);
                Meta.MarkTableAsNotEntityChild(DS.invoicedetail_taxable);
            }
            if(CurrCausaleIva == "IMPON") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.invoicedetail_taxable, null, filter, null, true);
                foreach(DataRow R in DS.invoicedetail_taxable.Rows) {
                    R["idexp_taxable"] = idexp;
                }
                GetData.CalculateTable(DS.invoicedetail_taxable);
                Meta.MarkTableAsNotEntityChild(DS.invoicedetail_taxable);
            }
            if(CurrCausaleIva == "IMPOS") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.invoicedetail_iva, null, filter, null, true);
                foreach(DataRow R in DS.invoicedetail_iva.Rows) {
                    R["idexp_iva"] = idexp;
                }
                GetData.CalculateTable(DS.invoicedetail_iva);
                Meta.MarkTableAsNotEntityChild(DS.invoicedetail_iva);
            }

            //CalcolaImportoInBaseADettagliFattura();
        }

		#endregion

		#region Gestione ComboBox Causale Iva


		decimal totimponibile_dociva;
		decimal totiva_dociva;
		decimal assigned_imponibile_dociva;
		decimal assigned_iva_dociva;
		decimal assigned_gen_dociva;



		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleIva(DataRow Ordine){
			if (currphase()!=faseivaspesa) return;
			DataAccess Conn= Meta.Conn;
			string filteriva = 
				"(idinvkind="+QueryCreator.quotedstrvalue(Ordine["idinvkind"],true)+")AND"+
				"(yinv='"+Ordine["yinv"].ToString()+"')AND"+
				"(ninv='"+Ordine["ninv"].ToString()+"')";

			DataTable T= Conn.RUN_SELECT("invoiceresidual","*",null,filteriva,null,true);
			if ((T!=null)&&(T.Rows.Count>0)){
				DataRow R=T.Rows[0];
				totimponibile_dociva=CfgFn.GetNoNullDecimal( R["taxabletotal"]);
				totiva_dociva=CfgFn.GetNoNullDecimal( R["ivatotal"]);
				assigned_imponibile_dociva= CfgFn.GetNoNullDecimal( R["linkedimpon"]);
				assigned_iva_dociva= CfgFn.GetNoNullDecimal( R["linkedimpos"]);
				assigned_gen_dociva=CfgFn.GetNoNullDecimal( R["linkeddocum"]);

			}
			else {
				totimponibile_dociva= 0;
				totiva_dociva =  0;
				assigned_imponibile_dociva= 0;
				assigned_iva_dociva= 0;
				assigned_gen_dociva= 0;
			}

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;


			bool found=false;
			if ((Meta.EditMode) || 
				((assigned_imponibile_dociva+assigned_iva_dociva)==0) && 
				(assigned_gen_dociva< (totimponibile_dociva+totiva_dociva)&&
				(totimponibile_dociva+totiva_dociva-assigned_gen_dociva>=currimp)
				)
				){
				EnableTipoMovimento("DOCUM","Contabilizzazione importo totale documento");
				found=true;
			}

			if ((Meta.EditMode) || 
				( (assigned_gen_dociva==0) &&(assigned_imponibile_dociva < totimponibile_dociva)&&
				(  (totimponibile_dociva-assigned_imponibile_dociva) >= currimp)
				)
				){
				EnableTipoMovimento("IMPON","Contabilizzazione imponibile documento");
				found=true;
			}

			if ( (Meta.EditMode) || 
				( (assigned_gen_dociva==0) &&(assigned_iva_dociva< totiva_dociva)&&
				( (totiva_dociva-assigned_iva_dociva) >= currimp)
				)
				){
				EnableTipoMovimento("IMPOS","Contabilizzazione iva documento");
				found=true;
			}
			if (!found){
				MessageBox.Show("Il movimento selezionato ha un importo superiore al residuo del documento."+
						" La contabilizzazione � impossibile.");
			}
			DS.expenseinvoice.Rows[0]["movkind"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=true;
			ReCalcImporto_Iva();
			
		}


		void ReCalcImporto_Iva(){
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=0;
			if (tipomovimento=="IMPOS"){
				importo= totiva_dociva-assigned_iva_dociva;
			}
			if (tipomovimento=="IMPON"){
				importo= totimponibile_dociva-assigned_imponibile_dociva;
			}
			if (tipomovimento=="DOCUM"){
				importo= totimponibile_dociva+totiva_dociva-assigned_gen_dociva;
			}

			//if ((currphase>1)&& (importo> DisponibileDaFasePrecedente)) importo=DisponibileDaFasePrecedente;
			if (importo<0) importo=0; //dovrebbe essere superfluo
	
			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale del documento poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}


		private void cmbCausaleIva_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleIva();
			ReCalcImporto_Iva();
		}

		string GetCausaleIva(){
			CurrCausaleIva="";
			if (DS.expenseinvoice.Rows.Count==0) return"";
			if (cmbCausale.SelectedValue!=null)
				DS.expenseinvoice.Rows[0]["movkind"]= cmbCausale.SelectedValue;
			else
				DS.expenseinvoice.Rows[0]["movkind"]= DBNull.Value;
			CurrCausaleIva= DS.expenseinvoice.Rows[0]["movkind"].ToString();
			return CurrCausaleIva;
			//ReCalcImporto();
		}


		bool TipoDocChangePilotato=false;
		private void cmbTipoDocumento_SelectedIndexChanged(object sender, System.EventArgs e) {
			if (!Meta.DrawStateIsDone) return;
			if (TipoDocChangePilotato) return;
			TipoDocChangePilotato=true;
			ScollegaIva();
			ClearControlliIva(true);
			txtEsercDoc.Text="";
			txtNumDoc.Text="";
			ClearComboCausale();
			cmbCausale.Enabled=false;
			TipoDocChangePilotato=false;
		}

		#endregion

		#region Gestione Selezione Ordine 

		string FilterOrdine;

		//		void AbilitaDisabilitaBtnOrdine(){
		//			bool SelezioneOrdineAttiva = ((Meta.IsEmpty)||(Meta.InsertMode));
		//			btnOrdine.Enabled=  SelezioneOrdineAttiva;
		//			txtNumOrdine.ReadOnly= !SelezioneOrdineAttiva;
		//			txtEsercOrdine.ReadOnly= !SelezioneOrdineAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumOrdine.Text.Trim()!="");
		//			txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//		}

		private void txtEsercOrdine_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
			//CalcolaStartFilter(null);
		}

		string GetFilterOrdine(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			FilterOrdine="(yman<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int esercordine= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (esercordine <= esercizio) 
						FilterOrdine="(yman='"+esercordine.ToString()+"')";
					else 
						FilterOrdine = //GetData.MergeFilters(FilterOrdine,
							"(yman='"+esercordine.ToString()+"')";
					//);
				}
				catch {
				}
			} 
			string filtertipoord=null;
			if (cmbTipoDocumento.SelectedIndex<=0){
				filtertipoord= null;
			}
			else {
				filtertipoord = "(idmankind="+
					QueryCreator.quotedstrvalue(cmbTipoDocumento.SelectedValue,true)+")";
			}
			FilterOrdine = GetData.MergeFilters(FilterOrdine, filtertipoord);
			if (FiltraNum){
				int numordine= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterOrdine = GetData.MergeFilters(FilterOrdine,
						"(nman='"+numordine.ToString()+"')");
				} 
			}
			//FilterOrdine+="AND(residuo>'0')";

			//eventualmente appende al filtro sull'ordine un filtro sul creditore.
			//Questo accade se la fase creditore � precedente a quella della missione e la
			// fase creditore � precedente alla prima fase selezionata ed il 
			// movimento relativo alla fase precedente � stato selezionato
			//			int fasecreditore = ManageCreditore.faseattivazione;
			//			bool fasecredcond = (fasecreditore<currphase) && (fasecreditore<faseordine);
			//			if (Meta.IsEmpty) return FilterOrdine;
			//			DataRow Curr = DS.spesa.Rows[0];
			//			bool faseprecselected = (Curr["livsupidspesa"]!=DBNull.Value);
			//			if (fasecredcond && faseprecselected){
			//				FilterOrdine = GetData.MergeFilters(FilterOrdine,
			//					"(codicecreddeb="+QueryCreator.quotedstrvalue(
			//					Curr["codicecreddeb"],true)+")");
			//			}

			return FilterOrdine;
		}


		private void btnOrdine_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);
			string MyOrdineFilter;
			string MyFilterOrdineGenericoOperativo;
			if (((Control)sender).Name == "txtNumDoc")
				MyOrdineFilter = GetFilterOrdine(true);
			else
				MyOrdineFilter = GetFilterOrdine(false);

			MyFilterOrdineGenericoOperativo= MyOrdineFilter;

			bool condfasecred = chkCredDeb.Checked;
			DataRow Curr = DS.expense.Rows[0];
			if (condfasecred ){
                MyOrdineFilter = GetData.MergeFilters(MyOrdineFilter,
                    "(idreg is null or idreg=" +
                    QueryCreator.quotedstrvalue(Curr["idreg"], true) + ")");

				MyFilterOrdineGenericoOperativo= GetData.MergeFilters(MyFilterOrdineGenericoOperativo,
					"(registry is null or registry="+
					QueryCreator.quotedstrvalue(txtCredDeb.Text,true)+")");
			}

            if ((SubEntity_comboUPB.SelectedIndex > 0 )) {
                string idupb = SubEntity_comboUPB.SelectedValue.ToString();

                MyOrdineFilter = GetData.MergeFilters(MyOrdineFilter,
                    "(idupb is null or idupb=" +
                    QueryCreator.quotedstrvalue(idupb, true) + ")");

                MyFilterOrdineGenericoOperativo = GetData.MergeFilters(MyFilterOrdineGenericoOperativo,
                    "(idupb is null or idupb=" + QueryCreator.quotedstrvalue(idupb, true) + ")");
            }

			MetaData MOrdine;
			DataRow MyDROrdine;

            MOrdine = MetaData.GetMetaData(this, "mandateresidual");
			MOrdine.FilterLocked=true;
			MOrdine.DS = DS.Clone();

			string filter2 = "(residual >= " + QueryCreator.quotedstrvalue(currimp,true)
				+ ") and ((active is null) or (active = 'S'))";
            if(!chkFilterResidual.Checked) filter2 = "((active is null) or (active = 'S'))";

			MyDROrdine = MOrdine.SelectOne("default",
				GetData.MergeFilters( MyFilterOrdineGenericoOperativo, filter2
				//"(residual>="+QueryCreator.quotedstrvalue(currimp,true)+")"
				),
					null,null);
			
			if(MyDROrdine == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectord= "(yman='"+MyDROrdine["yman"].ToString()+"')AND"+
				"(nman='"+MyDROrdine["nman"].ToString()+"')AND"+
				"(idmankind='"+MyDROrdine["idmankind"].ToString()+"')";
			
			string columnlist = QueryCreator.ColumnNameList(DS.mandate)+
				",registry";
			DataTable Temp = Meta.Conn.RUN_SELECT("mandateview",columnlist,null,selectord,null,null,true);
			
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetOrdine();
			CollegaOrdine(MyDR);
            CollegaTuttiDettagliOrdine();
            RintracciaOrdine();
            AbilitaDisabilitaControlliOrdine(true);

		}

		private void txtNumOrdine_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;
			//CalcolaStartFilter(null);


			if (txtNumDoc.Text.Trim()==""){
				ScollegaOrdine();				
				ClearControlliOrdine(true);
				return;
			}


			btnOrdine_Click(sender,e);

		}

		void ClearControlliOrdine(bool skipTipoDoc){
			//txtCredDeb.Text = "";		
		}

		void AbilitaDisabilitaControlliOrdine(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
            gboxDettmandate.Visible = abilita;
            CurrCausaleOrdine = GetCausaleOrdine();
            if(CurrCausaleOrdine == "ORDIN" || CurrCausaleOrdine == "IMPON") {
                dgrDettagliOrdine.Tag = "mandatedetail_taxable.listaimpon";
                //dgrDettagliOrdine.TableStyles.Clear();
                HelpForm.SetDataGrid(dgrDettagliOrdine, DS.mandatedetail_taxable);
                DS.mandatedetail_iva.Clear(); //Importante per evitare problemi in fase di delete
            }
            if(CurrCausaleOrdine == "IMPOS") {
                dgrDettagliOrdine.Tag = "mandatedetail_iva.listaimpos";
                //dgrDettagliOrdine.TableStyles.Clear();
                HelpForm.SetDataGrid(dgrDettagliOrdine, DS.mandatedetail_iva);
                DS.mandatedetail_taxable.Clear(); //Importante per evitare problemi in fase di delete
            }

		}

        void CollegaTuttiDettagliOrdine() {
            CurrCausaleOrdine = GetCausaleOrdine();
            string filter = CalculateFilterForMandateDetailLinking(true);
            DS.mandatedetail_iva.Clear();
            DS.mandatedetail_taxable.Clear();
            string idexp = DS.expense.Rows[0]["idexp"].ToString();
            if(CurrCausaleOrdine == "ORDIN") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.mandatedetail_taxable, null, filter, null, true);
                foreach(DataRow R in DS.mandatedetail_taxable.Rows) {
                    R["idexp_taxable"] = idexp;
                    R["idexp_iva"] = idexp;
                }
                GetData.CalculateTable(DS.mandatedetail_taxable);
                Meta.MarkTableAsNotEntityChild(DS.mandatedetail_taxable);
            }
            if(CurrCausaleOrdine == "IMPON") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.mandatedetail_taxable, null, filter, null, true);
                foreach(DataRow R in DS.mandatedetail_taxable.Rows) {
                    R["idexp_taxable"] = idexp;
                }
                GetData.CalculateTable(DS.mandatedetail_taxable);
                Meta.MarkTableAsNotEntityChild(DS.mandatedetail_taxable);
            }
            if(CurrCausaleOrdine == "IMPOS") {
                Meta.Conn.RUN_SELECT_INTO_TABLE(DS.mandatedetail_iva, null, filter, null, true);
                foreach(DataRow R in DS.mandatedetail_iva.Rows) {
                    R["idexp_iva"] = idexp;
                }
                GetData.CalculateTable(DS.mandatedetail_iva);
                Meta.MarkTableAsNotEntityChild(DS.mandatedetail_iva);
            }

            CalcolaImportoInBaseADettagliOrdine();
        }

		/// <summary>
		/// Collega la riga al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		void CollegaOrdine(DataRow Ordine2){
			//Meta.GetFormData(true);
			//AzzeraPadre();
			Hashtable ValoriOrdine = new Hashtable();
			foreach (DataColumn C in DS.mandate.Columns) 
				ValoriOrdine[C.ColumnName]= Ordine2[C.ColumnName];

			ScollegaOrdine();

			if (!faseOrdineInclusa()) return;

			DataRow NewOrdR = DS.mandate.NewRow();

			foreach (DataColumn C in DS.mandate.Columns){
				NewOrdR[C.ColumnName]= ValoriOrdine[C.ColumnName];
			}

			DS.mandate.Rows.Add(NewOrdR);
			NewOrdR.AcceptChanges();

			DataRow CurrRow= DS.expense.Rows[0];
			MetaData MovOrd = MetaData.GetMetaData(this,"expensemandate");
			MovOrd.SetDefaults(DS.expensemandate);
			DS.expensemandate.Columns["idmankind"].DefaultValue=ValoriOrdine["idmankind"];
			DS.expensemandate.Columns["nman"].DefaultValue= ValoriOrdine["nman"];
			DS.expensemandate.Columns["yman"].DefaultValue= ValoriOrdine["yman"];
			TipoDocChangePilotato=true;
			HelpForm.SetComboBoxValue(cmbTipoDocumento,ValoriOrdine["idmankind"].ToString());
			TipoDocChangePilotato=false;
			txtNumDoc.Text=ValoriOrdine["nman"].ToString();
			txtEsercDoc.Text=ValoriOrdine["yman"].ToString();

			DataRow RMovOrd = MovOrd.Get_New_Row(CurrRow, DS.expensemandate);
			DS.expensemandate.Columns["idmankind"].DefaultValue = DBNull.Value;
			DS.expensemandate.Columns["nman"].DefaultValue= DBNull.Value;
			DS.expensemandate.Columns["yman"].DefaultValue= DBNull.Value;

			//"Ord."+ValoriOrdine["documento"];

			NuovoDocumento="Ord."+
				ValoriOrdine["idmankind"].ToString()+"/"+
				ValoriOrdine["yman"].ToString().Substring(2,2)+"/"+
				ValoriOrdine["nman"].ToString().PadLeft(6,'0');
			NuovoDataDocumento = ValoriOrdine["docdate"];
			NuovoDescrizione = ValoriOrdine["description"];


			//CurrRow["codiceresponsabile"] = ValoriOrdine["codiceresponsabile"];
			//HelpForm.SetComboBoxValue(cmbResponsabile, 	ValoriOrdine["codiceresponsabile"].ToString());


			//Meta.myHelpForm.FillControls(tabMovFin.Controls);
			RintracciaOrdine();
			SetComboCausaleOrdine(NewOrdR);
			AbilitaDisabilitaControlliOrdine(true);
			cmbCausale.Enabled=true;
		}

		void ScollegaOrdine(){
			if (DS.expensemandate.Rows.Count==0) return;
			DS.expensemandate.Clear();
			DS.mandate.Clear();
            DS.mandatedetail_taxable.Clear();
            DS.mandatedetail_iva.Clear();
            ClearComboCausale();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			//CurrRow["codiceresponsabile"]=DBNull.Value;
			ClearControlliOrdine(false);
		}

		private void cmbTipoOrdine_SelectedIndexChanged(object sender, System.EventArgs e) {
			if (!Meta.DrawStateIsDone) return;
			if (TipoDocChangePilotato) return;
			TipoDocChangePilotato=true;
			ClearControlliOrdine(true);
			txtEsercDoc.Text="";
			txtNumDoc.Text="";
			TipoDocChangePilotato=false;
		}
		#endregion

		#region Gestione ComboBox Causale Ordine


		decimal totimponibile;
		decimal totiva;
		decimal assigned_imponibile;
		decimal assigned_iva;
		decimal assigned_gen;



		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleOrdine(DataRow Ordine){
			if (currphase()!=fasespesacont) return;
			DataAccess Conn= Meta.Conn;
			string filterordine = "(yman='"+Ordine["yman"].ToString()+"')AND"+
				"(nman='"+Ordine["nman"].ToString()+"')AND"+
				"(idmankind='"+Ordine["idmankind"].ToString()+"')";
			DataTable T= Conn.RUN_SELECT("mandateresidual","*",null,filterordine,null,true);
			if ((T!=null)&&(T.Rows.Count>0)){
				DataRow R=T.Rows[0];
				totimponibile=CfgFn.GetNoNullDecimal( R["taxabletotal"]);
				totiva=CfgFn.GetNoNullDecimal( R["ivatotal"]);
				assigned_imponibile= CfgFn.GetNoNullDecimal( R["linkedimpon"]);
				assigned_iva= CfgFn.GetNoNullDecimal( R["linkedimpos"]);
				assigned_gen=CfgFn.GetNoNullDecimal( R["linkedordin"]);

			}
			else {
				totimponibile= 0;
				totiva =  0;
				assigned_imponibile= 0;
				assigned_iva= 0;
				assigned_gen= 0;
			}

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;

			if (
				((assigned_imponibile+assigned_iva)==0) && 
				(assigned_gen< (totimponibile+totiva)) &&
				(totimponibile+totiva-assigned_gen >= currimp)
				){
				EnableTipoMovimento("ORDIN","Contabilizzazione Totale Contratto Passivo");
			}

			if (
				( (assigned_gen==0) &&(assigned_imponibile < totimponibile)&&
					(totimponibile-assigned_imponibile >= currimp)	
				)
				){
				EnableTipoMovimento("IMPON","Contabilizzazione Imponibile Contratto Passivo");
			}

			if ( 
				( (assigned_gen==0) &&(assigned_iva< totiva)&&
				  (totiva-assigned_iva >= currimp)
				)
				){
				EnableTipoMovimento("IMPOS","Contabilizzazione Iva Contratto Passivo");
			}
			DS.expensemandate.Rows[0]["movkind"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=true;
			ReCalcImporto_Ordine();
			
		}


		void ReCalcImporto_Ordine(){
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=0;
			if (tipomovimento=="IMPOS"){
				importo= totiva-assigned_iva;
			}
			if (tipomovimento=="IMPON"){
				importo= totimponibile-assigned_imponibile;
			}
			if (tipomovimento=="ORDIN"){
				importo= totimponibile+totiva-assigned_gen;
			}

			if (importo<0) importo=0; //dovrebbe essere superfluo

			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale del contratto passivo poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}


		}
        
		private void cmbCausaleOrdine_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleOrdine();
            SvuotaDettagliOrdine();
			ReCalcImporto_Ordine();
            CollegaTuttiDettagliOrdine();
		}

		string GetCausaleOrdine(){
			CurrCausaleOrdine="";
			if (DS.expensemandate.Rows.Count==0) return"";
			if (cmbCausale.SelectedValue!=null)
				DS.expensemandate.Rows[0]["movkind"]= cmbCausale.SelectedValue;
			else
				DS.expensemandate.Rows[0]["movkind"]= DBNull.Value;
			CurrCausaleOrdine= DS.expensemandate.Rows[0]["movkind"].ToString();
			return CurrCausaleOrdine;
			//ReCalcImporto();
		}

		#endregion

		#region Gestione Selezione Missione 



		//		void AbilitaDisabilitaBtnMissione(){
		//			int fasemissione = ManageMissione.faseattivazione;
		//			bool SelezioneMissioneAttiva=false;
		//			if ((faseinizio<= fasemissione) && (fasemissione<= fasespesafine)) 
		//				SelezioneMissioneAttiva=true;
		//			btnDocumento.Enabled=  SelezioneMissioneAttiva;
		//			txtNumDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			txtEsercDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumDoc.Text.Trim()!="");
		//			//txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//			AbilitaDisabilitaCreditoreDebitore();
		//		}

		private void txtEsercMissione_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
		}

		string GetFilterMissione(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			string FilterMissione="(yitineration<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int esercmissione= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (esercmissione <= esercizio) 
						FilterMissione="(yitineration='"+esercmissione.ToString()+"')";
					else 
						FilterMissione = //GetData.MergeFilters(FilterMissione,
							"(yitineration='"+esercmissione.ToString()+"')";
					//);
				}
				catch {
				}
			} 
			if (FiltraNum){
				int nummissione= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterMissione = GetData.MergeFilters(FilterMissione,
						"(nitineration='"+nummissione.ToString()+"')");
				} 
			}
			return FilterMissione;
		}


		private void btnMissione_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);

			string MyMissioneFilter;
			if (((Control)sender).Name == "txtNumDoc")
				MyMissioneFilter = GetFilterMissione(true);
			else
				MyMissioneFilter = GetFilterMissione(false);


			DataRow Curr = DS.expense.Rows[0];
			bool condfasecred = chkCredDeb.Checked;
			
			if (condfasecred){
				MyMissioneFilter = GetData.MergeFilters(MyMissioneFilter,
					"(idreg="+
					QueryCreator.quotedstrvalue(Curr["idreg"],true)+")");
			}

			MetaData MMissione;
			DataRow MyDRMissione;

			MMissione = MetaData.GetMetaData(this,"itinerationresidual");
			MMissione.FilterLocked=true;
			MMissione.DS = DS.Clone();

			string filter2 = "(residual >= " + QueryCreator.quotedstrvalue(currimp,true)
				+ ") and ((active is null) or (active = 'S'))";
            if(!chkFilterResidual.Checked) filter2 = "((active is null) or (active = 'S'))";

			MyDRMissione = MMissione.SelectOne("default",
				GetData.MergeFilters( MyMissioneFilter,filter2),
				null,null);
			
			if(MyDRMissione == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectmis= "(yitineration='"+MyDRMissione["yitineration"].ToString()+"')AND"+
				"(nitineration='"+MyDRMissione["nitineration"].ToString()+"')";


			string columnlist = QueryCreator.ColumnNameList(DS.itineration)
				+",registry";
			DataTable Temp = Meta.Conn.RUN_SELECT("itinerationview",columnlist,null,selectmis,null,null,true);
			
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetMissione();
			CollegaMissione(MyDR);
	
		}

		private void txtNumMissione_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;

			if (txtNumDoc.Text.Trim()=="") {
				ScollegaMissione();				
				return;
			}
			btnMissione_Click(sender,e);
		}

		void AbilitaDisabilitaControlliMissione(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
		}

		void ClearControlliMissione(){
		}

		/// <summary>
		/// Collega la riga missione al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		bool CollegaMissione(DataRow Missione2){
			
			Hashtable ValoriMissione = new Hashtable();
			foreach (DataColumn C in DS.itineration.Columns) 
				ValoriMissione[C.ColumnName]= Missione2[C.ColumnName];

			//AzzeraPadre();
			ScollegaMissione();
			DataRow CurrRow= DS.expense.Rows[0];

			if (!faseOrdineInclusa())return false;

			DataRow NewMissR = DS.itineration.NewRow();
			foreach (DataColumn C in DS.itineration.Columns){
				NewMissR[C.ColumnName]= ValoriMissione[C.ColumnName];
			}
			DS.itineration.Rows.Add(NewMissR);
			NewMissR.AcceptChanges();
			Missione2= NewMissR;

			MetaData MovMis = MetaData.GetMetaData(this,"expenseitineration");
			MovMis.SetDefaults(DS.expenseitineration);
			DS.expenseitineration.Columns["nitineration"].DefaultValue= ValoriMissione["nitineration"];
			DS.expenseitineration.Columns["yitineration"].DefaultValue= ValoriMissione["yitineration"];
			DataRow RMovMis = MovMis.Get_New_Row(CurrRow, DS.expenseitineration);
			DS.expenseitineration.Columns["nitineration"].DefaultValue= DBNull.Value;
			DS.expenseitineration.Columns["yitineration"].DefaultValue= DBNull.Value;
			txtNumDoc.Text= ValoriMissione["nitineration"].ToString();
			txtEsercDoc.Text= ValoriMissione["yitineration"].ToString();

			NuovoDocumento= "Mis."+ValoriMissione["yitineration"].ToString().Substring(2,2)+"/"+
				ValoriMissione["nitineration"].ToString().PadLeft(6,'0');
			NuovoDataDocumento = (DateTime)ValoriMissione["adate"];
			NuovoDescrizione = ValoriMissione["description"];


			RintracciaMissione();
			SetComboCausaleMissione(Missione2);
			AbilitaDisabilitaControlliMissione(false);
			cmbCausale.Enabled=true;
			return true;
		}

		
		void ScollegaMissione(){
			if (DS.expenseitineration.Rows.Count==0) {
				AbilitaDisabilitaControlliMissione(true);
				return;
			}
			DS.expenseitineration.Clear();
			DS.itineration.Clear();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			
			ClearComboCausale();
			AbilitaDisabilitaControlliMissione(true);
		}


	
		#endregion

		#region Gestione ComboBox Causale Missione
		decimal totlordo;
		decimal totanticipo;
		decimal contabilizzato_ANPAG;
		decimal contabilizzato_ANGIR;
		decimal contabilizzato_SALDO;
		decimal contabilizzato_VARIAZIONI;





		string lastMissEvalued=null;
		void CalcolaContabilizzatiMissione(DataRow Missione){
			string filtermiss = "(yitineration='"+Missione["yitineration"].ToString()+"')AND"+
				"(nitineration='"+Missione["nitineration"].ToString()+"')";
			decimal totlordo= CfgFn.GetNoNullDecimal(Missione["totalgross"]);

			if (filtermiss==lastMissEvalued) return;
			lastMissEvalued= filtermiss;

			DataTable Residuo = Conn.RUN_SELECT("itinerationresidual","*",null,filtermiss,null,true);

			DataRow CurrResid = Residuo.Rows[0];
			contabilizzato_ANGIR= CfgFn.GetNoNullDecimal(CurrResid["linkedangir"]);
			contabilizzato_ANPAG= CfgFn.GetNoNullDecimal(CurrResid["linkedanpag"]);
			contabilizzato_SALDO= CfgFn.GetNoNullDecimal(CurrResid["linkedsaldo"]);
			decimal residuo = CfgFn.GetNoNullDecimal(CurrResid["residual"]);
			contabilizzato_VARIAZIONI= -(totlordo-residuo-contabilizzato_ANPAG-contabilizzato_SALDO);

		}


		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleMissione(DataRow Missione){
			if (!faseMissioneInclusa()){
				cmbCausale.Enabled=false;
				return;
			}
			totlordo= CfgFn.GetNoNullDecimal(Missione["totalgross"]);
			totanticipo =  CfgFn.GetNoNullDecimal(Missione["totadvance"]);
			string completed = Missione["completed"].ToString().ToUpper();

			CalcolaContabilizzatiMissione(Missione);

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;

			if ( ((Meta.EditMode) || 
				((contabilizzato_SALDO+contabilizzato_ANPAG-contabilizzato_VARIAZIONI)< totlordo)&&
				 (totlordo-contabilizzato_SALDO-contabilizzato_ANPAG+contabilizzato_VARIAZIONI >= currimp))
				&& (completed == "S")
				){
				EnableTipoMovimento("SALDO","Pagamento o saldo della missione");
			}

			if ((Meta.EditMode) || 
				((contabilizzato_SALDO==0) && (contabilizzato_ANPAG==0) &&
				(contabilizzato_ANGIR< totanticipo)&&
				(totanticipo-contabilizzato_ANGIR >= currimp)
				)
				){
				EnableTipoMovimento("ANGIR","Anticipo della missione su partita di giro");
			}

			if ((Meta.EditMode) || 
				((contabilizzato_SALDO==0) && (contabilizzato_ANGIR==0) &&
				(contabilizzato_ANPAG< totanticipo)&&
				(totanticipo-contabilizzato_ANPAG >= currimp)
				)
				){
				EnableTipoMovimento("ANPAG","Anticipo della missione sul capitolo di spesa");
			}
			DS.expenseitineration.Rows[0]["movkind"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=Meta.InsertMode;
			ReCalcImporto_Missione();
			
		}

	


		void ReCalcImporto_Missione(){
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=0;
			if (tipomovimento=="SALDO"){
				importo= totlordo-(contabilizzato_SALDO+contabilizzato_ANPAG)+contabilizzato_VARIAZIONI;
			}
			if (tipomovimento=="ANGIR"){
				importo= totanticipo-contabilizzato_ANGIR;
			}
			if (tipomovimento=="ANPAG"){
				importo= totanticipo-contabilizzato_ANPAG;
			}
			if (importo<0) importo=0;
			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale della missione poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}

		private void cmbCausaleMissione_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleMissione();
			ReCalcImporto_Missione();//Richiama indirettamente RicalcolaPrestazioneMissione();
		}

		
		/// <summary>
		/// Legge la causale dal combobox e la mette in tipomovimento ove 
		///  possibile.
		/// </summary>
		string GetCausaleMissione(){
			CurrCausaleMissione= "";
			if (DS.expenseitineration.Rows.Count==0) return "";
			if (ContabilizzazioneSelezionata()!=tipocont.cont_missione)return "";
			if (cmbCausale.SelectedValue!=null)
				DS.expenseitineration.Rows[0]["movkind"]= cmbCausale.SelectedValue;
			else
				DS.expenseitineration.Rows[0]["movkind"]= DBNull.Value;			
			CurrCausaleMissione= DS.expenseitineration.Rows[0]["movkind"].ToString();
			return CurrCausaleMissione; 
			//ReCalcImporto();
		}

		#endregion


		#region Gestione Selezione Cedolino 



		//		void AbilitaDisabilitaBtnMissione(){
		//			int fasemissione = ManageMissione.faseattivazione;
		//			bool SelezioneMissioneAttiva=false;
		//			if ((faseinizio<= fasemissione) && (fasemissione<= fasespesafine)) 
		//				SelezioneMissioneAttiva=true;
		//			btnDocumento.Enabled=  SelezioneMissioneAttiva;
		//			txtNumDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			txtEsercDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumDoc.Text.Trim()!="");
		//			//txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//			AbilitaDisabilitaCreditoreDebitore();
		//		}

		private void txtEsercCedolino_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
		}

		
		string GetFilterCedolino(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			string FilterCedolino="(fiscalyear<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int annoriferimento= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (annoriferimento <= esercizio) 
						FilterCedolino="(fiscalyear='"+annoriferimento.ToString()+"')";
					else 
						FilterCedolino = //GetData.MergeFilters(FilterCedolino,
							"(fiscalyear='"+annoriferimento.ToString()+"')";
					//);
				}
				catch {
				}
			} 
			if (FiltraNum){
				int meseriferimento= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterCedolino = GetData.MergeFilters(FilterCedolino,
						"(npayroll='"+meseriferimento.ToString()+"')");
				} 
			}

			//if (Meta.InsertMode){
			if (true){
				FilterCedolino+="AND(disbursementdate is null)AND(fiscalyear='"+
					esercizio.ToString()
					+"')";
			}

			
			return FilterCedolino;
		}


		private void btnCedolino_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);

			string MyCedolinoFilter;
			if (((Control)sender).Name == "txtNumDoc")
				MyCedolinoFilter = GetFilterCedolino(true);
			else
				MyCedolinoFilter = GetFilterCedolino(false);


			DataRow Curr = DS.expense.Rows[0];
			bool condfasecred = chkCredDeb.Checked;
			
			if (condfasecred){
				MyCedolinoFilter= GetData.MergeFilters(MyCedolinoFilter,
					"(registry="+
					QueryCreator.quotedstrvalue(txtCredDeb.Text,true)+")");
				
			}

			MetaData MCedolino;
			DataRow MyDRCedolino;

			MCedolino = MetaData.GetMetaData(this,"payrollavailable");
			MCedolino.FilterLocked=true;
			MCedolino.DS = DS.Clone();
			
			MyDRCedolino = MCedolino.SelectOne("default",
				GetData.MergeFilters( MyCedolinoFilter,
				"(feegross="+	QueryCreator.quotedstrvalue(currimp,true)+
				")"),
				null,null);

			if(MyDRCedolino == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectced= "(idpayroll='"+MyDRCedolino["idpayroll"].ToString()+"')";


			string columnlist = QueryCreator.ColumnNameList(DS.payroll)
				+",registry";
			DataTable Temp = Meta.Conn.RUN_SELECT("payrollview",columnlist,null,selectced,null,null,true);
			
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetCedolino();
			CollegaCedolino(MyDR);
	
		}

		private void txtNumCedolino_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;

			if (txtNumDoc.Text.Trim()=="") {
				ScollegaCedolino();				
				return;
			}
			btnCedolino_Click(sender,e);
		}

		void AbilitaDisabilitaControlliCedolino(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
		}

		void ClearControlliCedolino(){
		}

		/// <summary>
		/// Collega la riga missione al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		bool CollegaCedolino(DataRow Cedolino2){
			
			Hashtable ValoriCedolino = new Hashtable();
			foreach (DataColumn C in DS.payroll.Columns) 
				ValoriCedolino[C.ColumnName]= Cedolino2[C.ColumnName];

			//AzzeraPadre();
			ScollegaCedolino();
			DataRow CurrRow= DS.expense.Rows[0];

			if (!faseOrdineInclusa())return false;

			DataRow NewCedR = DS.payroll.NewRow();
			foreach (DataColumn C in DS.payroll.Columns){
				NewCedR[C.ColumnName]= ValoriCedolino[C.ColumnName];
			}
			DS.payroll.Rows.Add(NewCedR);
			NewCedR.AcceptChanges();
			Cedolino2= NewCedR;

			MetaData MovCed = MetaData.GetMetaData(this,"expensepayroll");
			MovCed.SetDefaults(DS.expensepayroll);
			DS.expensepayroll.Columns["idpayroll"].DefaultValue= ValoriCedolino["idpayroll"];
			DataRow RMovCed = MovCed.Get_New_Row(CurrRow, DS.expensepayroll);
			DS.expensepayroll.Columns["idpayroll"].DefaultValue= DBNull.Value;
			txtNumDoc.Text= CfgFn.GetNoNullInt32(Meta.Conn.DO_READ_VALUE("payroll", "(idpayroll="+QueryCreator.quotedstrvalue(ValoriCedolino["idpayroll"]
				,true)+")", "npayroll")).ToString();
			txtEsercDoc.Text= CfgFn.GetNoNullInt32(Meta.Conn.DO_READ_VALUE("payroll", "(idpayroll="+QueryCreator.quotedstrvalue(ValoriCedolino["idpayroll"]
				,true)+")", "fiscalyear")).ToString();

			//txtNumDoc.Text= ValoriMissione["nummissione"].ToString();
			//txtEsercDoc.Text= ValoriMissione["esercmissione"].ToString();

			NuovoDocumento= "Cedolino "+
				ValoriCedolino["fiscalyear"].ToString()+"/"+
				ValoriCedolino["npayroll"].ToString();	//.PadLeft(2,'0');
				
			//NuovoDataDocumento = (DateTime)ValoriMissione["datacontabile"];
			NuovoDescrizione = NuovoDocumento;


			RintracciaCedolino();
			SetComboCausaleCedolino(Cedolino2);
			AbilitaDisabilitaControlliCedolino(false);
			cmbCausale.Enabled=true;
			return true;
		}

		
		void ScollegaCedolino(){
			if (DS.expensepayroll.Rows.Count==0) {
				AbilitaDisabilitaControlliCedolino(true);
				return;
			}
			DS.expensepayroll.Clear();
			DS.payroll.Clear();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			
			ClearComboCausale();
			AbilitaDisabilitaControlliCedolino(true);
		}


	
		#endregion

		#region Gestione ComboBox Causale Cedolino
		decimal cedolinolordo;
		decimal contabilizzatocedolino;




		string lastCedEvalued=null;
		void CalcolaContabilizzatiCedolino(DataRow Cedolino){
			string filterced = "(idpayroll='"+Cedolino["idpayroll"].ToString()+"')";
			decimal totlordo= CfgFn.GetNoNullDecimal(Cedolino["feegross"]);

			if (filterced==lastCedEvalued) return;
			lastCedEvalued= filterced;
			
			DataTable Residuo = Conn.RUN_SELECT("payrollresidual","*",null,filterced,null,true);

			DataRow CurrResid = Residuo.Rows[0];
			contabilizzatocedolino= CfgFn.GetNoNullDecimal(CurrResid["linkedamount"]);
			decimal residuo = CfgFn.GetNoNullDecimal( CurrResid["residual"]);

		}


		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleCedolino(DataRow Cedolino){
			if (!faseCedolinoInclusa()){
				cmbCausale.Enabled=false;
				return;
			}
			cedolinolordo= CfgFn.GetNoNullDecimal(Cedolino["feegross"]);
			CalcolaContabilizzatiCedolino(Cedolino);

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;

			if ( 
				(contabilizzatocedolino< cedolinolordo)
				){
				EnableTipoMovimento("SALDO","Pagamento");
			}


			//DS.cedolinomovspesa.Rows[0]["tipomovimento"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=Meta.InsertMode;
			ReCalcImporto_Cedolino();
			
		}

	


		void ReCalcImporto_Cedolino(){
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=cedolinolordo-contabilizzatocedolino;

			if (importo<0) importo=0;
			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale della missione poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}

		private void cmbCausaleCedolino_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleCedolino();
			ReCalcImporto_Cedolino();//Richiama indirettamente RicalcolaPrestazioneMissione();
		}

		
		/// <summary>
		/// Legge la causale dal combobox e la mette in tipomovimento ove 
		///  possibile.
		/// </summary>
		string GetCausaleCedolino(){
			CurrCausaleCedolino= "";
			if (DS.expensepayroll.Rows.Count==0) return "";
			if (ContabilizzazioneSelezionata()!=tipocont.cont_cedolino)return "";
			CurrCausaleCedolino= "SALDO";
			return CurrCausaleCedolino; 
			//ReCalcImporto();
		}

		#endregion


		#region Gestione Selezione Occasionale 



		//		void AbilitaDisabilitaBtnMissione(){
		//			int fasemissione = ManageMissione.faseattivazione;
		//			bool SelezioneMissioneAttiva=false;
		//			if ((faseinizio<= fasemissione) && (fasemissione<= fasespesafine)) 
		//				SelezioneMissioneAttiva=true;
		//			btnDocumento.Enabled=  SelezioneMissioneAttiva;
		//			txtNumDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			txtEsercDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumDoc.Text.Trim()!="");
		//			//txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//			AbilitaDisabilitaCreditoreDebitore();
		//		}

		private void txtEsercOccasionale_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
		}
		string GetFilterOccasionale(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			string FilterOccasionale="(ycon<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int eserccontratto= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (eserccontratto <= esercizio) 
						FilterOccasionale="(ycon='"+eserccontratto.ToString()+"')";
					else 
						FilterOccasionale = GetData.MergeFilters(FilterOccasionale,
							"(ycon='"+eserccontratto.ToString()+"')");
				}
				catch {
				}
			} 
			if (FiltraNum){
				int numcontratto= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterOccasionale = GetData.MergeFilters(FilterOccasionale,
						"(ncon='"+numcontratto.ToString()+"')");
				} 
			}						

			return FilterOccasionale;
		}

		private void btnOccasionale_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);
			string MyOccasionaleFilter;
			if (((Control)sender).Name == "txtNumDoc")
				MyOccasionaleFilter = GetFilterOccasionale(true);
			else
				MyOccasionaleFilter = GetFilterOccasionale(false);

			DataRow Curr = DS.expense.Rows[0];
			bool condfasecred = chkCredDeb.Checked;
			
			if (condfasecred){
				MyOccasionaleFilter = GetData.MergeFilters(MyOccasionaleFilter,
					"(idreg="+
					QueryCreator.quotedstrvalue(Curr["idreg"],true)+")");
			}


			MetaData MOccasionale;
			DataRow MyDROccasionale;


			MOccasionale = MetaData.GetMetaData(this,"casualcontractavailable");
			MOccasionale.FilterLocked=true;
			MOccasionale.DS = DS.Clone();
            string filterres = MyOccasionaleFilter;
            if(chkFilterResidual.Checked) filterres =
                GetData.MergeFilters( MyOccasionaleFilter,"(residual>="+
				QueryCreator.quotedstrvalue(currimp,true)+
				")");

			MyDROccasionale = MOccasionale.SelectOne("default",filterres,null,null);
			
			if(MyDROccasionale == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectocc= "(ycon='"+MyDROccasionale["ycon"].ToString()+"')AND"+
				"(ncon='"+MyDROccasionale["ncon"].ToString()+"')";

			string columnlist = QueryCreator.ColumnNameList(DS.casualcontract)
				+",registry";

			DataTable Temp = Meta.Conn.RUN_SELECT("casualcontractview",columnlist,null,selectocc,null,null,true);
			
		
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetOccasionale();
			CollegaOccasionale(MyDR);
	
		}

		private void txtNumOccasionale_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;

			if (txtNumDoc.Text.Trim()=="") {
				ScollegaOccasionale();				
				return;
			}
			btnOccasionale_Click(sender,e);
		}

		void AbilitaDisabilitaControlliOccasionale(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
		}

		void ClearControlliOccasionale(){
		}

		/// <summary>
		/// Collega la riga missione al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		bool CollegaOccasionale(DataRow ContrattoOcc2){
			
			Hashtable ValoriOccasionale = new Hashtable();
			foreach (DataColumn C in DS.casualcontract.Columns) 
				ValoriOccasionale[C.ColumnName]= ContrattoOcc2[C.ColumnName];


			//AzzeraPadre();
			ScollegaOccasionale();
			DataRow CurrRow= DS.expense.Rows[0];

			if (!faseOccasionaleInclusa())return false;

			DataRow NewOccR = DS.casualcontract.NewRow();
			foreach (DataColumn C in DS.casualcontract.Columns){
				NewOccR[C.ColumnName]= ValoriOccasionale[C.ColumnName];
			}
			DS.casualcontract.Rows.Add(NewOccR);
			NewOccR.AcceptChanges();
			ContrattoOcc2= NewOccR;
			MetaData MovOcc = MetaData.GetMetaData(this,"expensecasualcontract");
			MovOcc.SetDefaults(DS.expensecasualcontract);
			DS.expensecasualcontract.Columns["ycon"].DefaultValue= ValoriOccasionale["ycon"];
			DS.expensecasualcontract.Columns["ncon"].DefaultValue= ValoriOccasionale["ncon"];
			DataRow RMovOcc = MovOcc.Get_New_Row(CurrRow, DS.expensecasualcontract);
			DS.expensecasualcontract.Columns["ycon"].DefaultValue= DBNull.Value;
			DS.expensecasualcontract.Columns["ncon"].DefaultValue= DBNull.Value;
			txtEsercDoc.Text= ValoriOccasionale["ycon"].ToString();
			txtNumDoc.Text= ValoriOccasionale["ncon"].ToString();

			NuovoDocumento=  "Contratto Occasionale "+
				ValoriOccasionale["ycon"].ToString().Substring(2,2)+"/"+
				ValoriOccasionale["ncon"].ToString().PadLeft(6,'0');
			NuovoDataDocumento = ValoriOccasionale["adate"];
			NuovoDescrizione = ValoriOccasionale["description"];


			RintracciaOccasionale();
			SetComboCausaleOccasionale(ContrattoOcc2);
			AbilitaDisabilitaControlliOccasionale(false);
			cmbCausale.Enabled=true;
			return true;
		}

		
		void ScollegaOccasionale(){
			if (DS.expensecasualcontract.Rows.Count==0) {
				AbilitaDisabilitaControlliOccasionale(true);
				return;
			}
			DS.expensecasualcontract.Clear();
			DS.casualcontract.Clear();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			
			ClearComboCausale();
			AbilitaDisabilitaControlliOccasionale(true);
		}


	
		#endregion

		#region Gestione ComboBox Causale Occasionale
		decimal occasionalelordo;
		decimal contabilizzatooccasionale;



		string lastOccEvalued=null;

		void CalcolaContabilizzatiOccasionale(DataRow ContrattoOcc){
			string filterocc = "(ycon='"+ContrattoOcc["ycon"].ToString()+"')AND"+
				"(ncon='"+ContrattoOcc["ncon"].ToString()+"')";
			decimal totlordo= CfgFn.GetNoNullDecimal(ContrattoOcc["feegross"]);

			if (filterocc==lastOccEvalued) return;
			lastOccEvalued= filterocc;
			
			DataTable Residuo = Conn.RUN_SELECT("casualcontractresidual","*",null,filterocc,null,true);

			DataRow CurrResid = Residuo.Rows[0];
			contabilizzatooccasionale= CfgFn.GetNoNullDecimal(CurrResid["linkedtotal"]);
			//decimal residuo = CfgFn.GetNoNullDecimal( CurrResid["residuo"]);
			//contabilizzato_VARIAZIONI= -(totlordo-residuo-contabilizzatooccasionale);
		}




		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleOccasionale(DataRow ContrattoOcc){
			if (!faseOccasionaleInclusa()){
				cmbCausale.Enabled=false;
				return;
			}
			occasionalelordo= CfgFn.GetNoNullDecimal(ContrattoOcc["feegross"]);

			CalcolaContabilizzatiOccasionale(ContrattoOcc);

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;
			if ( (Meta.EditMode) || 
				(contabilizzatooccasionale< occasionalelordo)
				){
				EnableTipoMovimento("SALDO","Pagamento");
			}

			//DS.contrattooccmovspesa.Rows[0]["tipomovimento"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=Meta.InsertMode;
			ReCalcImporto_Occasionale();
			
		}

	


		void ReCalcImporto_Occasionale(){
			if (Meta.IsEmpty) return;
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if ((currphase()>1)&&(Curr["parentidexp"]==DBNull.Value)) return;
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=occasionalelordo-contabilizzatooccasionale;

			//if ((currphase>1)&& (importo> DisponibileDaFasePrecedente)) importo=DisponibileDaFasePrecedente;	

			if (importo<0) importo=0;
			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale del contratto poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}

		private void cmbCausaleOccasionale_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleOccasionale();
			ReCalcImporto_Occasionale();//Richiama indirettamente RicalcolaPrestazioneMissione();
		}

		
		/// <summary>
		/// Legge la causale dal combobox e la mette in tipomovimento ove 
		///  possibile.
		/// </summary>
		string GetCausaleOccasionale(){
			CurrCausaleOccasionale= "";
			if (DS.expensecasualcontract.Rows.Count==0) return "";
			if (ContabilizzazioneSelezionata()!=tipocont.cont_occasionale)return "";
			CurrCausaleOccasionale= "SALDO";
			return CurrCausaleOccasionale; 
		}

		#endregion


		
		#region Gestione Selezione Dipendente 



		//		void AbilitaDisabilitaBtnMissione(){
		//			int fasemissione = ManageMissione.faseattivazione;
		//			bool SelezioneMissioneAttiva=false;
		//			if ((faseinizio<= fasemissione) && (fasemissione<= fasespesafine)) 
		//				SelezioneMissioneAttiva=true;
		//			btnDocumento.Enabled=  SelezioneMissioneAttiva;
		//			txtNumDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			txtEsercDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumDoc.Text.Trim()!="");
		//			//txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//			AbilitaDisabilitaCreditoreDebitore();
		//		}

		private void txtEsercDipendente_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
		}
		string GetFilterDipendente(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			string FilterDipendente="(ycon<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int eserccontratto= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (eserccontratto <= esercizio) 
						FilterDipendente="(ycon='"+eserccontratto.ToString()+"')";
					else 
						FilterDipendente = GetData.MergeFilters(FilterDipendente,
							"(ycon='"+eserccontratto.ToString()+"')");
				}
				catch {
				}
			} 
			if (FiltraNum){
				int numcontratto= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterDipendente = GetData.MergeFilters(FilterDipendente,
						"(ncon='"+numcontratto.ToString()+"')");
				} 
			}						

			return FilterDipendente;
		}

		private void btnDipendente_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);
			string MyDipendenteFilter;
			if (((Control)sender).Name == "txtNumDoc")
				MyDipendenteFilter = GetFilterDipendente(true);
			else
				MyDipendenteFilter = GetFilterDipendente(false);

			DataRow Curr = DS.expense.Rows[0];
			bool condfasecred = chkCredDeb.Checked;
			
			if (condfasecred){
				MyDipendenteFilter = GetData.MergeFilters(MyDipendenteFilter,
					"(idreg="+
					QueryCreator.quotedstrvalue(Curr["idreg"],true)+")");
			}


			MetaData MDipendente;
			DataRow MyDRDipendente;


			MDipendente = MetaData.GetMetaData(this,"wageadditionavailable");
			MDipendente.FilterLocked=true;
			MDipendente.DS = DS.Clone();
            string filterres = MyDipendenteFilter;
            if (chkFilterResidual.Checked)filterres=GetData.MergeFilters( MyDipendenteFilter,"(residual>="+
				QueryCreator.quotedstrvalue(currimp,true)+
				")");
			
			MyDRDipendente = MDipendente.SelectOne("default",filterres,	null,null);
			
			if(MyDRDipendente == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectdip= "(ycon='"+MyDRDipendente["ycon"].ToString()+"')AND"+
				"(ncon='"+MyDRDipendente["ncon"].ToString()+"')";

			string columnlist = QueryCreator.ColumnNameList(DS.wageaddition)
				+",registry";

			DataTable Temp = Meta.Conn.RUN_SELECT("wageadditionview",columnlist,null,selectdip,null,null,true);
			
		
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetDipendente();
			CollegaDipendente(MyDR);
	
		}

		private void txtNumDipendente_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;

			if (txtNumDoc.Text.Trim()=="") {
				ScollegaDipendente();				
				return;
			}
			btnDipendente_Click(sender,e);
		}

		void AbilitaDisabilitaControlliDipendente(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
		}

		void ClearControlliDipendente(){
		}

		/// <summary>
		/// Collega la riga missione al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		bool CollegaDipendente(DataRow ContrattoDip2){
			
			Hashtable ValoriDipendente = new Hashtable();
			foreach (DataColumn C in DS.wageaddition.Columns) 
				ValoriDipendente[C.ColumnName]= ContrattoDip2[C.ColumnName];


			//AzzeraPadre();
			ScollegaDipendente();
			DataRow CurrRow= DS.expense.Rows[0];

			if (!faseDipendenteInclusa())return false;

			DataRow NewDipR = DS.wageaddition.NewRow();
			foreach (DataColumn C in DS.wageaddition.Columns){
				NewDipR[C.ColumnName]= ValoriDipendente[C.ColumnName];
			}
			DS.wageaddition.Rows.Add(NewDipR);
			NewDipR.AcceptChanges();
			ContrattoDip2= NewDipR;
			MetaData MovDip = MetaData.GetMetaData(this,"expensewageaddition");
			MovDip.SetDefaults(DS.expensewageaddition);
			DS.expensewageaddition.Columns["ycon"].DefaultValue= ValoriDipendente["ycon"];
			DS.expensewageaddition.Columns["ncon"].DefaultValue= ValoriDipendente["ncon"];
			DataRow RMovDip = MovDip.Get_New_Row(CurrRow, DS.expensewageaddition);
			DS.expensewageaddition.Columns["ycon"].DefaultValue= DBNull.Value;
			DS.expensewageaddition.Columns["ncon"].DefaultValue= DBNull.Value;
			txtEsercDoc.Text= ValoriDipendente["ycon"].ToString();
			txtNumDoc.Text= ValoriDipendente["ncon"].ToString();

			NuovoDocumento=  "Compenso a Dipendente "+
				ValoriDipendente["ycon"].ToString().Substring(2,2)+"/"+
				ValoriDipendente["ncon"].ToString().PadLeft(6,'0');
			NuovoDataDocumento = ValoriDipendente["adate"];
			NuovoDescrizione = ValoriDipendente["description"];


			RintracciaDipendente();
			SetComboCausaleDipendente(ContrattoDip2);
			AbilitaDisabilitaControlliDipendente(false);
			cmbCausale.Enabled=true;
			return true;
		}

		
		void ScollegaDipendente(){
			if (DS.expensewageaddition.Rows.Count==0) {
				AbilitaDisabilitaControlliDipendente(true);
				return;
			}
			DS.expensewageaddition.Clear();
			DS.wageaddition.Clear();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			
			ClearComboCausale();
			AbilitaDisabilitaControlliDipendente(true);
		}


		#endregion

		#region Gestione ComboBox Causale Dipendente
		decimal dipendentelordo;
		decimal contabilizzatodipendente;



		string lastDipEvalued=null;

		void CalcolaContabilizzatiDipendente(DataRow ContrattoDip){
			string filterdip= "(ycon='"+ContrattoDip["ycon"].ToString()+"')AND"+
				"(ncon='"+ContrattoDip["ncon"].ToString()+"')";
			decimal totlordo= CfgFn.GetNoNullDecimal(ContrattoDip["feegross"]);

			if (filterdip==lastDipEvalued) return;
			lastDipEvalued= filterdip;
			
			DataTable Residuo = Conn.RUN_SELECT("wageadditionresidual","*",null,filterdip,null,true);

			DataRow CurrResid = Residuo.Rows[0];
			contabilizzatodipendente= CfgFn.GetNoNullDecimal(CurrResid["linkedtotal"]);
			//decimal residuo = CfgFn.GetNoNullDecimal( CurrResid["residuo"]);
			//contabilizzato_VARIAZIONI= -(totlordo-residuo-contabilizzatooccasionale);
		}




		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleDipendente(DataRow ContrattoDip){
			if (!faseDipendenteInclusa()){
				cmbCausale.Enabled=false;
				return;
			}
			dipendentelordo= CfgFn.GetNoNullDecimal(ContrattoDip["feegross"]);

			CalcolaContabilizzatiDipendente(ContrattoDip);

			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;
			if ( (Meta.EditMode) || 
				(contabilizzatodipendente< dipendentelordo)
				){
				EnableTipoMovimento("SALDO","Pagamento");
			}

			//DS.contrattooccmovspesa.Rows[0]["tipomovimento"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=Meta.InsertMode;
			ReCalcImporto_Dipendente();
			
		}

	


		void ReCalcImporto_Dipendente(){
			if (Meta.IsEmpty) return;
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if ((currphase()>1)&&(Curr["parentidexp"]==DBNull.Value)) return;
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=dipendentelordo-contabilizzatodipendente;

			//if ((currphase>1)&& (importo> DisponibileDaFasePrecedente)) importo=DisponibileDaFasePrecedente;	

			if (importo<0) importo=0;
			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale del compenso poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}

		private void cmbCausaleDipendente_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleDipendente();
			ReCalcImporto_Dipendente();//Richiama indirettamente RicalcolaPrestazioneMissione();
		}

		
		/// <summary>
		/// Legge la causale dal combobox e la mette in tipomovimento ove 
		///  possibile.
		/// </summary>
		string GetCausaleDipendente(){
			CurrCausaleDipendente= "";
			if (DS.expensewageaddition.Rows.Count==0) return "";
			if (ContabilizzazioneSelezionata()!=tipocont.cont_dipendente)return "";
			CurrCausaleDipendente= "SALDO";
			return CurrCausaleDipendente; 
		}

		#endregion


		#region Gestione Selezione Professionale 



		//		void AbilitaDisabilitaBtnMissione(){
		//			int fasemissione = ManageMissione.faseattivazione;
		//			bool SelezioneMissioneAttiva=false;
		//			if ((faseinizio<= fasemissione) && (fasemissione<= fasespesafine)) 
		//				SelezioneMissioneAttiva=true;
		//			btnDocumento.Enabled=  SelezioneMissioneAttiva;
		//			txtNumDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			txtEsercDoc.ReadOnly= !SelezioneMissioneAttiva;
		//			cmbCausale.Enabled= Meta.InsertMode && (txtNumDoc.Text.Trim()!="");
		//			//txtCredDeb.ReadOnly = !Meta.IsEmpty;
		//			AbilitaDisabilitaCreditoreDebitore();
		//		}

		private void txtEsercProfessionale_Leave(object sender, System.EventArgs e) {
			if (txtEsercDoc.ReadOnly)return;
			if (!Meta.DrawStateIsDone) return;
			FormattaDataDelTexBox(txtEsercDoc);		
		}

		string GetFilterProfessionale(bool FiltraNum){
			int esercizio= Convert.ToInt32(Meta.GetSys("esercizio"));
			string FilterProfessionale="(ycon<='"+esercizio.ToString()+"')";
			if(txtEsercDoc.Text != ""){
				int eserccontratto= CfgFn.GetNoNullInt32(txtEsercDoc.Text);
				try {
					if (eserccontratto <= esercizio) 
						FilterProfessionale="(ycon='"+eserccontratto.ToString()+"')";
					else 
						FilterProfessionale = GetData.MergeFilters(FilterProfessionale,
							"(ycon='"+eserccontratto.ToString()+"')");
				}
				catch {
				}
			} 
			if (FiltraNum){
				int numcontratto= CfgFn.GetNoNullInt32(txtNumDoc.Text);
				if(txtNumDoc.Text != ""){
					FilterProfessionale = GetData.MergeFilters(FilterProfessionale,
						"(ncon='"+numcontratto.ToString()+"')");
				} 
			}						

			return FilterProfessionale;
		}

		private void btnProfessionale_Click(object sender, System.EventArgs e) {
			
			DataAccess Conn = MetaData.GetConnection(this);

			string MyProfessionaleFilter;
			if (((Control)sender).Name == "txtNumDoc")
				MyProfessionaleFilter = GetFilterProfessionale(true);
			else
				MyProfessionaleFilter = GetFilterProfessionale(false);


			DataRow Curr = DS.expense.Rows[0];
			bool condfasecred = chkCredDeb.Checked;
			
			if (condfasecred){
				MyProfessionaleFilter = GetData.MergeFilters(MyProfessionaleFilter,
					"(idreg="+
					QueryCreator.quotedstrvalue(Curr["idreg"],true)+")");
			}


			MetaData MProfessionale;
			DataRow MyDRProfessionale;


			MProfessionale = MetaData.GetMetaData(this,"profserviceavailable");
			MProfessionale.FilterLocked=true;
			MProfessionale.DS = DS.Clone();
            string filterres = MyProfessionaleFilter;
            if (chkFilterResidual.Checked) filterres=GetData.MergeFilters( MyProfessionaleFilter,"(residual>="+
				QueryCreator.quotedstrvalue(currimp,true)+
				")");
			
			MyDRProfessionale = MProfessionale.SelectOne("default",filterres,null,null);
			
			if(MyDRProfessionale == null) {
				if (typeof(TextBox).IsAssignableFrom(sender.GetType())){
					if (((TextBox)sender).Text.Trim()!="")	((TextBox)sender).Focus();
				}
				return;
			}
			string selectprof= "(ycon='"+MyDRProfessionale["ycon"].ToString()+"')AND"+
				"(ncon='"+MyDRProfessionale["ncon"].ToString()+"')";

			string columnlist = QueryCreator.ColumnNameList(DS.profservice)
				+",registry";

			DataTable Temp = Meta.Conn.RUN_SELECT("profserviceview",columnlist,null,selectprof,null,null,true);
			
		
			//if (Temp.Rows.Count==0) return;

			DataRow MyDR = Temp.Rows[0];

		
			//Inserisco nella riga attuale il valore idspesa nel campo livsupidspesa
			//al fine di consentire il calcolo automatico del nuovo idspesa.
			//Poi eredito tutti i campi dell'eventuale movimento padre.
			ResetProfessionale();
			CollegaProfessionale(MyDR);
	
		}

		private void txtNumProfessionale_Leave(object sender, System.EventArgs e) {
			if (txtNumDoc.ReadOnly)return;
			//if (!Meta.InsertMode) return;

			if (txtNumDoc.Text.Trim()=="") {
				ScollegaProfessionale();				
				return;
			}
			btnProfessionale_Click(sender,e);
		}

		void AbilitaDisabilitaControlliProfessionale(bool abilita){
			//txtCredDeb.ReadOnly=!abilita;
		}

		void ClearControlliProfessionale(){
		}

		/// <summary>
		/// Collega la riga missione al movimento e aggiorna il form.
		/// </summary>
		/// <param name="Ordine"></param>
		bool CollegaProfessionale(DataRow ContrattoProf2){
			
			Hashtable ValoriProfessionale = new Hashtable();
			foreach (DataColumn C in DS.profservice.Columns) 
				ValoriProfessionale[C.ColumnName]= ContrattoProf2[C.ColumnName];


			//AzzeraPadre();
			ScollegaOccasionale();
			DataRow CurrRow= DS.expense.Rows[0];

			if (!faseProfessionaleInclusa())return false;

			DataRow NewProfR = DS.profservice.NewRow();
			foreach (DataColumn C in DS.profservice.Columns){
				NewProfR[C.ColumnName]= ValoriProfessionale[C.ColumnName];
			}
			DS.profservice.Rows.Add(NewProfR);
			NewProfR.AcceptChanges();
			ContrattoProf2= NewProfR;
			MetaData MovProf = MetaData.GetMetaData(this,"expenseprofservice");
			MovProf.SetDefaults(DS.expenseprofservice);
			DS.expenseprofservice.Columns["ycon"].DefaultValue= ValoriProfessionale["ycon"];
			DS.expenseprofservice.Columns["ncon"].DefaultValue= ValoriProfessionale["ncon"];
			DataRow RMovOcc = MovProf.Get_New_Row(CurrRow, DS.expenseprofservice);
			DS.expenseprofservice.Columns["ycon"].DefaultValue= DBNull.Value;
			DS.expenseprofservice.Columns["ncon"].DefaultValue= DBNull.Value;
			txtEsercDoc.Text= ValoriProfessionale["ycon"].ToString();
			txtNumDoc.Text= ValoriProfessionale["ncon"].ToString();


			NuovoDocumento=  ValoriProfessionale["doc"];
			NuovoDataDocumento = ValoriProfessionale["adate"];
			NuovoDescrizione = ValoriProfessionale["description"];


			RintracciaProfessionale();
			SetComboCausaleProfessionale(ContrattoProf2);
			AbilitaDisabilitaControlliProfessionale(false);
			cmbCausale.Enabled=true;
			return true;
		}

		
		void ScollegaProfessionale(){
			if (DS.expensecasualcontract.Rows.Count==0) {
				AbilitaDisabilitaControlliOccasionale(true);
				return;
			}
			DS.expenseprofservice.Clear();
			DS.profservice.Clear();
			NuovoDataDocumento=null;
			NuovoDocumento=null;
			NuovoDescrizione=null;
			
			ClearComboCausale();
			AbilitaDisabilitaControlliProfessionale(true);
		}


	
		#endregion

		#region Gestione ComboBox Causale Professionale

		decimal totprofimponibile;
		decimal totprofiva;
		decimal assigned_profimponibile;
		decimal assigned_profiva;
		decimal assigned_profgen;


		string lastProfEvalued=null;
		void CalcolaContabilizzatiProfessionale(DataRow ContrattoProf){
			string filterprof = "(ycon='"+ContrattoProf["ycon"].ToString()+"')AND"+
				"(ncon='"+ContrattoProf["ncon"].ToString()+"')";
			if (filterprof==lastProfEvalued) return;
			lastProfEvalued= filterprof;
			decimal costototale= CfgFn.GetNoNullDecimal(ContrattoProf["totalcost"]);			
			totprofiva=CfgFn.GetNoNullDecimal( ContrattoProf["importoiva"]);
			totprofimponibile=costototale-totprofiva;

			DataTable Residuo = Conn.RUN_SELECT("profserviceresidual","*",null,filterprof,null,true);

			DataRow CurrResid = Residuo.Rows[0];
			assigned_profimponibile= CfgFn.GetNoNullDecimal(CurrResid["linkedimpon"]);
			assigned_profiva= CfgFn.GetNoNullDecimal(CurrResid["linkedimpos"]);
			assigned_profgen= CfgFn.GetNoNullDecimal(CurrResid["linkeddocum"]);
			//decimal residuo = CfgFn.GetNoNullDecimal(CurrResid["residuo"]);
			//contabilizzato_VARIAZIONI= 0; //-(totlordo-residuo-contabilizzato_ANPAG-contabilizzato_SALDO);

		}




		/// <summary>
		/// Riempie il combobox causale con i valori ammessi, senza impostarvi alcun valore
		/// </summary>
		/// <param name="Ordine"></param>
		void SetComboCausaleProfessionale(DataRow ContrattoProf){
			if (!faseProfessionaleInclusa()){
				cmbCausale.Enabled=false;
				return;
			}

			string filterordine = "(ycon='"+ContrattoProf["ycon"].ToString()+"')AND"+
				"(ncon='"+ContrattoProf["ncon"].ToString()+"')";


			DataTable T= Conn.RUN_SELECT("profserviceresidual","*",null,filterordine,null,true);
			if ((T!=null)&&(T.Rows.Count>0)){
				DataRow R=T.Rows[0];
				totprofimponibile=CfgFn.GetNoNullDecimal( R["taxabletotal"]);
				totprofiva=CfgFn.GetNoNullDecimal( R["ivatotal"]);
				assigned_profimponibile= CfgFn.GetNoNullDecimal( R["linkedimpon"]);
				assigned_profiva= CfgFn.GetNoNullDecimal( R["linkedimpos"]);
				assigned_profgen=CfgFn.GetNoNullDecimal( R["linkeddocum"]);

			}
			else {
				totprofimponibile= 0;
				totprofiva =  0;
				assigned_profimponibile= 0;
				assigned_profiva= 0;
				assigned_profgen= 0;
			}


			ClearComboCausale();
			DataTable TCombo= DS.tipomovimento;

			if ((Meta.EditMode) || 
				((assigned_profimponibile+assigned_profiva)==0) && 
				(assigned_profgen< (totprofimponibile+totprofiva))
				){
				EnableTipoMovimento("DOCUM","Contabilizzazione Totale Fattura");
			}

			if ((Meta.EditMode) || 
				( (assigned_profgen==0) &&(assigned_profimponibile < totprofimponibile))
				){
				EnableTipoMovimento("IMPON","Contabilizzazione Imponibile Fattura");
			}

			if ( (Meta.EditMode) || 
				( (assigned_profgen==0) &&(assigned_profiva< totprofiva))
				){
				EnableTipoMovimento("IMPOS","Contabilizzazione Iva Fattura");
			}

			DS.expenseprofservice.Rows[0]["movkind"]=	 cmbCausale.SelectedValue;
			cmbCausale.Enabled=Meta.InsertMode;
			ReCalcImporto_Professionale();
			
		}

	


		void ReCalcImporto_Professionale(){
			if (Meta.IsEmpty) return;
			DataRow Curr = DS.Tables["expense"].Rows[0];
			if ((currphase()>1)&&(Curr["parentidexp"]==DBNull.Value)) return;
			if (cmbCausale.SelectedValue==null) return;

			string tipomovimento = cmbCausale.SelectedValue.ToString();

			decimal importo=0;
			if (tipomovimento=="IMPOS"){
				importo= totprofiva-assigned_profiva;
			}
			if (tipomovimento=="IMPON"){
				importo= totprofimponibile-assigned_profimponibile;
			}
			if (tipomovimento=="DOCUM"){
				importo= totprofimponibile+totprofiva-assigned_profgen;
			}
			if (importo<0) importo=0;

			//if ((currphase>1)&& (importo> DisponibileDaFasePrecedente)) importo=DisponibileDaFasePrecedente;	

			if (importo> currimp) {
				MessageBox.Show("Sar� effettuata una contabilizzazione parziale del contratto poich� la "+
					"disponibilit� del movimento selezionato � inferiore a "+importo.ToString());
			}

		}

		private void cmbCausaleProfessionale_SelectedIndexChanged(object sender, System.EventArgs e) {
			GetCausaleProfessionale();
			ReCalcImporto_Professionale();//Richiama indirettamente RicalcolaPrestazioneMissione();
		}

		
		/// <summary>
		/// Legge la causale dal combobox e la mette in tipomovimento ove 
		///  possibile.
		/// </summary>
		string GetCausaleProfessionale(){
			CurrCausaleProfessionale= "";
			if (DS.expenseprofservice.Rows.Count==0) return "";
			if (ContabilizzazioneSelezionata()!=tipocont.cont_professionale)return "";
			if (cmbCausale.SelectedValue!=null)
				DS.expenseprofservice.Rows[0]["movkind"]= cmbCausale.SelectedValue;
			else
				DS.expenseprofservice.Rows[0]["movkind"]= DBNull.Value;			
			CurrCausaleProfessionale= DS.expenseprofservice.Rows[0]["movkind"].ToString();
			return CurrCausaleProfessionale; 
		}

		#endregion

		void ResetMissione(){
		}

		void RintracciaMissione(){
		}

		void ResetCedolino(){
		}

		void RintracciaCedolino(){
		}

		void ResetOrdine(){
		}

		void RintracciaOrdine(){
		}

		void ResetIva(){
		}

		void RintracciaIva(){
		}

		void ResetOccasionale(){
		}

		void RintracciaOccasionale(){
		}

		void ResetProfessionale(){
		}

		void RintracciaProfessionale(){
		}

		void ResetDipendente(){
		}

		void RintracciaDipendente(){
		}

		private void tabController_SelectionChanged(object sender, System.EventArgs e) {
		
		}

        private void Frm_expense_wizardcontabilizza_Load(object sender, EventArgs e) {

        }




        string CalculateFilterForMandateDetailLinking(bool SQL) {
            string MyFilter;

            string idreg = DS.expense.Rows[0]["idreg"].ToString();
            string idupb = DS.expenseyear.Rows[0]["idupb"].ToString();
            DataRow OrdineLinked = null;
            if(DS.mandate.Rows.Count > 0)
                OrdineLinked = DS.mandate.Rows[0];
            else
                return "";


            MyFilter = "(idmankind=" +
                QueryCreator.quotedstrvalue(OrdineLinked["idmankind"], SQL) + ")AND" +
                "(yman=" +
                QueryCreator.quotedstrvalue(OrdineLinked["yman"], SQL) + ")AND" +
                "(nman=" +
                QueryCreator.quotedstrvalue(OrdineLinked["nman"], SQL) + ")";
            DataRow TipoOrdine = DS.mandatekind.Select("(idmankind=" +
                QueryCreator.quotedstrvalue(OrdineLinked["idmankind"], SQL) + ")")[0];
            if(chkCredDeb.Checked) {
                if(TipoOrdine["multireg"].ToString().ToUpper() == "S") {
                    if(idreg != "")
                        MyFilter += "AND(idreg='" + idreg + "')";
                }
            }

            if(idupb != "")
                MyFilter += " AND (idupb is null or idupb = " + QueryCreator.quotedstrvalue(idupb, SQL) + ")";

            if(CurrCausaleOrdine == "ORDIN") {
                MyFilter += "AND (idexp_iva is null and idexp_taxable is null)";
            }
            if(CurrCausaleOrdine == "IMPOS") {
                MyFilter += "AND (idexp_iva is null)";
            }
            if(CurrCausaleOrdine == "IMPON") {
                MyFilter += "AND (idexp_taxable is null)";
            }
            MyFilter += "AND(stop is null)";


            return MyFilter;
        }


        private void btnCollegaDettOrdine_Click(object sender, System.EventArgs e) {
            DataRow OrdineLinked = null;
            if(DS.mandate.Rows.Count > 0) OrdineLinked = DS.mandate.Rows[0];

            if(OrdineLinked == null) {
                MessageBox.Show("E' necessario selezionare prima il contr.passivo");
                return;
            }
            MetaData.GetFormData(this, true);
            CurrCausaleOrdine = GetCausaleOrdine();
            string MyFilter = CalculateFilterForMandateDetailLinking(true);
            string tablename = "";
            if(CurrCausaleOrdine == "ORDIN" || CurrCausaleOrdine == "IMPON") {
                tablename = "mandatedetail_taxable";
            }
            if(CurrCausaleOrdine == "IMPOS") {
                tablename = "mandatedetail_iva";
            }

            string command = "choose." + tablename + ".listaspesa." + MyFilter;
            if(!MetaData.Choose(this, command)) return;
            if(CurrCausaleOrdine == "ORDIN") {
                foreach(DataRow R in DS.mandatedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }
            CalcolaImportoInBaseADettagliOrdine();
        }


        private void btnModificaDettOrdine_Click(object sender, System.EventArgs e) {

            DataRow OrdineLinked = null;
            if(DS.mandate.Rows.Count > 0) OrdineLinked = DS.mandate.Rows[0];

            if(OrdineLinked == null) {
                MessageBox.Show("E' necessario selezionare prima il contr.passivo");
                return;
            }
            Meta.GetFormData(true);
            DataTable ToLink = null;
            CurrCausaleOrdine = GetCausaleOrdine();
            if(CurrCausaleOrdine == "ORDIN" || CurrCausaleOrdine == "IMPON") {
                ToLink = DS.mandatedetail_taxable;
            }
            if(CurrCausaleOrdine == "IMPOS") {
                ToLink = DS.mandatedetail_iva;
            }
            string MyFilter = CalculateFilterForMandateDetailLinking(false);
            string MyFilterSQL = CalculateFilterForMandateDetailLinking(true);
            Meta.MultipleLinkUnlinkRows("Selezione dettagli contratto",
                "Dettagli inclusi nel movimento corrente",
                "Dettagli non inclusi in alcun movimento",
                ToLink, MyFilter, MyFilterSQL, "listaspesa");
            if(CurrCausaleOrdine == "ORDIN") {
                foreach(DataRow R in DS.mandatedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }

            CalcolaImportoInBaseADettagliOrdine();
        }

        private void btnScollegaDettOrdine_Click(object sender, System.EventArgs e) {
            DataRow OrdineLinked = null;
            if(DS.mandate.Rows.Count > 0) OrdineLinked = DS.mandate.Rows[0];
            if(OrdineLinked == null) {
                MessageBox.Show("E' necessario selezionare prima il contr.passivo");
                return;
            }
            Meta.GetFormData(true);
            MetaData.Unlink_Grid(dgrDettagliOrdine);
            CurrCausaleOrdine = GetCausaleOrdine();
            if(CurrCausaleOrdine == "ORDIN") {
                foreach(DataRow R in DS.mandatedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }
            CalcolaImportoInBaseADettagliOrdine();
        }



        decimal GetImportoDettagliOrdine() {
            if(DS.mandate.Rows.Count == 0)
                return 0;
            decimal tassocambio;
            DataRow Contratto = DS.mandate.Rows[0];
            tassocambio = CfgFn.GetNoNullDecimal(Contratto["exchangerate"]);
            if(tassocambio == 0) tassocambio = 1;
            decimal imponibile = 0;
            decimal imposta = 0;
            DataRow[] ToConsider = new DataRow[0];
            CurrCausaleOrdine = GetCausaleOrdine();
            if(CurrCausaleOrdine == "IMPON") {
                ToConsider = DS.mandatedetail_taxable.Select("idexp_taxable is not null");
            }
            if(CurrCausaleOrdine == "IMPOS") {
                ToConsider = DS.mandatedetail_iva.Select("idexp_iva is not null");
            }
            if(CurrCausaleOrdine == "ORDIN") {
                ToConsider = DS.mandatedetail_taxable.Select("idexp_taxable is not null");
            }

            foreach(DataRow R in ToConsider) {
                if(R.RowState == DataRowState.Deleted) continue;
                if(R["stop"] != DBNull.Value) continue;
                decimal R_imponibile = CfgFn.GetNoNullDecimal(R["taxable"]);
                decimal R_quantita = CfgFn.GetNoNullDecimal(R["number"]);
                //decimal R_imposta  = RoundDecimal6(CfgFn.GetNoNullDecimal(R["taxrate"]));
                decimal R_imposta = CfgFn.GetNoNullDecimal(R["tax"]);
                decimal R_sconto = CfgFn.Round(CfgFn.GetNoNullDecimal(R["discount"]), 6);
                imponibile += CfgFn.RoundValuta((R_imponibile * R_quantita * (1 - R_sconto)) * tassocambio);
                //imposta    +=  CfgFn.RoundValuta((R_imponibile*R_quantita *(1-R_sconto))*R_imposta*tassocambio);
                imposta += CfgFn.RoundValuta(R_imposta * tassocambio);
            }

            decimal totale = 0;

            if(CurrCausaleOrdine == "IMPON") {
                totale = imponibile;
            }
            if(CurrCausaleOrdine == "IMPOS") {
                totale = imposta;
            }
            if(CurrCausaleOrdine == "ORDIN") {
                totale = imponibile + imposta;
            }

            return totale;

        }

        void CalcolaImportoInBaseADettagliOrdine() {
            if(Meta.IsEmpty) return;
            tipocont currcont = ContabilizzazioneSelezionata();
            if(currcont != tipocont.cont_ordine) return;
            CurrCausaleOrdine = GetCausaleOrdine();
            decimal totale = GetImportoDettagliOrdine();
            //SetImporto(totale);
            CalcTotMandateDetail();
        }

        void SvuotaDettagliOrdine() {
            if(Meta.EditMode) return;
            DS.mandatedetail_taxable.Clear();
            DS.mandatedetail_iva.Clear();
            CalcTotMandateDetail();

        }

        private void btnCollegaDettInvoice_Click(object sender, System.EventArgs e) {

            DataRow IvaLinked = null;
            if(DS.invoice.Rows.Count > 0) IvaLinked = DS.invoice.Rows[0];
            if(IvaLinked == null) {
                MessageBox.Show("E' necessario selezionare prima la fattura.");
                return;
            }
            MetaData.GetFormData(this, true);
            CurrCausaleIva = GetCausaleIva();
            string MyFilter = CalculateFilterForInvoiceDetailLinking(true);
            string tablename = "";
            if(CurrCausaleIva == "DOCUM" || CurrCausaleIva == "IMPON") {
                tablename = "invoicedetail_taxable";
            }
            if(CurrCausaleIva == "IMPOS") {
                tablename = "invoicedetail_iva";
            }

            string command = "choose." + tablename + ".listaspesa." + MyFilter;
            if(!MetaData.Choose(this, command)) return;
            if(CurrCausaleIva == "DOCUM") {
                foreach(DataRow R in DS.invoicedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }
            CalcolaImportoInBaseADettagliFattura();
        }


        void CalcolaImportoInBaseADettagliFattura() {
            if(Meta.IsEmpty) return;
            tipocont currcont = ContabilizzazioneSelezionata();
            if(currcont != tipocont.cont_iva) return;
            CurrCausaleIva = GetCausaleIva();
            decimal totale = GetImportoDettagliFattura();
            //SetImporto(totale);
            CalcTotInvoiceDetail();
        }

        private void btnModificaDettInvoice_Click(object sender, System.EventArgs e) {

            DataRow IvaLinked = null;
            if(DS.invoice.Rows.Count > 0) IvaLinked = DS.invoice.Rows[0];
            if(IvaLinked == null) {
                MessageBox.Show("E' necessario selezionare prima la fattura.");
                return;
            }
            Meta.GetFormData(true);
            DataTable ToLink = null;
            if(CurrCausaleIva == "DOCUM" || CurrCausaleIva == "IMPON") {
                ToLink = DS.invoicedetail_taxable;
            }
            if(CurrCausaleIva == "IMPOS") {
                ToLink = DS.invoicedetail_iva;
            }
            string MyFilter = CalculateFilterForInvoiceDetailLinking(false);
            string MyFilterSQL = CalculateFilterForInvoiceDetailLinking(true);
            Meta.MultipleLinkUnlinkRows("Selezione dettagli fattura",
                "Dettagli inclusi nel movimento corrente",
                "Dettagli non inclusi in alcun movimento",
                ToLink, MyFilter, MyFilterSQL, "listaspesa");
            if(CurrCausaleIva == "DOCUM") {
                foreach(DataRow R in DS.invoicedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }

            CalcolaImportoInBaseADettagliFattura();
        }

        private void btnScollegaDettInvoice_Click(object sender, System.EventArgs e) {
            DataRow IvaLinked = null;
            if(DS.invoice.Rows.Count > 0) IvaLinked = DS.invoice.Rows[0];
            if(IvaLinked == null) {
                MessageBox.Show("E' necessario selezionare prima la fattura.");
                return;
            }
            Meta.GetFormData(true);
            MetaData.Unlink_Grid(dgrDettagliFattura);
            if(CurrCausaleIva == "DOCUM") {
                foreach(DataRow R in DS.invoicedetail_taxable.Rows) {
                    R["idexp_iva"] = R["idexp_taxable"];
                };
            }
            CalcolaImportoInBaseADettagliFattura();
        }

        decimal GetImportoDettagliFattura() {
            if(DS.invoice.Rows.Count == 0)
                return 0;
            decimal tassocambio;
            DataRow Fattura = DS.invoice.Rows[0];
            tassocambio = CfgFn.GetNoNullDecimal(Fattura["exchangerate"]);
            if(tassocambio == 0) tassocambio = 1;
            decimal imponibile = 0;
            decimal imposta = 0;
            DataRow[] ToConsider = new DataRow[0];
            CurrCausaleIva = GetCausaleIva();
            if(CurrCausaleIva == "IMPON") {
                ToConsider = DS.invoicedetail_taxable.Select("idexp_taxable is not null");
            }
            if(CurrCausaleIva == "IMPOS") {
                ToConsider = DS.invoicedetail_iva.Select("idexp_iva is not null");
            }
            if(CurrCausaleIva == "DOCUM") {
                ToConsider = DS.invoicedetail_taxable.Select("idexp_taxable is not null");
            }

            foreach(DataRow R in ToConsider) {
                if(R.RowState == DataRowState.Deleted) continue;
                decimal R_imponibile = CfgFn.GetNoNullDecimal(R["taxable"]);
                decimal R_quantita = CfgFn.GetNoNullDecimal(R["number"]);
                //decimal R_imposta  = RoundDecimal6(CfgFn.GetNoNullDecimal(R["taxrate"]));
                decimal R_imposta = CfgFn.GetNoNullDecimal(R["tax"]);
                decimal R_sconto = CfgFn.Round(CfgFn.GetNoNullDecimal(R["discount"]), 6);
                imponibile += CfgFn.RoundValuta((R_imponibile * R_quantita * (1 - R_sconto)) * tassocambio);
                //imposta    +=  CfgFn.RoundValuta((R_imponibile*R_quantita *(1-R_sconto))*R_imposta*tassocambio);
                imposta += CfgFn.RoundValuta(R_imposta * tassocambio);
            }

            decimal totale = 0;

            if(CurrCausaleIva == "IMPON") {
                totale = imponibile;
            }
            if(CurrCausaleIva == "IMPOS") {
                totale = imposta;
            }
            if(CurrCausaleIva == "DOCUM") {
                totale = imponibile + imposta;
            }

            return totale;

        }


        void CalcTotMandateDetail() {
            txtTotMandateDetail.Text = "";
            if(Meta.IsEmpty) return;
            decimal totale = GetImportoDettagliOrdine();
            txtTotMandateDetail.Text = totale.ToString("c");
        }

        void CalcTotInvoiceDetail() {
            txtTotInvoiceDetail.Text = "";
            if(Meta.IsEmpty) return;
            decimal totale = GetImportoDettagliFattura();
            txtTotInvoiceDetail.Text = totale.ToString("c");
        }


        string CalculateFilterForInvoiceDetailLinking(bool SQL) {
            string MyFilter;
            DataRow IvaLinked = null;
            if(DS.invoice.Rows.Count > 0) IvaLinked = DS.invoice.Rows[0];

            string idreg = DS.expense.Rows[0]["idreg"].ToString();
            string idupb = DS.expenseyear.Rows[0]["idupb"].ToString();

            MyFilter = "(idinvkind=" +
                QueryCreator.quotedstrvalue(IvaLinked["idinvkind"], SQL) + ")AND" +
                "(yinv=" +
                QueryCreator.quotedstrvalue(IvaLinked["yinv"], SQL) + ")AND" +
                "(ninv=" +
                QueryCreator.quotedstrvalue(IvaLinked["ninv"], SQL) + ")";

            if(idupb != "")
                MyFilter += " AND (idupb is null or idupb = " + QueryCreator.quotedstrvalue(idupb, SQL) + ")";

            bool filterparent = false;
            string parid = "";
            if(Meta.InsertMode) {
                DataRow Curr = DS.expense.Rows[0];
                filterparent = (Curr["parentidexp"] != DBNull.Value);
                if(filterparent) parid = Curr["parentidexp"].ToString();
            }

            if(CurrCausaleIva == "DOCUM") {
                MyFilter += "AND (idexp_iva is null and idexp_taxable is null)";
                if(filterparent) MyFilter += "AND ((idexp_taxablemand is null AND idexp_ivamand is null) " +
                                     " OR (idexp_ivamand = idexp_taxablemand AND '" + parid + "' like idexp_taxablemand +'%'))";
            }
            if(CurrCausaleIva == "IMPOS") {
                MyFilter += "AND (idexp_iva is null)";
                if(filterparent) MyFilter += "AND (idexp_ivamand is null OR '" + parid + "' like idexp_ivamand +'%')";
            }
            if(CurrCausaleIva == "IMPON") {
                MyFilter += "AND (idexp_taxable is null)";
                if(filterparent) MyFilter += "AND (idexp_taxablemand is null OR '" + parid + "' like idexp_taxablemand +'%')";
            }

            MyFilter += "AND (flagvariation ='N')";
            return MyFilter;
        }

	}
}


