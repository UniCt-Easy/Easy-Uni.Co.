namespace expense_wizardcontabilizza {
using System;
using System.Data;
[System.CodeDom.Compiler.GeneratedCodeAttribute("System.Data.Design.TypedDataSetGenerator", "2.0.0.0")]
[Serializable()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
public partial class vistaForm: System.Data.DataSet {
// List of DataTables
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expense{get { return this.Tables["expense"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable income{get { return this.Tables["income"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable incomephase{get { return this.Tables["incomephase"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensephase{get { return this.Tables["expensephase"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable manager{get { return this.Tables["manager"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable registry{get { return this.Tables["registry"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expenseyear{get { return this.Tables["expenseyear"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable incomeyear{get { return this.Tables["incomeyear"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expenseitineration{get { return this.Tables["expenseitineration"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable itineration{get { return this.Tables["itineration"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensevar{get { return this.Tables["expensevar"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable incomevar{get { return this.Tables["incomevar"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable fin{get { return this.Tables["fin"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expenseinvoice{get { return this.Tables["expenseinvoice"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable invoice{get { return this.Tables["invoice"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable incomeinvoice{get { return this.Tables["incomeinvoice"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable invoicekind{get { return this.Tables["invoicekind"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable tipomovimento{get { return this.Tables["tipomovimento"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable itinerationresidual{get { return this.Tables["itinerationresidual"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensepayroll{get { return this.Tables["expensepayroll"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable payroll{get { return this.Tables["payroll"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensecasualcontract{get { return this.Tables["expensecasualcontract"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expenseprofservice{get { return this.Tables["expenseprofservice"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable casualcontract{get { return this.Tables["casualcontract"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable profservice{get { return this.Tables["profservice"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensewageaddition{get { return this.Tables["expensewageaddition"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable wageaddition{get { return this.Tables["wageaddition"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable upb{get { return this.Tables["upb"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable mandate{get { return this.Tables["mandate"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable expensemandate{get { return this.Tables["expensemandate"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable mandatekind{get { return this.Tables["mandatekind"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable mandatedetail_taxable{get { return this.Tables["mandatedetail_taxable"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable invoicedetail_taxable{get { return this.Tables["invoicedetail_taxable"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable mandatedetail_iva{get { return this.Tables["mandatedetail_iva"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable invoicedetail_iva{get { return this.Tables["invoicedetail_iva"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable address{get { return this.Tables["address"];}}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
[System.ComponentModel.Browsable(false)]
[System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
public DataTable apactivitykind{get { return this.Tables["apactivitykind"];}}

[System.Diagnostics.DebuggerNonUserCodeAttribute()]
public vistaForm(){
this.BeginInit();
this.InitClass();
this.EndInit();
}
[System.Diagnostics.DebuggerNonUserCodeAttribute()]
private void InitClass() {
this.DataSetName = "vistaForm";
this.Prefix = "";
this.Namespace = "http://tempuri.org/vistaForm.xsd";
this.EnforceConstraints = false;
this.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
DataTable T;
DataColumn C;
DataColumn [] key;
T= new DataTable("expense");
C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nphase", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ymov", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nmov", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ycreation", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("parentidexp", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idreg", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idman", typeof(System.String), ""));
T.Columns.Add(new DataColumn("ypay", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("npay", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("amount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("employtaxamount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("admintaxamount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("clawbackamount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("regmodcode", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idpaymethod", typeof(System.String), ""));
T.Columns.Add(new DataColumn("cin", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idbank", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcab", typeof(System.String), ""));
T.Columns.Add(new DataColumn("cc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("paymentdescr", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idser", typeof(System.String), ""));
T.Columns.Add(new DataColumn("servicestart", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("servicestop", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("ivaamount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("fulfilled", typeof(System.String), ""));
T.Columns.Add(new DataColumn("autotaxflag", typeof(System.String), ""));
T.Columns.Add(new DataColumn("autoclawbackflag", typeof(System.String), ""));
T.Columns.Add(new DataColumn("autokind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idproceeds", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idpayment", typeof(System.String), ""));
T.Columns.Add(new DataColumn("expiration", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("income");
C= new DataColumn("idinc", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nphase", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ymov", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nmov", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ycreation", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("parentidinc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idreg", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idman", typeof(System.String), ""));
T.Columns.Add(new DataColumn("ypro", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("npro", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("amount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("fulfilled", typeof(System.String), ""));
T.Columns.Add(new DataColumn("autokind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idproceeds", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idpayment", typeof(System.String), ""));
T.Columns.Add(new DataColumn("expiration", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idinc"]};
T.PrimaryKey = key;

T= new DataTable("incomephase");
C= new DataColumn("nphase", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("flagregistry", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagfinance", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["nphase"]};
T.PrimaryKey = key;

T= new DataTable("expensephase");
C= new DataColumn("nphase", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("flagregistry", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagfinance", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["nphase"]};
T.PrimaryKey = key;

T= new DataTable("manager");
C= new DataColumn("idman", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("title", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("iddivision", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("email", typeof(System.String), ""));
T.Columns.Add(new DataColumn("phonenumber", typeof(System.String), ""));
T.Columns.Add(new DataColumn("userweb", typeof(System.String), ""));
T.Columns.Add(new DataColumn("passwordweb", typeof(System.String), ""));
T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idman"]};
T.PrimaryKey = key;

T= new DataTable("registry");
C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("title", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("cf", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idland", typeof(System.String), ""));
T.Columns.Add(new DataColumn("p_iva", typeof(System.String), ""));
C= new DataColumn("residence", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("sortcode", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcurrency", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idlanguage", typeof(System.String), ""));
T.Columns.Add(new DataColumn("annotation", typeof(System.String), ""));
C= new DataColumn("human", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("birthdate", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("birthplace", typeof(System.String), ""));
T.Columns.Add(new DataColumn("birthprovince", typeof(System.String), ""));
T.Columns.Add(new DataColumn("birthnation", typeof(System.String), ""));
T.Columns.Add(new DataColumn("gender", typeof(System.String), ""));
T.Columns.Add(new DataColumn("surname", typeof(System.String), ""));
T.Columns.Add(new DataColumn("forename", typeof(System.String), ""));
T.Columns.Add(new DataColumn("foreigncf", typeof(System.String), ""));
C= new DataColumn("flagtax", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("active", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("badgecode", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcategory", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcentralizedcategory", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idmaritalstatus", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idtitle", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idregistryclass", typeof(System.String), ""));
T.Columns.Add(new DataColumn("maritalsurname", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcity", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idnation", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("location", typeof(System.String), ""));
T.Columns.Add(new DataColumn("extmatricula", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idreg"]};
T.PrimaryKey = key;

T= new DataTable("expenseyear");
C= new DataColumn("ayear", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idfin", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
T.Columns.Add(new DataColumn("nphase", typeof(System.String), ""));
T.Columns.Add(new DataColumn("amount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("flagarrear", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["ayear"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("incomeyear");
C= new DataColumn("idinc", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ayear", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idfin", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
T.Columns.Add(new DataColumn("nphase", typeof(System.String), ""));
T.Columns.Add(new DataColumn("amount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("flagarrear", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["idinc"], T.Columns["ayear"]};
T.PrimaryKey = key;

T= new DataTable("expenseitineration");
C= new DataColumn("yitineration", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nitineration", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("movkind", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["yitineration"], T.Columns["nitineration"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("itineration");
C= new DataColumn("yitineration", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nitineration", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idser", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("authorizationdate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idposition", typeof(System.String), ""));
T.Columns.Add(new DataColumn("incomeclass", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("foreigngroupnumber", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("sortcode", typeof(System.String), ""));
T.Columns.Add(new DataColumn("currentclass", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("incomeclassvalidity", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("maxincomeclass", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("idwor", typeof(System.String), ""));
T.Columns.Add(new DataColumn("matricula", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idemployment", typeof(System.String), ""));
T.Columns.Add(new DataColumn("admincarkmcost", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("owncarkmcost", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("footkmcost", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("admincarkm", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("owncarkm", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("footkm", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("italianexemption", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("foreignexemption", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("foreignhours", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("grossfactor", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("totalrefund", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("extraallowance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("kmrefund", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("italianallowance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("foreignallowance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("italiangrossallowance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("foreigngrossallowance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("italianexemptionapplied", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("foreignexemptionapplied", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("employtax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("admintax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("netfee", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("totalnet", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("totalgross", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("total", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("totadvance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("advanceagreed", typeof(System.Decimal), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("completed", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["yitineration"], T.Columns["nitineration"]};
T.PrimaryKey = key;

T= new DataTable("expensevar");
C= new DataColumn("nvar", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yvar", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("amount", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("autokind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idpayment", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["nvar"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("incomevar");
C= new DataColumn("idinc", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nvar", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yvar", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("amount", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("autokind", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["idinc"], T.Columns["nvar"]};
T.PrimaryKey = key;

T= new DataTable("fin");
C= new DataColumn("idfin", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ayear", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("finpart", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("codefin", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("paridfin", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nlevel", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idman", typeof(System.String), ""));
C= new DataColumn("printingorder", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("title", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("expiration", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("flagincomesurplus", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagexpensesurplus", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagcontra", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flaginternaltransfer", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagthirdparties", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idfin"]};
T.PrimaryKey = key;

T= new DataTable("expenseinvoice");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yinv", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ninv", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("movkind", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idinvkind"], T.Columns["yinv"], T.Columns["ninv"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("invoice");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yinv", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ninv", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("registryreference", typeof(System.String), ""));
C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("paymentexpiring", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("idexpirationkind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idintracommunityfreight", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idintracommunitytransaction", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idintracommunityregime", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcurrency", typeof(System.String), ""));
T.Columns.Add(new DataColumn("exchangerate", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("idnomenclatureiva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("netweight", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("number", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("statisticvalue", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("idland", typeof(System.String), ""));
T.Columns.Add(new DataColumn("country", typeof(System.String), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("packinglistnum", typeof(System.String), ""));
T.Columns.Add(new DataColumn("packinglistdate", typeof(System.DateTime), ""));
C= new DataColumn("flagintra", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("officiallyprinted", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("active", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["idinvkind"], T.Columns["yinv"], T.Columns["ninv"]};
T.PrimaryKey = key;

T= new DataTable("incomeinvoice");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yinv", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ninv", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idinc", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("movkind", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idinvkind"], T.Columns["yinv"], T.Columns["ninv"], T.Columns["idinc"]};
T.PrimaryKey = key;

T= new DataTable("invoicekind");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("flagbuysell", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("flagvariation", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idinvkind"]};
T.PrimaryKey = key;

T= new DataTable("tipomovimento");
C= new DataColumn("idtipo", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("descrizione", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idtipo"]};
T.PrimaryKey = key;

T= new DataTable("itinerationresidual");
C= new DataColumn("yitineration", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nitineration", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("registry", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("totalgross", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("totadvance", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("residual", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("linkedsaldo", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("linkedangir", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("linkedanpag", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("completed", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["yitineration"], T.Columns["nitineration"]};
T.PrimaryKey = key;

T= new DataTable("expensepayroll");
C= new DataColumn("idpayroll", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("cu", typeof(System.String), ""));
T.Columns.Add(new DataColumn("ct", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("lu", typeof(System.String), ""));
T.Columns.Add(new DataColumn("lt", typeof(System.DateTime), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["idpayroll"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("payroll");
C= new DataColumn("idpayroll", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("fiscalyear", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("enabletaxrelief", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("currentrounding", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("feegross", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("netfee", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("ct", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("cu", typeof(System.String), ""));
T.Columns.Add(new DataColumn("disbursementdate", typeof(System.DateTime), ""));
C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("flagcomputed", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("flagbalance", typeof(System.String), ""));
C= new DataColumn("workingdays", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idresidence", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idcon", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("lt", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("lu", typeof(System.String), ""));
C= new DataColumn("npayroll", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idpayroll"]};
T.PrimaryKey = key;

T= new DataTable("expensecasualcontract");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["ycon"], T.Columns["idexp"], T.Columns["ncon"]};
T.PrimaryKey = key;

T= new DataTable("expenseprofservice");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("movkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["ycon"], T.Columns["idexp"], T.Columns["ncon"]};
T.PrimaryKey = key;

T= new DataTable("casualcontract");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idser", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("feegross", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("ct", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("cu", typeof(System.String), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ndays", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("taxableothercontracts", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxableotheragency", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("lt", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("lu", typeof(System.String), ""));
T.Columns.Add(new DataColumn("description", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["ycon"], T.Columns["ncon"]};
T.PrimaryKey = key;

T= new DataTable("profservice");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("socialsecurityrate", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("pensioncontributionrate", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("ivarate", typeof(System.Decimal), ""));
C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idser", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("feegross", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("totalcost", typeof(System.Decimal), ""));
C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ndays", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("ivaamount", typeof(System.Decimal), ""));
C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("ivafieldnumber", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("description", typeof(System.String), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["ycon"], T.Columns["ncon"]};
T.PrimaryKey = key;

T= new DataTable("expensewageaddition");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["ycon"], T.Columns["ncon"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("wageaddition");
C= new DataColumn("ycon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ncon", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idser", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("feegross", typeof(System.Decimal), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("stop", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("start", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ndays", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["ycon"], T.Columns["ncon"]};
T.PrimaryKey = key;

T= new DataTable("upb");
C= new DataColumn("idupb", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("codeupb", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("title", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("paridupb", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idunderwriter", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idman", typeof(System.String), ""));
T.Columns.Add(new DataColumn("requested", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("granted", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("previousappropriation", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("expiration", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("txt", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rtf", typeof(System.Byte[]), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("assured", typeof(System.String), ""));
C= new DataColumn("printingorder", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("active", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idupb"]};
T.PrimaryKey = key;

T= new DataTable("mandate");
C= new DataColumn("idmankind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yman", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nman", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idreg", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("registryreference", typeof(System.String), ""));
C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idman", typeof(System.String), ""));
T.Columns.Add(new DataColumn("deliveryexpiration", typeof(System.String), ""));
T.Columns.Add(new DataColumn("deliveryaddress", typeof(System.String), ""));
T.Columns.Add(new DataColumn("paymentexpiring", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("idexpirationkind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idcurrency", typeof(System.String), ""));
T.Columns.Add(new DataColumn("exchangerate", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("doc", typeof(System.String), ""));
T.Columns.Add(new DataColumn("docdate", typeof(System.DateTime), ""));
C= new DataColumn("adate", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("officiallyprinted", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("active", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[3]{
T.Columns["idmankind"], T.Columns["yman"], T.Columns["nman"]};
T.PrimaryKey = key;

T= new DataTable("expensemandate");
C= new DataColumn("idmankind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yman", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nman", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("idexp", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("movkind", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idmankind"], T.Columns["yman"], T.Columns["nman"], T.Columns["idexp"]};
T.PrimaryKey = key;

T= new DataTable("mandatekind");
C= new DataColumn("idmankind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("multireg", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idmankind"]};
T.PrimaryKey = key;

T= new DataTable("mandatedetail_taxable");
C= new DataColumn("idmankind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nman", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("rownum", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yman", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("annotations", typeof(System.String), ""));
T.Columns.Add(new DataColumn("assetkind", typeof(System.String), ""));
C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("detaildescription", typeof(System.String), ""));
T.Columns.Add(new DataColumn("discount", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("idexp_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idexp_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idinv", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("number", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("start", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("stop", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("tax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxrate", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("toinvoice", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagmixed", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idaccmotive", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idivakind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("unabatable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("idgroup", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idreg", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("rowtotal", typeof(System.Decimal), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idmankind"], T.Columns["nman"], T.Columns["rownum"], T.Columns["yman"]};
T.PrimaryKey = key;

T= new DataTable("invoicedetail_taxable");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ninv", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("rownum", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yinv", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("annotations", typeof(System.String), ""));
C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("detaildescription", typeof(System.String), ""));
T.Columns.Add(new DataColumn("discount", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("idaccmotive", typeof(System.String), ""));
C= new DataColumn("idivakind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idmankind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("manrownum", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("nman", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("number", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("tax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("unabatable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("yman", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("estimrownum", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idestimkind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("nestim", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("yestim", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("idexp_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idexp_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idgroup", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idinc_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idinc_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rowtotal", typeof(System.Decimal), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idinvkind"], T.Columns["ninv"], T.Columns["rownum"], T.Columns["yinv"]};
T.PrimaryKey = key;

T= new DataTable("mandatedetail_iva");
C= new DataColumn("idmankind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("nman", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("rownum", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yman", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("annotations", typeof(System.String), ""));
T.Columns.Add(new DataColumn("assetkind", typeof(System.String), ""));
C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("detaildescription", typeof(System.String), ""));
T.Columns.Add(new DataColumn("discount", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("idexp_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idexp_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idinv", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("number", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("start", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("stop", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("tax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxrate", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("toinvoice", typeof(System.String), ""));
T.Columns.Add(new DataColumn("flagmixed", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idaccmotive", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idivakind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("unabatable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("idgroup", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idreg", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("rowtotal", typeof(System.Decimal), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idmankind"], T.Columns["nman"], T.Columns["rownum"], T.Columns["yman"]};
T.PrimaryKey = key;

T= new DataTable("invoicedetail_iva");
C= new DataColumn("idinvkind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ninv", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("rownum", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("yinv", typeof(System.Int16), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("annotations", typeof(System.String), ""));
C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("detaildescription", typeof(System.String), ""));
T.Columns.Add(new DataColumn("discount", typeof(System.Double), ""));
T.Columns.Add(new DataColumn("idaccmotive", typeof(System.String), ""));
C= new DataColumn("idivakind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("idmankind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idupb", typeof(System.String), ""));
C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("manrownum", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("nman", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("number", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("tax", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("taxable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("unabatable", typeof(System.Decimal), ""));
T.Columns.Add(new DataColumn("yman", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("estimrownum", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idestimkind", typeof(System.String), ""));
T.Columns.Add(new DataColumn("nestim", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("yestim", typeof(System.Int16), ""));
T.Columns.Add(new DataColumn("idexp_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idexp_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idgroup", typeof(System.Int32), ""));
T.Columns.Add(new DataColumn("idinc_iva", typeof(System.String), ""));
T.Columns.Add(new DataColumn("idinc_taxable", typeof(System.String), ""));
T.Columns.Add(new DataColumn("rowtotal", typeof(System.Decimal), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[4]{
T.Columns["idinvkind"], T.Columns["ninv"], T.Columns["rownum"], T.Columns["yinv"]};
T.PrimaryKey = key;

T= new DataTable("address");
C= new DataColumn("idaddress", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("active", typeof(System.String), ""));
C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

T.Columns.Add(new DataColumn("lt", typeof(System.DateTime), ""));
T.Columns.Add(new DataColumn("lu", typeof(System.String), ""));
Tables.Add(T);
//Primary Key
key = new DataColumn[1]{
T.Columns["idaddress"]};
T.PrimaryKey = key;

T= new DataTable("apactivitykind");
C= new DataColumn("idapactivitykind", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ayear", typeof(System.Int32), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("ct", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("cu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("description", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lt", typeof(System.DateTime), "");
C.AllowDBNull=false;
T.Columns.Add(C);

C= new DataColumn("lu", typeof(System.String), "");
C.AllowDBNull=false;
T.Columns.Add(C);

Tables.Add(T);
//Primary Key
key = new DataColumn[2]{
T.Columns["idapactivitykind"], T.Columns["ayear"]};
T.PrimaryKey = key;


//Relations
DataTable TPar;
DataTable TChild;
DataColumn []CPar;
DataColumn []CChild;
TPar= Tables["expense"];
TChild= Tables["invoicedetail_iva"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_iva"]};
Relations.Add(new DataRelation("expense_invoicedetail_iva",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["mandatedetail_iva"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_iva"]};
Relations.Add(new DataRelation("expense_mandatedetail_iva",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["invoicedetail_taxable"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_taxable"]};
Relations.Add(new DataRelation("expense_invoicedetail1",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["invoicedetail_taxable"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_iva"]};
Relations.Add(new DataRelation("expense_invoicedetail",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["mandatedetail_taxable"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_taxable"]};
Relations.Add(new DataRelation("expense_mandatedetail1",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["mandatedetail_taxable"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp_iva"]};
Relations.Add(new DataRelation("expense_mandatedetail",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expensemandate"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpensemandate",CPar,CChild));

TPar= Tables["mandate"];
TChild= Tables["expensemandate"];
CPar = new DataColumn[3]{TPar.Columns["idmankind"], TPar.Columns["yman"], TPar.Columns["nman"]};
CChild = new DataColumn[3]{TChild.Columns["idmankind"], TChild.Columns["yman"], TChild.Columns["nman"]};
Relations.Add(new DataRelation("mandateexpensemandate",CPar,CChild));

TPar= Tables["mandatekind"];
TChild= Tables["mandate"];
CPar = new DataColumn[1]{TPar.Columns["idmankind"]};
CChild = new DataColumn[1]{TChild.Columns["idmankind"]};
Relations.Add(new DataRelation("mandatekindmandate",CPar,CChild));

TPar= Tables["wageaddition"];
TChild= Tables["expensewageaddition"];
CPar = new DataColumn[2]{TPar.Columns["ycon"], TPar.Columns["ncon"]};
CChild = new DataColumn[2]{TChild.Columns["ycon"], TChild.Columns["ncon"]};
Relations.Add(new DataRelation("wageadditionexpensewageaddition",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expensewageaddition"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpensewageaddition",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expenseprofservice"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpenseprofservice",CPar,CChild));

TPar= Tables["profservice"];
TChild= Tables["expenseprofservice"];
CPar = new DataColumn[2]{TPar.Columns["ycon"], TPar.Columns["ncon"]};
CChild = new DataColumn[2]{TChild.Columns["ycon"], TChild.Columns["ncon"]};
Relations.Add(new DataRelation("profserviceexpenseprofservice",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expensecasualcontract"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpensecasualcontract",CPar,CChild));

TPar= Tables["casualcontract"];
TChild= Tables["expensecasualcontract"];
CPar = new DataColumn[2]{TPar.Columns["ycon"], TPar.Columns["ncon"]};
CChild = new DataColumn[2]{TChild.Columns["ycon"], TChild.Columns["ncon"]};
Relations.Add(new DataRelation("casualcontractexpensecasualcontract",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expensepayroll"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpensepayroll",CPar,CChild));

TPar= Tables["payroll"];
TChild= Tables["expensepayroll"];
CPar = new DataColumn[1]{TPar.Columns["idpayroll"]};
CChild = new DataColumn[1]{TChild.Columns["idpayroll"]};
Relations.Add(new DataRelation("payrollexpensepayroll",CPar,CChild));

TPar= Tables["invoice"];
TChild= Tables["incomeinvoice"];
CPar = new DataColumn[3]{TPar.Columns["idinvkind"], TPar.Columns["yinv"], TPar.Columns["ninv"]};
CChild = new DataColumn[3]{TChild.Columns["idinvkind"], TChild.Columns["yinv"], TChild.Columns["ninv"]};
Relations.Add(new DataRelation("invoiceincomeinvoice",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["incomeinvoice"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["idinc"]};
Relations.Add(new DataRelation("incomeincomeinvoice",CPar,CChild));

TPar= Tables["invoicekind"];
TChild= Tables["invoice"];
CPar = new DataColumn[1]{TPar.Columns["idinvkind"]};
CChild = new DataColumn[1]{TChild.Columns["idinvkind"]};
Relations.Add(new DataRelation("invoicekindinvoice",CPar,CChild));

TPar= Tables["invoice"];
TChild= Tables["expenseinvoice"];
CPar = new DataColumn[3]{TPar.Columns["idinvkind"], TPar.Columns["yinv"], TPar.Columns["ninv"]};
CChild = new DataColumn[3]{TChild.Columns["idinvkind"], TChild.Columns["yinv"], TChild.Columns["ninv"]};
Relations.Add(new DataRelation("invoiceexpenseinvoice",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expenseinvoice"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpenseinvoice",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["incomevar"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["idinc"]};
Relations.Add(new DataRelation("incomeincomevar",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expensevar"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpensevar",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expenseitineration"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpenseitineration",CPar,CChild));

TPar= Tables["itineration"];
TChild= Tables["expenseitineration"];
CPar = new DataColumn[2]{TPar.Columns["yitineration"], TPar.Columns["nitineration"]};
CChild = new DataColumn[2]{TChild.Columns["yitineration"], TChild.Columns["nitineration"]};
Relations.Add(new DataRelation("itinerationexpenseitineration",CPar,CChild));

TPar= Tables["upb"];
TChild= Tables["incomeyear"];
CPar = new DataColumn[1]{TPar.Columns["idupb"]};
CChild = new DataColumn[1]{TChild.Columns["idupb"]};
Relations.Add(new DataRelation("upbincomeyear",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["incomeyear"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["idinc"]};
Relations.Add(new DataRelation("incomeincomeyear",CPar,CChild));

TPar= Tables["fin"];
TChild= Tables["incomeyear"];
CPar = new DataColumn[1]{TPar.Columns["idfin"]};
CChild = new DataColumn[1]{TChild.Columns["idfin"]};
Relations.Add(new DataRelation("finincomeyear",CPar,CChild));

TPar= Tables["upb"];
TChild= Tables["expenseyear"];
CPar = new DataColumn[1]{TPar.Columns["idupb"]};
CChild = new DataColumn[1]{TChild.Columns["idupb"]};
Relations.Add(new DataRelation("upbexpenseyear",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expenseyear"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idexp"]};
Relations.Add(new DataRelation("expenseexpenseyear",CPar,CChild));

TPar= Tables["fin"];
TChild= Tables["expenseyear"];
CPar = new DataColumn[1]{TPar.Columns["idfin"]};
CChild = new DataColumn[1]{TChild.Columns["idfin"]};
Relations.Add(new DataRelation("finexpenseyear",CPar,CChild));

TPar= Tables["incomephase"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["nphase"]};
CChild = new DataColumn[1]{TChild.Columns["nphase"]};
Relations.Add(new DataRelation("incomephaseincome",CPar,CChild));

TPar= Tables["manager"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["idman"]};
CChild = new DataColumn[1]{TChild.Columns["idman"]};
Relations.Add(new DataRelation("managerincome",CPar,CChild));

TPar= Tables["registry"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["idreg"]};
CChild = new DataColumn[1]{TChild.Columns["idreg"]};
Relations.Add(new DataRelation("registryincome",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["parentidinc"]};
Relations.Add(new DataRelation("incomeincome",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idpayment"]};
Relations.Add(new DataRelation("expenseincome_1",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["income"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["idproceeds"]};
Relations.Add(new DataRelation("incomeincome_1",CPar,CChild));

TPar= Tables["expensephase"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["nphase"]};
CChild = new DataColumn[1]{TChild.Columns["nphase"]};
Relations.Add(new DataRelation("expensephaseexpense",CPar,CChild));

TPar= Tables["manager"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["idman"]};
CChild = new DataColumn[1]{TChild.Columns["idman"]};
Relations.Add(new DataRelation("managerexpense",CPar,CChild));

TPar= Tables["registry"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["idreg"]};
CChild = new DataColumn[1]{TChild.Columns["idreg"]};
Relations.Add(new DataRelation("registryexpense",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["parentidexp"]};
Relations.Add(new DataRelation("expenseexpense",CPar,CChild));

TPar= Tables["expense"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["idexp"]};
CChild = new DataColumn[1]{TChild.Columns["idpayment"]};
Relations.Add(new DataRelation("expenseexpense_1",CPar,CChild));

TPar= Tables["income"];
TChild= Tables["expense"];
CPar = new DataColumn[1]{TPar.Columns["idinc"]};
CChild = new DataColumn[1]{TChild.Columns["idproceeds"]};
Relations.Add(new DataRelation("incomeexpense",CPar,CChild));

}
}
}
