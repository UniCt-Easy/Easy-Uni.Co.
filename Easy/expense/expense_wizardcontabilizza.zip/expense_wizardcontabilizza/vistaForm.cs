﻿namespace expense_wizardcontabilizza {


    partial class vistaForm
    {
        partial class adminoperationDataTable
        {
        }
    
        partial class expenseDataTable
        {
        }
    }
}
